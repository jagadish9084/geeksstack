package com.scb.channels.foundation.search;

import com.fatboyindustrial.gsonjavatime.Converters;
import com.google.gson.GsonBuilder;

import java.util.List;
import java.util.Map;

public class Utils {

    public static ApiClient initApiClient(String baseUrl) {
        ApiClient api = new ApiClient();
        api.setBasePath(baseUrl);
        api.getJSON().setGson(Converters.registerInstant(new GsonBuilder()).create());
        return api;
    }

    public static String getSafe(Map<String, Object> map, String... addresses) {
        String result = null;
        for(int i=0;i!=addresses.length;i++) {
            if (i < addresses.length-1) {
                Object o = map.get(addresses[i]);
                if (o instanceof Map) {
                    map = (Map)o;
                }
                if (o instanceof List && ((List)o).size() > 0) {
                    map = (Map)((List)o).get(0);
                }
            } else {
                result = (String) map.get(addresses[i]);
            }
        }
        return result;
    }

}
