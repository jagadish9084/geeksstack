package com.scb.channels.foundation.search.impl;

import org.junit.Test;

public class SearchBuildersTest {

    //TODO: complete tests

    @Test
    public void quickSearchRequestBuilder() throws Exception {

    }

    @Test
    public void searchRequestBuilder() throws Exception {

    }

    @Test
    public void aggregationRequestBuilder() throws Exception {

    }

    @Test
    public void parseSuggestResponse() throws Exception {

    }

    @Test
    public void suggestRequestBuilder() throws Exception {

    }

}