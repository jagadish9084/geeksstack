package com.scb.channels.foundation.search.impl;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.scb.channels.foundation.api.dto.recon.ReconHeaderRequest;
import com.scb.channels.foundation.api.dto.recon.ReconHeaderResponse;
import com.scb.channels.foundation.api.dto.recon.ReconHeaders;
import com.scb.channels.foundation.datasource.util.DataSourceFactory;
import com.scb.channels.foundation.entitlement.dap.DapPolicy;
import com.scb.channels.foundation.entitlement.dap.policy.research.ResearchDapPolicy;
import com.scb.channels.foundation.objectstore.ObjectStoreProvider;
import com.scb.channels.foundation.objectstore.SimpleMapObjectStoreProvider;
import com.scb.channels.foundation.search.Application;
import com.scb.channels.foundation.search.SearchEngineAdminService;
import com.scb.channels.foundation.search.SearchEngineContext;
import com.scb.channels.foundation.search.SearchEngineService;
import com.scb.channels.foundation.search.api.dto.IngestEnvelope;
import com.scb.channels.foundation.search.elastic.StaticDapPolicyFactory;
import com.scb.channels.foundation.search.model.*;
import com.scb.channels.foundation.util.encryption.HashingUtil;
import io.advantageous.config.Config;
import io.advantageous.config.ConfigLoader;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.node.NodeValidationException;
import org.junit.*;

import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNotNull;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalToIgnoringCase;
import static org.junit.Assert.*;

public class SearchEngineServiceImplTest {

    private static SearchEngineService searchEngineService;
    private static SearchEngineAdminService searchEngineAdminService;

    static ElasticSearchProvider provider;
    private SearchEventService searchEventService;

    private static ObjectStoreProvider objectStoreProvider;

    private static ObjectMapper objectMapper = new Application().objectMapper();

    static {
        try {
            Config config = ConfigLoader.config("service-config.js");
            provider = new EmbeddedElasticSearchProvider(config, "S2B-Search-Engine", "localhost", "node1", true);
        } catch (NodeValidationException | UnknownHostException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }


    @BeforeClass
    public static void setup() throws SQLException {

        Config config = ConfigLoader.config("service-config.js");

        objectStoreProvider = createObjectStoreProvider();

        SearchEventService searchEventService = createSearchEventService(objectStoreProvider);

        searchEngineAdminService = new SearchEngineAdminServiceImpl(config, provider, searchEventService);

        searchEngineService = new SearchEngineServiceImpl(provider, searchEventService, searchEngineAdminService, objectStoreProvider, objectMapper);

    }

    @Before
    public void setupInstance() throws InterruptedException, SQLException {

        searchEventService = createSearchEventService(createObjectStoreProvider());

        prepareIndex();

    }

    @Test
    public void prefix_quicksearch() throws Exception {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors(12345)", HashingUtil.xxHash(getPaymentSource()), new String[]{"12345"}, "Q12345"),
                getPaymentSource())), null);

        waitForReplication();

        SearchResult qsr = searchEngineService.quickSearch("Paym", 1, null);

        assertEquals(1, qsr.getHits());

    }

    @Test
    public void ingest_research_and_quicksearch() throws IOException {
        String content = "{\"applicationId\":\"rp\",\"messageID\":\"1a5a5cb9-3cdc-48ee-aaa8-6f2bdffafdbb\",\"timestamp\":\"2017-02-10T09:14:28.883Z\",\"sourceSystem\":\"FSP\",\"entityType\":\"report\",\"status\":\"ACTIVE\",\"identifier\":[\"83643\"],\"description\":\"sdfdsf sdfsdf sddsfdsf sdfsdf\",\"dapTopic\":[\"ASSET\",\"COUNTRY\"],\"payload\":{\"reportId\":83643,\"publicationType\":\"ACT\",\"title\":\"ACT \\u2013 Kenya \\u2013 Buy 364-day T-bills\",\"frequencyCode\":\"ADHOC\",\"pageCount\":10,\"resources\":[{\"mimeType\":\"application/pdf\",\"path\":\"https://fspapi.global.standardchartered.com/ERService/GetFile(Name='|PDF|2015|gnalt_83643.pdf')\",\"name\":\"gnalt_83643.pdf\"},{\"mimeType\":\"application/x-compressed\",\"path\":\"https://fspapi.global.standardchartered.com/ERService/GetFile(Name='|zipworks|2015|gnalt_83643.zip')\",\"name\":\"gnalt_83643.zip\"}],\"authors\":[{\"id\":674,\"isPrimary\":true},{\"id\":640,\"isPrimary\":false}],\"abstract\":{\"html\":\"\\u2022 Short-dated yields have moved significantly higher over the past few months\\r\\n\\u2022 Given the sharp inversion of the yield curve, we prefer building long 364-day T-bill positions for now\\r\\n\\u2022 We recommend an entry level of 22% for the 12-month T-bill; our stop-loss is 26% for this trade\\r\\n\\u2022 We expect post-tax USD unhedged returns of 10.3% for a 12M T-bill position\"},\"abstractFormatted\":{\"html\":\"<ul>\\r\\n<li>Short-dated yields have moved significantly higher over the past few months</li>\\r\\n<li>Given the sharp inversion of the yield curve, we prefer building long 364-day T-bill positions for now</li>\\r\\n<li>We recommend an entry level of 22% for the 12-month T-bill; our stop-loss is 26% for this trade</li>\\r\\n<li>We expect post-tax USD unhedged returns of 10.3% for a 12M T-bill position</li>\\r\\n</ul>\"},\"researchReasonCodes\":[],\"generationDateTime\":\"2017-02-09T09:35:12\",\"publishedDateTime\":\"10/28/2015 00:45:35\",\"archiveDate\":\"2016-09-10T00:00:00\",\"expiryDate\":\"2017-09-10T00:00:00\",\"alertExpiryDate\":\"2015-10-31T00:45:35\",\"hasPendingData\":false,\"isCorrectionReport\":false,\"languageCode\":\"ENG\",\"assetClassCodes\":[\"RATES\",\"FX\",\"CREDIT\"],\"restrictedTopicCodes\":[],\"materialMentioned\":[],\"nonMaterialMentioned\":[],\"regionCountryIds\":[],\"relatedReports\":[{\"reportId\":1221,\"isTranslation\":false},{\"reportId\":2363,\"isTranslation\":false}],\"externalContentUrl\":\"hardcode\",\"suppressAlert\":[\"EMAIL\",\"MOBILE\",\"WEBISTE\"],\"scoopUrl\":\"http://app.brainshark.com/standardcharter/vu?pi=zHkzDdkODzGjOqz0\",\"entitlementInclude\":[\"RATES\",\"FX\",\"CREDIT\"],\"entitlementExclude\":[],\"imgFileName\":\"83643.jpg\",\"promotionDays\":0}}";

        ObjectMapper objectMapper = new ObjectMapper()
                .registerModule(new JodaModule())
                .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
                .registerModule(new JavaTimeModule())
                .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);


        IngestEnvelope envelope = objectMapper.readValue(content, IngestEnvelope.class);
        searchEngineService.ingest(Collections.singletonList(IndexObject.fromDto(envelope, objectMapper)), new SearchEngineContext("system", "Research"));

        SearchResult qsr = searchEngineService.quickSearch("*", 1, null);
        assertEquals(1, qsr.getHits());

        StaticDapPolicyFactory.init(dapPolicy -> new ResearchDapPolicy());

        SearchEngineService restrictedSe = new SearchEngineServiceImpl(provider, searchEventService, searchEngineAdminService, objectStoreProvider, objectMapper);
        qsr = restrictedSe.quickSearch("*", 1, null);
        assertEquals(1, qsr.getHits());

    }

    @Test
    public void ingest_and_quicksearch() throws Exception {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors(12345)", HashingUtil.xxHash(getPaymentSource()), new String[]{"12345"}, "Q12345"),
                getPaymentSource())), null);

        waitForReplication();

        SearchResult qsr = searchEngineService.quickSearch("Q12345", 1, null);

        assertEquals(1, qsr.getHits());

        assertEquals("[Q12345]", qsr.getResults().get(0).getFields().get("identifier").toString());
        assertEquals("payment", qsr.getResults().get(0).getFields().get("entityType"));
        assertEquals("NextGen", qsr.getResults().get(0).getFields().get("applicationId"));
        assertEquals("Payment Q12345 -> Tata Motors(12345)", qsr.getResults().get(0).getFields().get("description"));

        qsr = searchEngineService.quickSearch("6789", 1, null);
        assertEquals(1, qsr.getHits());

        qsr = searchEngineService.quickSearch("19-01-2016", 1, null);
        assertEquals(1, qsr.getHits());

        qsr = searchEngineService.quickSearch("Q6789*", false, 1, null);
        assertEquals(0, qsr.getHits());
    }

    @Test
    public void ingest_and_update_and_quicksearch() throws Exception {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment R12345 -> Tata Motors(12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12345"}, "Q12345"),
                getPaymentSource())), null);

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment R12345 -> Tata Motors(12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12345"}, "Q12345"),
                getPaymentSource())), null);

        waitForReplication();

        SearchResult qsr = searchEngineService.quickSearch("Q12345", 1, null);

        assertEquals(1, qsr.getHits());

        assertEquals("[Q12345]", qsr.getResults().get(0).getFields().get("identifier").toString());
        assertEquals("payment", qsr.getResults().get(0).getFields().get("entityType"));
        assertEquals("NextGen", qsr.getResults().get(0).getFields().get("applicationId"));
        assertEquals("Payment R12345 -> Tata Motors(12345)", qsr.getResults().get(0).getFields().get("description"));
    }

    @Test
    public void quicksearch_is_subjected_to_DAP_policy() throws Exception {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors(12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12345"}, "Q12345"),
                getPaymentSource("12345"))), null);

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12346 -> Tata Motors(12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12346"}, "Q12346"),
                getPaymentSource("12346"))), null);

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors(12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12347"}, "Q12347"),
                getPaymentSource("12347"))), null);


        waitForReplication();

        //simple case, no dap policy supplied
        SearchResult qsr = searchEngineService.quickSearch("payment", 3, null);
        assertEquals(3, qsr.getHits());

        StaticDapPolicyFactory.init(dapPolicy -> accountBasedDapPolicy());

        SearchEngineService restrictedSe = new SearchEngineServiceImpl(provider, searchEventService, searchEngineAdminService, objectStoreProvider, objectMapper);

        qsr = restrictedSe.quickSearch("payment", 3, new SearchEngineContext("valid-user", "NextGen"));
        assertEquals(2, qsr.getHits());

    }

    @Test
    public void did_you_mean_is_subjected_to_DAP_policy() throws Exception {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors (12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12345"}, "Q12345"),
                getPaymentSource("12345"))), null);

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12346 -> Tata Motors (12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12346"}, "Q12346"),
                getPaymentSource("12346"))), null);

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Shell Petroleum (12347)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12347"}, "Q12347"),
                getPaymentSource("12347"))), null);


        waitForReplication();

        //simple case, no dap policy supplied
        Collection<String> qsr = searchEngineService.predict(PredictionType.DidYouMean, "Shall", 3, new String[]{"description"}, null);
        assertEquals(1, qsr.size());
        assertEquals("shell", qsr.iterator().next());

        qsr = searchEngineService.predict(PredictionType.DidYouMean, "Toto motors", 5, new String[]{"description"}, null);
        assertEquals(1, qsr.size());
        assertEquals("tata motors", qsr.iterator().next());

        StaticDapPolicyFactory.init(dapPolicy -> accountBasedDapPolicy());

        SearchEngineService restrictedSe = new SearchEngineServiceImpl(provider, searchEventService, searchEngineAdminService, objectStoreProvider, objectMapper);

        qsr = restrictedSe.predict(PredictionType.DidYouMean, "Toto motors", 3, new String[]{"description"}, new SearchEngineContext("valid-user", "NextGen"));
        assertEquals(1, qsr.size());
        assertEquals("tata motors", qsr.iterator().next());

        qsr = restrictedSe.predict(PredictionType.DidYouMean, "Shall", 3, new String[]{"description"}, new SearchEngineContext("valid-user", "NextGen"));
        assertEquals(0, qsr.size());

    }

    @Test
    public void aggregation_alongside_search() {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment 12345 -> Tata Motors (12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"200000"}, "Q200000"),
                getPaymentSource("12346"))), null);

        ingestPayments(100);

        SearchAggregation[] agregations = new SearchAggregation[]{
                new SearchAggregation(SearchAggregation.AggregationType.Histogram, SearchAggregation.AggregationReductionType.Date, "agg", "timestamp", 60000.0d, null)
        };
        SearchResult result = searchEngineService.newSearch(new NewSearchRequest("Payment", null, false, false, new String[0], new String[0], agregations, null, 30), null);
        assertEquals(1, result.getAggregations().size());

        agregations = new SearchAggregation[]{
                new SearchAggregation(SearchAggregation.AggregationType.Count, SearchAggregation.AggregationReductionType.None, "agg", "entityType", 1.0d, null)
        };
        result = searchEngineService.newSearch(new NewSearchRequest("Payment", null, false, false, new String[0], new String[0], agregations, null, 30), null);
        assertEquals(1, result.getAggregations().size());
        assertEquals(101, ((Long) result.getAggregations().get("payment")).longValue());
    }

    @Test
    public void did_you_mean_is_subjected_to_DAP_policy_performance_profile() throws Exception {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment 12345 -> Tata Motors (12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"200000"}, "Q200000"),
                getPaymentSource("12346"))), null);

        ingestPayments(10000);

        long start = System.nanoTime();
        for (int i = 0; i != 1000; i++) {
            searchEngineService.predict(PredictionType.DidYouMean, "toto motors", 3, new String[]{"description"}, null);
        }
        System.out.println((System.nanoTime() - start) / 10000);

        StaticDapPolicyFactory.init(dapPolicy -> accountBasedDapPolicy());

        SearchEngineService restrictedSe = new SearchEngineServiceImpl(provider, searchEventService, searchEngineAdminService, objectStoreProvider, objectMapper);

        System.out.println("##########");
        start = System.nanoTime();
        for (int i = 0; i != 1000; i++) {
            restrictedSe.predict(PredictionType.AutoComplete, "toto motors", 3, new String[]{"description"}, new SearchEngineContext("valid-user", "NextGen"));
        }
        System.out.println((System.nanoTime() - start) / 10000);

    }

    private void ingestPayments(int count) {

        List<IndexObject> indexObjects = Lists.newArrayList();
        for (int i = 0; i < count; i++) {
            indexObjects.add(indexObject("nextgen", "payment",
                    MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment " + i + " -> Tata Motors (12345)",
                            HashingUtil.xxHash(getPaymentSource("Q" + i, String.valueOf(i))), new String[]{"1234567"}, "Q" + i),
                    getPaymentSource("Q" + i, String.valueOf(i))));
        }

        searchEngineService.ingest(indexObjects, null);
    }


    @Test
    public void auto_complete_is_subjected_to_DAP_policy() throws Exception {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors(12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12345"}, "Q12345"),
                getPaymentSource("12345"))), null);

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12346 -> Tata Motors(12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12346"}, "Q12346"),
                getPaymentSource("12346"))), null);

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors(12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12347"}, "Q12347"),
                getPaymentSource("12347"))), null);


        waitForReplication();

        //simple case, no dap policy supplied
        Collection<String> qsr = searchEngineService.predict(PredictionType.AutoComplete, "Q1234", 3, new String[]{"identifier"}, null);
        assertEquals(3, qsr.size());

        StaticDapPolicyFactory.init(dapPolicy -> accountBasedDapPolicy());

        SearchEngineService restrictedSe = new SearchEngineServiceImpl(provider, searchEventService, searchEngineAdminService, objectStoreProvider, objectMapper);

        qsr = restrictedSe.predict(PredictionType.AutoComplete, "Q1234", 3, new String[]{"identifier"}, new SearchEngineContext("valid-user", "NextGen"));
        assertEquals(2, qsr.size());


    }


    @Test
    public void quick_search_with_chinese_characters_works() throws Exception {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "叻出色",
                        HashingUtil.xxHash(getPaymentSource("12345")), new String[]{"12345"}, "叻出色"),
                getPaymentSource("12345"))), null);

        waitForReplication();

        //simple case, no dap policy supplied
        SearchResult sr = searchEngineService.quickSearch("叻出", 3, null);
        assertEquals(1, sr.getHits());

        sr = searchEngineService.quickSearch("bob", 3, null);
        assertEquals(0, sr.getHits());
    }

    @Test
    public void new_search_is_subjected_to_DAP_policy() throws Exception {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors(12345)",
                        HashingUtil.xxHash(getPaymentSource("12345")), new String[]{"12345"}, "Q12345"),
                getPaymentSource("12345"))), null);

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12346 -> Tata Motors(12345)",
                        HashingUtil.xxHash(getPaymentSource("12346")), new String[]{"12346"}, "Q12346"),
                getPaymentSource("12346"))), null);

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors(12345)",
                        HashingUtil.xxHash(getPaymentSource("12347")), new String[]{"12347"}, "Q12347"),
                getPaymentSource("12347"))), null);


        waitForReplication();

        SearchResult qsr = searchEngineService.newSearch(
                new NewSearchRequest("Payment", null, false, true, new String[0], new String[0], null, null, 30), null
        );

        assertEquals(3, qsr.getHits());

        StaticDapPolicyFactory.init(dapPolicy -> accountBasedDapPolicy());

        SearchEngineService restrictedSe = new SearchEngineServiceImpl(provider, searchEventService, searchEngineAdminService, objectStoreProvider, objectMapper);

        qsr = restrictedSe.newSearch(
                new NewSearchRequest("Payment", null, false, false, new String[0], new String[0], null, null, 30), new SearchEngineContext("valid-user", "NextGen")
        );
        assertEquals(2, qsr.getHits());

    }

    @Test
    public void continueSearch_is_subjected_to_DAP_policy() throws Exception {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors(12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12345"}, "Q12345"),
                getPaymentSource("12345"))), null);

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12346 -> Tata Motors(Q12346)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12346"}, "Q12346"),
                getPaymentSource("12346"))), null);

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12347 -> Tata Motors(Q12347)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12347"}, "Q12347"),
                getPaymentSource("12347"))), null);


        waitForReplication();

        StaticDapPolicyFactory.init(dapPolicy -> accountBasedDapPolicy());

        SearchEngineService restrictedSe = new SearchEngineServiceImpl(provider, searchEventService, searchEngineAdminService, objectStoreProvider, objectMapper);

        NewSearchRequest searchRequest = new NewSearchRequest("Payment", null, false, false, new String[0], new String[0], null, null, 1);
        SearchResult qsr = restrictedSe.newSearch(
                searchRequest, new SearchEngineContext("valid-user", "NextGen")
        );

        assertEquals(1, qsr.getResults().size());
        assertEquals("[Q12345]", qsr.getResults().get(0).getFields().get("identifier").toString());

        String[] marker = qsr.getResults().get(0).getContinuationMarker();
        qsr = restrictedSe.continueSearch(ContinueSearchRequest.fromMarker(marker, searchRequest), new SearchEngineContext("valid-user", "NextGen"));
        assertEquals(1, qsr.getResults().size());
        assertEquals("[Q12346]", qsr.getResults().get(0).getFields().get("identifier").toString());

        marker = qsr.getResults().get(0).getContinuationMarker();
        qsr = restrictedSe.continueSearch(ContinueSearchRequest.fromMarker(marker, searchRequest), new SearchEngineContext("valid-user", "NextGen"));
        assertEquals(0, qsr.getResults().size());

    }

    @Test
    public void add_favourite() throws Exception {

        ((SimpleMapObjectStoreProvider) objectStoreProvider).reset();

        objectStoreProvider.getObjectStore("SearchEvent").put("s12345678", new SearchEvent("s12345678", null, ""));
        objectStoreProvider.getObjectStore("SearchEvent").put("s12345679", new SearchEvent("s12345679", null, ""));

        objectStoreProvider.getObjectStore("SearchLog").put("s12345678", new SearchEvent("s12345678", null, ""));
        objectStoreProvider.getObjectStore("SearchLog").put("s12345679", new SearchEvent("s12345679", null, ""));

        SearchEngineService restrictedSe = new SearchEngineServiceImpl(provider, new SearchEventServiceImpl(objectStoreProvider), searchEngineAdminService, objectStoreProvider, objectMapper);

        restrictedSe.addFavourite("s12345678", new SearchEngineContext("valid-user", "NextGen"));
        restrictedSe.addFavourite("s12345679", new SearchEngineContext("valid-user", "NextGen"));

        try {
            restrictedSe.addFavourite("s12345680", new SearchEngineContext("valid-user", "NextGen"));
            fail();
        } catch (AssertionError e) {

        }

        Collection<SearchEvent> favourites = restrictedSe.findFavourites(10, new SearchEngineContext("valid-user", "NextGen"));
        assertEquals(2, favourites.size());

    }

    @Test
    public void delete_favourite() throws Exception {

        ((SimpleMapObjectStoreProvider) objectStoreProvider).reset();

        objectStoreProvider.getObjectStore("SearchEvent").put("s12345678", new SearchEvent("s12345678", null, ""));
        objectStoreProvider.getObjectStore("SearchEvent").put("s12345679", new SearchEvent("s12345679", null, ""));
        objectStoreProvider.getObjectStore("SearchEvent").put("s12345680", new SearchEvent("s12345680", null, ""));
        objectStoreProvider.getObjectStore("SearchEvent").put("s12345681", new SearchEvent("s12345681", null, ""));

        objectStoreProvider.getObjectStore("SearchLog").put("s12345678", new SearchEvent("s12345678", null, ""));
        objectStoreProvider.getObjectStore("SearchLog").put("s12345679", new SearchEvent("s12345679", null, ""));
        objectStoreProvider.getObjectStore("SearchLog").put("s12345680", new SearchEvent("s12345680", null, ""));
        objectStoreProvider.getObjectStore("SearchLog").put("s12345681", new SearchEvent("s12345681", null, ""));

        SearchEngineService restrictedSe = new SearchEngineServiceImpl(provider, new SearchEventServiceImpl(objectStoreProvider), searchEngineAdminService, objectStoreProvider, objectMapper);

        restrictedSe.addFavourite("s12345678", new SearchEngineContext("valid-user", "NextGen"));
        restrictedSe.addFavourite("s12345679", new SearchEngineContext("valid-user", "NextGen"));
        restrictedSe.addFavourite("s12345680", new SearchEngineContext("valid-user", "NextGen"));
        restrictedSe.addFavourite("s12345681", new SearchEngineContext("valid-user", "NextGen"));

        Collection<SearchEvent> favourites = restrictedSe.findFavourites(10, new SearchEngineContext("valid-user", "NextGen"));
        assertEquals(4, favourites.size());

        restrictedSe.deleteFavourite("s12345680", new SearchEngineContext("valid-user", "NextGen"));

        favourites = restrictedSe.findFavourites(10, new SearchEngineContext("valid-user", "NextGen"));
        assertEquals(3, favourites.size());

    }

    @Test
    public void get_favourite() throws Exception {

        objectStoreProvider.getObjectStore("SearchEvent").put("s12345678", new SearchEvent("s12345678", null, ""));
        objectStoreProvider.getObjectStore("SearchEvent").put("s12345679", new SearchEvent("s12345679", null, ""));

        objectStoreProvider.getObjectStore("SearchLog").put("s12345678", new SearchEvent("s12345678", null, ""));
        objectStoreProvider.getObjectStore("SearchLog").put("s12345679", new SearchEvent("s12345679", null, ""));

        SearchEngineService restrictedSe = new SearchEngineServiceImpl(provider, new SearchEventServiceImpl(objectStoreProvider), searchEngineAdminService, objectStoreProvider, objectMapper);

        restrictedSe.addFavourite("s12345678", new SearchEngineContext("valid-user", "NextGen"));
        restrictedSe.addFavourite("s12345679", new SearchEngineContext("valid-user", "NextGen"));

        Collection<SearchEvent> favourites = restrictedSe.findFavourites(1, new SearchEngineContext("valid-user", "NextGen"));
        assertEquals(1, favourites.size());

        favourites = restrictedSe.findFavourites(10, new SearchEngineContext("valid-user", "NextGen"));
        assertEquals(2, favourites.size());

    }

    private DapPolicy accountBasedDapPolicy() {
        return (userId, dataType, topic) -> userId.equals("valid-user") && dataType.equals("payment") && !topic[0].endsWith("7");
    }

    @Test
    public void predict_auto_complete() throws Exception {

        ingestThreePayments();
        waitForReplication();

        Collection<String> res = searchEngineService.predict(PredictionType.AutoComplete, "q12", 6, new String[]{"identifier"}, null);
        assertEquals(3, res.size());

    }

    @Test
    public void predict_did_you_mean() throws Exception {

        ingestThreePayments();
        waitForReplication();

        Collection<String> res = searchEngineService.predict(PredictionType.DidYouMean, "Toto Motrs", 6, new String[]{"description"}, null);
        assertEquals(1, res.size());
        assertEquals("tata motors", res.toArray(new String[res.size()])[0]);

        res = searchEngineService.predict(PredictionType.DidYouMean, "tata motr", 6, new String[]{"description"}, null);
        assertEquals(1, res.size());
        assertEquals("tata motors", res.iterator().next());
    }

    @Test
    public void predict_did_you_mean_all() throws Exception {

        ingestThreePayments();
        waitForReplication();

        Collection<String> res = searchEngineService.predict(PredictionType.DidYouMean, "Standerd", 6, new String[]{"description"}, null);
        assertEquals(1, res.size());
        assertEquals("standard", res.toArray(new String[res.size()])[0]);

    }

    @Test
    public void searches_on_identifier_should_use_trigram_analyser() throws InterruptedException {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors (12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12345"}, "Q12345"),
                getPaymentSource())), null);

        waitForReplication();


        validateSearches(1, "345", "2345", "12345", "Q12", "Q123", "Q1234");

        validateSearches(0, "9345", "3345", "22345", "R12", "R123", "Q1236");
    }

    @Test
    public void searches_on_identifier_and_term_should_use_trigram_analyser() throws InterruptedException {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors (12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12345"}, "Q12345"),
                getPaymentSource())), null);

        waitForReplication();

        validateSearches(1, "345 Tata Standard");
        validateSearches(1, "Q1234 Tat Standard");

    }

    @Test
    public void searches_on_identifier_with_filters_should_return() throws InterruptedException {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors (12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12345"}, "QMF", "Q12345"),
                getPaymentSource())), null);

        waitForReplication();

        SearchResult qsr = searchEngineService.newSearch(
                new NewSearchRequest("Q12345", "identifier:(\"Q12345\")", false, false, new String[0], new String[0], null, null, 30), null
        );

        assertEquals(1, qsr.getHits());

    }

    @Test
    public void searches_on_long_identifier_do_not_crash() throws InterruptedException {

        ingestPayments(1000);

        waitForReplication();

        SearchResult qsr = searchEngineService.newSearch(
                new NewSearchRequest("Q12345", "identifier:(\"Q12345\" AND sdf dsfd f sd sdf sdf  sdf sdf sd sdf fds fds dfs dfs dsf dsfd fsdfs df dfsfdsjfhdskjfhdskjfhdsjkhfdsjkfhdskjfhsdkjfhskdjfh sdj  dsjkfksdfjhfjkdshfjkdhsfksdjhf sjkdsdkjhfksdjhfdkjsdhfjksdhfsdjkf  kjhsdkjh )", false, false, new String[0], new String[0], null, null, 30), null
        );

        qsr = searchEngineService.newSearch(
                new NewSearchRequest("Q12345", "identifier:(\"Q12345\" AND \"dfsfdsjfhdskjfhdskjfhdsjkhfdsjkfhdskjfhsdkjfhskdjfh\" \"sdj\"  \"dsjkfksdfjhfjkdshfjkdhsfksdjhf\" \"sjkdsdkjhfksdjhfdkjsdhfjksdhfsdjkf \" \"kjhsdkjh\" \"fdsf\" \"sdfsdf\" \"sdfsdf\" \"sdfsdf\" \"erewr\" \"cvxcv\" \"dsfsdf\"   )", false, false, new String[0], new String[0], null, null, 30), null
        );


        qsr = searchEngineService.newSearch(
                new NewSearchRequest("Q12345", "identifier:(\"Q12345\" AND dfsfdsjfhdskjfhdskjfhdsjkhfdsjkfhdskjfhsdkjfhskdjfh sdj  dsjkfksdfjhfjkdshfjkdhsfksdjhf sjkdsdkjhfksdjhfdkjsdhfjksdhfsdjkf  kjhsdkjh fdsf sdfsdf sdfsdf sdfsdf erewr cvxcv dsfsdf   )", false, false, new String[0], new String[0], null, null, 30), null
        );


        //
        qsr = searchEngineService.newSearch(
                new NewSearchRequest("Q12345", "identifier:(\"Q12345\" AND dfsfdsjfhd sdj  dfsfdsjfhd dfsfdsjfhd  kjhsdkjh fdsf sdfsdf sdfsdf sdfsdf erewr cvxcv dsfsdf   )", false, false, new String[0], new String[0], null, null, 30), null
        );

        qsr = searchEngineService.newSearch(
                new NewSearchRequest("Q12345", "identifier:(\"GSGSCBSE\" AND \"20160909id000000000008000\")", false, false, new String[0], new String[0], null, null, 30), null
        );


        qsr = searchEngineService.newSearch(
                new NewSearchRequest("Q12345", "identifier:(\"Q12345\" AND \"dfsfdsjfhdskjfhd\" \"sdj\"  \"dfsfdsjfhdskjfhd\" \"fdsf\" \"sdfsdf\" \"sdfsdf\" \"sdfsdf\" \"erewr\"  )", false, false, new String[0], new String[0], null, null, 30), null
        );
    }

    private void validateSearches(int expectedLength, String... searches) {
        for (String search : searches) {
            SearchResult qsr = searchEngineService.newSearch(
                    new NewSearchRequest(search, null, false, false, new String[0], new String[0], null, null, 30), null
            );
            assertEquals(expectedLength, qsr.getHits());
        }
    }

    @Test
    public void newSearch() throws Exception {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors (12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12345"}, "Q12345"),
                getPaymentSource())), null);

        waitForReplication();

        SearchResult qsr = searchEngineService.newSearch(
                new NewSearchRequest("Q12345", null, false, false, new String[0], new String[0], null, null, 30), null
        );

        assertEquals(1, qsr.getHits());

        assertNotNull(qsr.getResults().get(0).getContinuationMarker());
        assertEquals(2, qsr.getResults().get(0).getContinuationMarker().length);
        assertEquals("payment#Q12345$12345", qsr.getResults().get(0).getContinuationMarker()[1]);

        assertEquals("[Q12345]", qsr.getResults().get(0).getFields().get("identifier").toString());
        assertEquals("payment", qsr.getResults().get(0).getFields().get("entityType"));
        assertEquals("NextGen", qsr.getResults().get(0).getFields().get("applicationId"));
        assertEquals("Payment Q12345 -> Tata Motors (12345)", qsr.getResults().get(0).getFields().get("description"));

    }

    @Test
    public void newSearchHighlight() throws Exception {

        searchEngineService.ingest(Collections.singleton(
                indexObject("nextgen", "payment",
                        MandatoryIndexFields.of("NextGen",
                                "payment",
                                Instant.now(),
                                "bank of china, bank of singapore, often this is afsfofadsf",
                                HashingUtil.xxHash(getPaymentSource()),
                                new String[]{"12345"},
                                "Q12345"),
                        getPaymentSource())),
                null);

        waitForReplication();

        SearchResult qsr = searchEngineService.newSearch(
                new NewSearchRequest("\"bank of Chin\"", null, false, false, new String[0], new String[0], null, null, 30), null
        );
        assertEquals(1, qsr.getHits());
        assertEquals("<em>bank of chin</em>a, bank of singapore, often this is afsfofadsf", qsr.getResults().get(0).getHighlights().get("description").get(0).toString());

        qsr = searchEngineService.newSearch(
                new NewSearchRequest("\"ank of Chin\"", null, false, false, new String[0], new String[0], null, null, 30), null
        );
        assertEquals(1, qsr.getHits());
        assertEquals("b<em>ank of chin</em>a, bank of singapore, often this is afsfofadsf", qsr.getResults().get(0).getHighlights().get("description").get(0).toString());

        qsr = searchEngineService.newSearch(
                new NewSearchRequest("\"bank of\"", null, false, false, new String[0], new String[0], null, null, 30), null
        );
        assertEquals(1, qsr.getHits());
        assertEquals("<em>bank of</em> china, <em>bank of</em> singapore, often this is afsfofadsf", qsr.getResults().get(0).getHighlights().get("description").get(0).toString());
    }

    @Test
    public void ingestDuplicateIDs() throws Exception {

        searchEngineService.ingest(Collections.singleton(
                indexObject("nextgen", "payment",
                        MandatoryIndexFields.of("NextGen",
                                "payment",
                                Instant.now(),
                                "Icarus shows probability of crisis has fallen",
                                HashingUtil.xxHash(getPaymentSource()),
                                new String[]{"12345"},
                                "Q12345"),
                        getPaymentSource())),
                null);

        waitForReplication();
        Thread.sleep(100);

        // this should update instead of create new
        searchEngineService.ingest(Collections.singleton(
                indexObject("nextgen", "payment",
                        MandatoryIndexFields.of("NextGen",
                                "payment",
                                Instant.now(),
                                "Icarus shows probability of crisis has fallen",
                                HashingUtil.xxHash(getPaymentSource()),
                                new String[]{"12345"},
                                "Q12345"),
                        getPaymentSource())),
                null);

        waitForReplication();
        Thread.sleep(100);

        SearchResult qsr = searchEngineService.newSearch(
                new NewSearchRequest("\"shows probability\"", null, false, false, new String[0], new String[0], null, null, 30), null
        );

        assertEquals(1, qsr.getHits());

        searchEngineService.ingest(Collections.singleton(
                indexObject("nextgen", "payment",
                        MandatoryIndexFields.of("NextGen",
                                "payment",
                                Instant.now(),
                                "Icarus shows probability of crisis has fallen",
                                HashingUtil.xxHash(getPaymentSource()),
                                new String[]{"1234"},
                                "Q12345"),
                        getPaymentSource())),
                null);

        waitForReplication();
        Thread.sleep(100);
        qsr = searchEngineService.newSearch(
                new NewSearchRequest("\"shows probability\"", null, false, false, new String[0], new String[0], null, null, 30), null
        );
        assertEquals(1, qsr.getHits());

    }

    @Test
    public void newSearch_honours_sort() throws Exception {

        searchEngineAdminService.defineIndex("nextgen",
                "payment",
                ImmutableMap.of("payload.paymentref", IndexFieldDefinition.TEXT_WITH_FIELD_DATA));

        ingestThreePayments();

        waitForReplication();

        SearchResult qsr = searchEngineService.newSearch(
                new NewSearchRequest("Q1234*", null, false, false, new String[0], new String[0], null, new SearchSortBy[]{new SearchSortBy("payload.paymentref", SearchSortBy.Direction.Desc)}, 30), null
        );

        assertEquals(3, qsr.getHits());

        assertEquals("[Q12347]", qsr.getResults().get(0).getFields().get("identifier").toString());
        assertEquals("[Q12346]", qsr.getResults().get(1).getFields().get("identifier").toString());
        assertEquals("[Q12345]", qsr.getResults().get(2).getFields().get("identifier").toString());

    }

    @Test
    public void newSearch_honours_did_you_mean() throws Exception {
        ingestThreePayments();
        waitForReplication();

        SearchResult qsr = searchEngineService.newSearch(
                new NewSearchRequest("Q123", null, false, false, new String[0], new String[0], null, null, 30), null
        );

        assertEquals(0, qsr.getSuggestions().size());

        qsr = searchEngineService.newSearch(
                new NewSearchRequest("Q123", null, true, false, new String[0], new String[0], null, null, 30), null
        );

        assertEquals(3, qsr.getSuggestions().size());
        assertThat(qsr.getSuggestions(), containsInAnyOrder(equalToIgnoringCase("Q12345"),
                equalToIgnoringCase("Q12346"),
                equalToIgnoringCase("Q12347")));

    }

    @Test
    public void newSearch_honours_status() throws Exception {

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors (12345)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12345"}, "Q123457"),
                getPaymentSource())), null);

        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12346 -> Tata Motors (12346)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12346"}, StatusFlag.ACTIVE, "Q123467"),
                getPaymentSource())), null);

        waitForReplication();

        StaticDapPolicyFactory.init(dapPolicy -> accountBasedDapPolicy());
        SearchEngineService restrictedSe = new SearchEngineServiceImpl(provider, searchEventService, searchEngineAdminService, objectStoreProvider, objectMapper);

        SearchResult qsr = restrictedSe.newSearch(
                new NewSearchRequest("Q1234", null, false, false, new String[0], new String[0], null, null, 30), new SearchEngineContext("valid-user", "NextGen")
        );

        assertEquals(2, qsr.getHits());

        restrictedSe.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12346 -> Tata Motors (12346)",
                        HashingUtil.xxHash(getPaymentSource()), new String[]{"12346"}, StatusFlag.INACTIVE, "Q123467"),
                getPaymentSource())), new SearchEngineContext("valid-user", "NextGen"));

        qsr = restrictedSe.newSearch(
                new NewSearchRequest("Q1234", null, false, false, new String[0], new String[0], null, null, 30), new SearchEngineContext("valid-user", "NextGen")
        );

        assertEquals(1, qsr.getHits());
    }

    @Test
    public void continueSearch() throws Exception {

        ingestThreePayments();

        waitForReplication();

        NewSearchRequest searchRequest = new NewSearchRequest("Payment", null, false, false, new String[0], new String[0], null, null, 1);
        SearchResult qsr = searchEngineService.newSearch(
                searchRequest, null
        );

        assertEquals(1, qsr.getResults().size());
        assertEquals("[Q12345]", qsr.getResults().get(0).getFields().get("identifier").toString());

        String[] marker = qsr.getResults().get(0).getContinuationMarker();
        qsr = searchEngineService.continueSearch(ContinueSearchRequest.fromMarker(marker, searchRequest), null);
        assertEquals(1, qsr.getResults().size());
        assertEquals("[Q12346]", qsr.getResults().get(0).getFields().get("identifier").toString());

        marker = qsr.getResults().get(0).getContinuationMarker();
        qsr = searchEngineService.continueSearch(ContinueSearchRequest.fromMarker(marker, searchRequest), null);
        assertEquals(1, qsr.getResults().size());
        assertEquals("[Q12347]", qsr.getResults().get(0).getFields().get("identifier").toString());

    }

    @Test
    public void defineIndex() throws Exception {
        try {
            searchEngineAdminService.defineIndex("nextgen", "payment", Collections.emptyMap());
            searchEngineAdminService.defineIndex("nextgen", "payment", Collections.emptyMap());
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    @Test
    public void getIndexDefinition() throws Exception {
        try {
            searchEngineAdminService.defineIndex("nextgen", "payment", Collections.emptyMap());
            ingestThreePayments();
            Map<String, Object> fieldMappings = searchEngineAdminService.getIndexMappings("nextgen", "payment");
            assertTrue(fieldMappings.size() > 0);
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    @Test
    public void index_has_md5hash() throws InterruptedException {
        ingestThreePayments();

        String expectedResult = HashingUtil.xxHash(getPaymentSource("12345"));

        NewSearchRequest searchRequest = new NewSearchRequest("12345", null, false, false, new String[0], new String[0], null, null, 1);
        SearchResult qsr = searchEngineService.newSearch(
                searchRequest, null
        );

        assertEquals(expectedResult, qsr.getResults().get(0).getFields().get("md5hash"));
    }

    @Ignore
    public void canPerformRecon() throws InterruptedException {

        ingestThreePayments();

        ReconHeaderRequest request = new ReconHeaderRequest();
        Instant now = Instant.now();

        ReconHeaders headersInElastic = ReconHeaders.builder()
                .md5hash(HashingUtil.xxHash(getPaymentSource("Q12345", "12345")))
                .identifiers(Arrays.asList("Q12345"))
                .entityType("payment")
                .timestamp(now.minus(1, ChronoUnit.DAYS).getEpochSecond())
                .subCategory("")
                .applicationId("payment")
                .build();
        ReconHeaders headersNotInElastic = ReconHeaders.builder()
                .md5hash(HashingUtil.xxHash(getPaymentSource("Q12349", "12345")))
                .identifiers(Arrays.asList("Q12349"))
                .entityType("payment")
                .timestamp(now.getEpochSecond())
                .subCategory("")
                .applicationId("payment")
                .build();

        ReconHeaders headersHashMiss = ReconHeaders.builder()
                .md5hash(HashingUtil.xxHash(getPaymentSource("Q12346", "Some New Value")))
                .identifiers(Arrays.asList("Q12346"))
                .entityType("payment")
                .timestamp(now.getEpochSecond())
                .subCategory("")
                .applicationId("payment")
                .build();

        request.addReconHeaders(headersInElastic);
        request.addReconHeaders(headersNotInElastic);
        request.addReconHeaders(headersHashMiss);

        ReconHeaders headersToDeactivate = ReconHeaders.builder()
                .md5hash(HashingUtil.xxHash(getPaymentSource("Q12347", "12345")))
                .identifiers(Arrays.asList("Q12347"))
                .entityType("payment")
                .timestamp(now.getEpochSecond())
                .subCategory("")
                .applicationId("payment")
                .build();
        ReconHeaderResponse response = searchEngineService.compareReconHeaders(request, null);

        assertTrue(response.getHdrsToUpdate().contains(headersNotInElastic));
        assertTrue(response.getHdrsToUpdate().contains(headersHashMiss));
        assertEquals(response.getHdrsToDeactivate().size(), 1);
        assertEquals(response.getHdrsToDeactivate().get(0).getMd5hash(), headersToDeactivate.getMd5hash());
        assertTrue(!response.getHdrsToUpdate().contains(headersInElastic));
        assertTrue(!response.getHdrsToDeactivate().contains(headersInElastic));
    }

    @Ignore
    //@Test(timeout = 30000)
    public void reconLargeDataSet() {
        ingestPayments(30000);

        ReconHeaderRequest request = new ReconHeaderRequest();
        ReconHeaders headersInElastic = ReconHeaders.builder()
                .md5hash(HashingUtil.xxHash(getPaymentSource("Q10000", "12345")))
                .identifiers(Arrays.asList("Q12345"))
                .entityType("payment")
                .timestamp(Instant.now().getEpochSecond())
                .subCategory("")
                .applicationId("payment")
                .build();
        request.addReconHeaders(headersInElastic);
        ReconHeaderResponse response = searchEngineService.compareReconHeaders(request, null);
        assertTrue(response.getHdrsToUpdate().contains(headersInElastic));
        assertTrue(response.getHdrsToDeactivate().size() == 29999);

    }

    @Test
    public void excludeHeadersToDeactivateIfNotExist() throws Exception {
        ReconHeaders reconHeaders = ReconHeaders.builder()
                .identifiers(ImmutableList.of("12345", "testEntity"))
                .applicationId("test-app")
                .subCategory("sub")
                .md5hash("1234567890")
                .entityType("testEntity")
                .timestamp(1484709889)
                .action("delete").build();

        ReconHeaderRequest reconHeaderRequest = new ReconHeaderRequest();
        reconHeaderRequest.addReconHeaders(reconHeaders);
        ReconHeaderResponse reconHeaderResponse = searchEngineService.compareReconHeaders(reconHeaderRequest, null);
        Assert.assertEquals(reconHeaderResponse.getHdrsToUpdate().size(), 0);
    }

    @Test
    public void IncludeHeadersToDeactivateIfExist() throws Exception {
        ingestPayments(1);
        ReconHeaders headersInElastic = ReconHeaders.builder()
                .md5hash(HashingUtil.xxHash(getPaymentSource("Q10000", "12345")))
                .identifiers(Collections.singletonList("Q0"))
                .entityType("payment")
                .timestamp(Instant.now().plusSeconds(60).getEpochSecond())
                .subCategory("")
                .applicationId("payment")
                .action("delete")
                .build();

        ReconHeaderRequest reconHeaderRequest = new ReconHeaderRequest();
        reconHeaderRequest.addReconHeaders(headersInElastic);
        ReconHeaderResponse reconHeaderResponse = searchEngineService.compareReconHeaders(reconHeaderRequest, null);
        Assert.assertEquals(1, reconHeaderResponse.getHdrsToUpdate().size());
    }

    @Test
    public void IncludeIfHashMissMatch() throws Exception {
        ingestPayments(1);
        Thread.sleep(2000);
        ReconHeaders headersInElastic = ReconHeaders.builder()
                .md5hash(HashingUtil.xxHash(getPaymentSource("Q10000", "12345")))
                .identifiers(Collections.singletonList("Q0"))
                .entityType("payment")
                .timestamp(Instant.now().getEpochSecond())
                .subCategory("")
                .applicationId("payment")
                .build();

        ReconHeaderRequest reconHeaderRequest = new ReconHeaderRequest();
        reconHeaderRequest.addReconHeaders(headersInElastic);
        ReconHeaderResponse reconHeaderResponse = searchEngineService.compareReconHeaders(reconHeaderRequest, null);
        Assert.assertEquals(1, reconHeaderResponse.getHdrsToUpdate().size());
    }

    @Test
    public void IncludeIfDocNotInSync() throws Exception {
        ingestPayments(1);
        ReconHeaders headersInElastic = ReconHeaders.builder()
                .md5hash(HashingUtil.xxHash(getPaymentSource("Q0", "0ss")))
                .identifiers(Collections.singletonList("Q0"))
                .entityType("payment")
                .timestamp(Instant.now().plusSeconds(60).getEpochSecond())
                .subCategory("")
                .applicationId("payment")
                .build();

        ReconHeaderRequest reconHeaderRequest = new ReconHeaderRequest();
        reconHeaderRequest.addReconHeaders(headersInElastic);
        ReconHeaderResponse reconHeaderResponse = searchEngineService.compareReconHeaders(reconHeaderRequest, null);
        Assert.assertEquals(1, reconHeaderResponse.getHdrsToUpdate().size());
    }

    //Ingest 30000 records

    public static ObjectStoreProvider createObjectStoreProvider() throws SQLException {
        return new SimpleMapObjectStoreProvider();
    }

    public static SearchEventService createSearchEventService(ObjectStoreProvider objectStoreProvider) throws SQLException {

        DataSourceFactory dataSourceFactory = new DataSourceFactory(ConfigLoader.load("service-config.js"));

        return new SearchEventService() {

            @Override
            public String logQuickSearch(String expression, int limit, SearchResponse response) {
                return UUID.randomUUID().toString();
            }

            @Override
            public String logSearch(NewSearchRequest newSearchRequest, SearchResponse response) {
                return UUID.randomUUID().toString();
            }

            @Override
            public String logSearchContinuation(ContinueSearchRequest continueSearchRequest, SearchResponse response) {
                return UUID.randomUUID().toString();
            }

            @Override
            public void logIngestation(Collection<IndexObject> indexObjects) {

            }

            @Override
            public SearchEvent findSearch(String searchId) {
                return objectStoreProvider.<String, SearchEvent>getObjectStore("SearchEvent").get(searchId);
            }
        };

    }

    private void ingestThreePayments() throws InterruptedException {
        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12345 -> Tata Motors(Q12345)",
                        HashingUtil.xxHash(getPaymentSource("Q12345", "12345")), new String[]{"12345"}, "Q12345"),
                getPaymentSource("Q12345", "12345"))), null);
        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12346 -> Tata Motors(Q12346)",
                        HashingUtil.xxHash(getPaymentSource("Q12346", "12345")), new String[]{"12345"}, "Q12346"),
                getPaymentSource("Q12346", "12345"))), null);
        searchEngineService.ingest(Collections.singleton(indexObject("nextgen", "payment",
                MandatoryIndexFields.of("NextGen", "payment", Instant.now(), "Payment Q12347 -> Tata Motors(Q12347)",
                        HashingUtil.xxHash(getPaymentSource("Q12347", "12345")), new String[]{"12345"}, "Q12347"),
                getPaymentSource("Q12347", "12345"))), null);
    }

    private void prepareIndex() {

        boolean exists = provider.getClient().admin().indices()
                .prepareExists("nextgen")
                .execute().actionGet().isExists();

        if (exists) {
            provider.getClient().admin().indices().prepareDelete("nextgen").get();
        }

        exists = provider.getClient().admin().indices()
                .prepareExists("rp-report")
                .execute().actionGet().isExists();
        if (exists) {
            provider.getClient().admin().indices().prepareDelete("rp-report").get();
        }


        searchEngineAdminService.defineIndex("nextgen", "payment", Collections.emptyMap());
    }

    private void waitForReplication() throws InterruptedException {
    }

    private IndexObject indexObject(String myIndex, String myIndexType, MandatoryIndexFields fields, String source) {
        return new IndexObject(source.getBytes(), fields, myIndex, myIndexType);
    }

    private String getPaymentSource() {
        return getPaymentSource("Q12345", "12345");
    }

    private String getPaymentSource(String accountNumber) {
        return getPaymentSource("Q12345", accountNumber);
    }

    private String getPaymentSource(String payRef, String accountNumber) {
        return "{" +
                "         \"paymentref\":\"" + payRef + "\"," +
                "         \"paymentdate\":\"19-01-2016\"," +
                "         \"debitaccno\":\"777777\",   " +
                "         \"payee\":{\n" +
                "            \"payeename\":\"Standard\"," +
                "            \"accountno\":\"" + accountNumber + "\"" +
                "         },\n" +
                "         \"invoice\":{\n" +
                "            \"invoiceno\":\"6789\"," +
                "            \"invoicedate\":\"20-01-2016\"" +
                "         }\n" +
                "     }";
    }

}