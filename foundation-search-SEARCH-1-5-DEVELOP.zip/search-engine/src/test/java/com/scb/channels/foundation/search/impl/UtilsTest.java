package com.scb.channels.foundation.search.impl;

import org.elasticsearch.search.fetch.subphase.highlight.HighlightField;
import org.junit.Test;

import static org.junit.Assert.*;

public class UtilsTest {

    //TODO: complete tests

    @Test
    public void buildPayloadAll() throws Exception {

    }

    @Test
    public void buildSuggesterString() throws Exception {

    }

    @Test
    public void cleanPartialForPredict() throws Exception {

    }

    @Test
    public void getFetchFields() throws Exception {

    }

    @Test
    public void postProcessHighlights() throws Exception {

    }

    @Test
    public void direction() throws Exception {

    }

    @Test
    public void opType() throws Exception {

    }

    @Test
    public void contentType() throws Exception {

    }

    @Test
    public void id() throws Exception {

    }

    @Test
    public void valueOfField() throws Exception {

    }

    @Test
    public void defaultSearchFieldArray() throws Exception {

    }

    @Test
    public void defaultFieldArray() throws Exception {

    }

    @Test
    public void indexType() throws Exception {

    }

    @Test
    public void indexName() throws Exception {

    }

    @Test
    public void isQueryExpression() throws Exception {

    }

    @Test
    public void isSuffixWildcard() throws Exception {

    }

    @Test
    public void groupIngestResults() throws Exception {

    }

    @Test
    public void tagMatch() throws Exception {

    }


    @Test
    public void tagMatch_should_tag_without_case_sensitivity() throws Exception {
        HighlightField hf = Utils.tagMatch("field1", "this VALUE is Very VaLue-Able", "valUE","<em>","</em>");
        assertEquals("field1", hf.getName());
        assertEquals("this <em>VALUE</em> is Very <em>VaLue</em>-Able", hf.getFragments()[0].string());
    }

    @Test
    public void tagMatch_should_tag_for_full_match() throws Exception {
        HighlightField hf = Utils.tagMatch("field1", "VAL", "VAL","<em>","</em>");
        assertEquals("field1", hf.getName());
        assertEquals("<em>VAL</em>", hf.getFragments()[0].string());
    }

    @Test
    public void tagMatch_should_tag_for_multi_term_match() throws Exception {
        HighlightField hf = Utils.tagMatch("field1", "ACH", "HSBC ACH","<em>","</em>");
        assertEquals("field1", hf.getName());
        assertEquals("<em>ACH</em>", hf.getFragments()[0].string());
    }

    @Test
    public void tagMatch_should_tag_for_multi_term_no_match() throws Exception {
        HighlightField hf = Utils.tagMatch("field1", "AC", "HSBC ACH","<em>","</em>");
        assertEquals("field1", hf.getName());
        assertEquals("AC", hf.getFragments()[0].string());
    }

    @Test
    public void tagMatch_should_tag_for_multi_term_query() throws Exception {
        HighlightField hf = Utils.tagMatch("field1", "this VALUE is Very VaLue-Able", "valUE this","<em>","</em>");
        assertEquals("field1", hf.getName());
        assertEquals("<em>this</em> <em>VALUE</em> is Very <em>VaLue</em>-Able", hf.getFragments()[0].string());

        hf = Utils.tagMatch("field1", "SearchSanityPayeetwo | SGD 450 | TT | 2017-03-24T09:58:15Z | Completed","SGD sanity", "<em>","</em>");
        assertEquals("Search<em>Sanity</em>Payeetwo | <em>SGD</em> 450 | TT | 2017-03-24T09:58:15Z | Completed", hf.getFragments()[0].string());

        hf = Utils.tagMatch("field1", "SITBS01", "standard BUKIT", "<em>","</em>");
        assertEquals("SITBS01", hf.getFragments()[0].string());
    }

    @Test
    public void tagMatch_should_tag_for_phrase() throws Exception {
        // case-insensitive test
        HighlightField hf = Utils.tagMatch("field1", "bank of China, bank of singapore, bank of china", "bank of china","<em>","</em>");
        assertEquals("field1", hf.getName());
        assertEquals("<em>bank of China</em>, bank of singapore, <em>bank of china</em>", hf.getFragments()[0].string());
        hf = Utils.tagMatch("field1", "bank of china, bank of singapore, bank of china", "bank of china","<em>","</em>");
        assertEquals("field1", hf.getName());
        assertEquals("<em>bank of china</em>, bank of singapore, <em>bank of china</em>", hf.getFragments()[0].string());
        // middle of the phrase
        hf = Utils.tagMatch("field1", "bank of china, bank of singapore, bank of china", "bank of singapore","<em>","</em>");
        assertEquals("field1", hf.getName());
        assertEquals("bank of china, <em>bank of singapore</em>, bank of china", hf.getFragments()[0].string());
        // end of the phrase
        hf = Utils.tagMatch("field1", "bank of china, bank of singapore, bank of Indonesia", "bank of indonesia","<em>","</em>");
        assertEquals("field1", hf.getName());
        assertEquals("bank of china, bank of singapore, <em>bank of Indonesia</em>", hf.getFragments()[0].string());
        // partial phrase test
        hf = Utils.tagMatch("field1", "bank of China, bank of singapore, bank of china", "bank of chin","<em>","</em>");
        assertEquals("field1", hf.getName());
        assertEquals("<em>bank of Chin</em>a, bank of singapore, <em>bank of chin</em>a", hf.getFragments()[0].string());
        // partial middle phrase test
        hf = Utils.tagMatch("field1", "bank of China, bank of singapore, bank of china", "ank of chin","<em>","</em>");
        assertEquals("field1", hf.getName());
        assertEquals("b<em>ank of Chin</em>a, bank of singapore, b<em>ank of chin</em>a", hf.getFragments()[0].string());

    }

}