package com.scb.channels.foundation.search.api.resource;

import com.scb.channels.foundation.search.SearchEngineService;
import com.scb.channels.foundation.search.api.dto.FilterSpec;
import com.scb.channels.foundation.search.api.dto.FilterSpecs;
import com.scb.channels.foundation.search.api.dto.SearchRequest;
import com.scb.channels.foundation.search.model.NewSearchRequest;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

public class SearchResourceImplTest {

    private SearchEngineService searchEngineService;

    @Before
    public void setupSearchEngine() {
        searchEngineService = mock(SearchEngineService.class);
    }

    @Test
    public void expression_filter_and_specs() throws Exception {

        SearchRequest sr = SearchRequest.builder()
                .expression("A")
                .filterExpression("B")
                .filterSpecs(FilterSpecs.of(
                        new FilterSpec("field1", FilterSpec.Operator.eq, new String[] { "value1" }))
                ).build();

        NewSearchRequest nsr = new NewSearchRequest(sr);

        assertEquals("A", nsr.getExpression());
        assertEquals("B AND field1:(\"value1\")", nsr.getFilterExpression());

    }

    @Test
    public void expression_filter() throws Exception {

        SearchRequest sr = SearchRequest.builder()
                .expression("A")
                .filterExpression("B")
                .build();

        NewSearchRequest nsr = new NewSearchRequest(sr);

        assertEquals("A", nsr.getExpression());

    }


    @Test
    public void expression_specs() throws Exception {

        SearchRequest sr = SearchRequest.builder()
                .expression("A")
                .filterSpecs(FilterSpecs.of(
                        new FilterSpec("field1", FilterSpec.Operator.eq, new String[] { "value1" }))
                ).build();

        NewSearchRequest nsr = new NewSearchRequest(sr);

        assertEquals("A", nsr.getExpression());
        assertEquals("field1:(\"value1\")", nsr.getFilterExpression());

    }

}