package com.scb.channels.foundation.search.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.joda.time.DateTime;
import org.joda.time.format.ISODateTimeFormat;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.nio.charset.Charset;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.GZIPInputStream;

public class DataLoader {

    static CloseableHttpClient httpclient = HttpClients.createDefault();

    private static ExecutorService executor = Executors.newFixedThreadPool(8);

    public static void main(String[] args) throws IOException {

        String file = args[0];
        String hostPort = args[1];
        int batchSize = Integer.parseInt(args[2]);
        String series = args[3];

        do {
            LineNumberReader reader = new LineNumberReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(file))));
            String line;
            List<Object> objects = new ArrayList();
            int batch = 1;
            while ((line = reader.readLine()) != null) {
                try {
                    postMessage(objects, line, series);
                } catch (Exception e) {
                    System.err.println(line + ": " + e.getMessage());
                }
                if (objects.size() >= batchSize) {
                    System.out.println("Submitted batch " + batch + " for series " + series);
                    post(hostPort, objects);
                    objects.clear();
                    batch++;
                }
            }
            reader.close();
            series = String.valueOf( Integer.parseInt(series) + 1);
        } while (true);
    }

    private static void post(String hostPort, List<Object> objects) throws IOException {
        executor.submit( () -> {
            try {
                Map<String, Object> r = new HashMap<>();
                r.put("ingestEnvelopes", objects);

                ObjectMapper mapper = new ObjectMapper();
                HttpPost post = new HttpPost("http://" + hostPort + "/search/ingest?userid=32424324");
                post.setEntity(new StringEntity(mapper.writeValueAsString(r)));
                post.setHeader("Content-Type", "application/json");
                HttpResponse response = httpclient.execute(post);
                IOUtils.toString(response.getEntity().getContent(), Charset.defaultCharset());
                response.getEntity().getContent().close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private static void postMessage(List<Object> objects, String line, String series) throws IOException {

        line = StringUtils.replace(line,"\":.","\":0.");

        line = StringUtils.replace(line,"\"workflow\":\"null\"", "\"workflow\": [] ");

        line = StringUtils.replace(line,":\"null\"", ":null ");

        line = StringUtils.replace(line,"\":,\"", "\":0.0,\"");

        line = StringUtils.replace(line,"\"identifier\":[\"Q", "\"identifier\":[\"Q" + series);

        ObjectMapper mapper = new ObjectMapper();

        Map<String,Object> o = mapper.readValue(line, Map.class);

        List list = (List)o.get("ingestEnvelopes");


        ((Map)list.get(0)).put("timestamp", DateTime.now().toString(ISODateTimeFormat.dateTime()));
        ((Map)list.get(0)).put("dapTopic", new ArrayList(Arrays.asList("A","B")));
        ((Map)list.get(0)).put("description", "a nice description");


        objects.addAll( list );

    }

}
