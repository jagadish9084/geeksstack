package com.scb.channels.foundation.search.model;

public class ServerEndPoint {

    private int port;
    private String host;

    public ServerEndPoint(String host, int port) {
        this.port = port;
        this.host = host;
    }



    public int getPort() {
        return port;
    }

    public String getHost() {
        return host;
    }
}
