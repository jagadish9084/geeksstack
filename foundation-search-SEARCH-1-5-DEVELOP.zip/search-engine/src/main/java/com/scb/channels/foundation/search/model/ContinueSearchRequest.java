package com.scb.channels.foundation.search.model;

public class ContinueSearchRequest {

    private final String[] marker;
    private NewSearchRequest newSearchRequest;

    public ContinueSearchRequest(String[] marker, NewSearchRequest newSearchRequest) {
        this.marker = marker;
        this.newSearchRequest = newSearchRequest;
    }

    public static ContinueSearchRequest fromMarker(String[] marker,NewSearchRequest newSearchRequest) {
        return new ContinueSearchRequest(marker, newSearchRequest);
    }

    public String[] getMarker() {
        return marker;
    }

    public NewSearchRequest getNewSearchRequest() {
        return newSearchRequest;
    }
}
