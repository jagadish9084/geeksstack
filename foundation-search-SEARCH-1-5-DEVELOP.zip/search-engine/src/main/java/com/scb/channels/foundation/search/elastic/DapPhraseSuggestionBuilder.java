package com.scb.channels.foundation.search.elastic;

import com.scb.channels.foundation.entitlement.dap.DapPolicy;
import com.scb.channels.foundation.search.SearchEngineContext;
import org.elasticsearch.index.query.QueryShardContext;
import org.elasticsearch.search.suggest.SuggestionSearchContext;
import org.elasticsearch.search.suggest.phrase.DapPhraseSuggester;
import org.elasticsearch.search.suggest.phrase.PhraseSuggestionBuilder;

import java.io.IOException;
import java.lang.reflect.Field;

public class DapPhraseSuggestionBuilder extends PhraseSuggestionBuilder {

    private final String dapPolicy;
    private final String userId;

    public DapPhraseSuggestionBuilder(String field, SearchEngineContext context) {
        super(field);
        this.dapPolicy = context.getDapPolicy();
        this.userId = context.getUserId();
    }

    @Override
    public String getWriteableName() {
        return DapPhraseSuggester.NAME;
    }

    @Override
    public SuggestionSearchContext.SuggestionContext build(QueryShardContext context) throws IOException {
        SuggestionSearchContext.SuggestionContext r = super.build(context);
        Field field;
        try {
            field = r.getClass().getSuperclass().getDeclaredField("suggester");
            field.setAccessible(true);
            field.set(r, new  DapPhraseSuggester(dapPolicy(), userId) );
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new RuntimeException(e.getMessage(),e);
        }
        return r;
    }

    private DapPolicy dapPolicy() {
        return StaticDapPolicyFactory.INSTANCE.create(dapPolicy);
    }
}
