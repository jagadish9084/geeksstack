package com.scb.channels.foundation.search.api.dto;

import com.google.common.collect.Lists;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.stream.Stream;

public class FilterSpec {

    public FilterSpec() {

    }

    public FilterSpec(String field, Operator eq, String[] values) {
        this.field = field;
        operator = eq;
        this.values = values;
    }

    public enum Operator { eq("",":"), in("",":"), ne("NOT",":"), lt("",":<"), gt("",":>"), le("",":<="), ge("",":>=");
        private final String preOp;
        private final String luceneOp;

        Operator(String preOp, String luceneOp) {
            this.preOp = preOp;
            this.luceneOp = luceneOp;
        }

        public String preOp() {
            return preOp;
        }

        public String luceneOp() {
            return luceneOp;
        }
    }

    private String field;
    private Operator operator;
    private String[] values;

    public String getField() {
        return field;
    }

    public Operator getOperator() {
        return operator;
    }

    public String[] getValues() {
        return values;
    }

    @Override
    public String toString() {
        return operator.preOp() + field + operator.luceneOp() + "(" + StringUtils.join(quoteValues(values)," " + conjunction() + " ") + ")";
    }

    private String conjunction() {
        return Operator.in.equals(operator) ? " OR " : " AND ";
    }

    private String[] quoteValues(String[] values) {
        List<String> val = Lists.newArrayList();
        Stream.of(values).forEach(v->{
            if (v.startsWith("[") && v.endsWith("]")) {
                val.add(v);
            } else {
                val.add("\"" + v + "\"");
            }
        });
        return val.toArray(new String[val.size()]);
    }

}
