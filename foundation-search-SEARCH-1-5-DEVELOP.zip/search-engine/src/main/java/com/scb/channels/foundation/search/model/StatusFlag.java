package com.scb.channels.foundation.search.model;

public enum StatusFlag {

    ACTIVE, INACTIVE

}
