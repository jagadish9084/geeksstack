package com.scb.channels.foundation.search.api.dto;

import com.scb.channels.foundation.search.model.StatusFlag;

import java.lang.reflect.Field;
import java.time.Instant;
import java.util.concurrent.atomic.AtomicInteger;

public class IngestEnvelope {

    private String applicationId;
    private String entityType;
    private Instant timestamp = Instant.now();
    private String[] identifier;
    private Object payload;
    private String description;
    private String[] dapTopic;
    private String status;

    public String getApplicationId() {
        return applicationId;
    }

    public String getEntityType() {
        return entityType;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    public String[] getIdentifier() {
        return identifier;
    }

    public Object getPayload() {
        return payload;
    }

    public String getDescription() {
        return description;
    }

    public String[] getDapTopic() {
        return dapTopic;
    }

    public String getStatus() {
        return status == null ? StatusFlag.ACTIVE.name() : status;
    }

    public String checkComplete(AtomicInteger counter) {
        boolean ok = true;
        StringBuffer sb = new StringBuffer();
        ok &= assertNotNull(this, sb, "applicationId");
        ok &= assertNotNull(this, sb, "entityType");
        ok &= assertNotNull(this, sb, "timestamp");
        ok &= assertNotNull(this, sb, "identifier");
        ok &= assertNotNull(this, sb, "payload");
        ok &= assertNotNull(this, sb, "description");
        ok &= assertNotNull(this, sb, "dapTopic");
        if (!ok) {
            counter.incrementAndGet();
        }
        return sb.toString();
    }

    private boolean assertNotNull(Object ths, StringBuffer sb, String fieldName) {
        Field f;
        try {
            f = ths.getClass().getDeclaredField(fieldName);
            f.setAccessible(true);
            if (f.get(ths) == null) {
                sb.append(fieldName).append(" is null. ");
                return false;
            }
            return true;
        } catch (IllegalAccessException | NoSuchFieldException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

}
