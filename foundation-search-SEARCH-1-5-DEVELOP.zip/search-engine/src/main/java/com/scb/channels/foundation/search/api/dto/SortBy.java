package com.scb.channels.foundation.search.api.dto;

public class SortBy {

    public enum Direction{ Asc, Desc }

    private String fieldName;
    private Direction direction;

    public String getFieldName() {
        return fieldName;
    }

    public Direction getDirection() {
        return direction;
    }
}
