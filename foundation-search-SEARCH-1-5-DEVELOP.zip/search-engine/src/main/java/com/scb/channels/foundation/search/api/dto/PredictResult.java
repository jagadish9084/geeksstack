package com.scb.channels.foundation.search.api.dto;

import java.util.Collection;

public class PredictResult {

    private Collection<String> results;

    public PredictResult() { }

    public PredictResult(Collection<String> results) {
        this.results = results;
    }

    public Collection<String> getResults() {
        return results;
    }
}
