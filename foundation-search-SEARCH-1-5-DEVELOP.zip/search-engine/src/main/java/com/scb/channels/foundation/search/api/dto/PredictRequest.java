package com.scb.channels.foundation.search.api.dto;

import com.scb.channels.foundation.search.model.PredictionType;

public class PredictRequest {

    private PredictionType predictionType;
    private String partial;
    private String[] fields;
    private int resultLimit;

    public PredictionType getPredictionType() {
        return predictionType;
    }

    public String getPartial() {
        return partial;
    }

    public String[] getFields() {
        return fields;
    }

    public int getResultLimit() {
        return resultLimit;
    }

}
