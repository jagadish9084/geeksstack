package com.scb.channels.foundation.search.api.dto;

import java.util.Collections;
import java.util.Map;

public class FieldDefinition {

    public enum DataType { Text, Date, Boolean, Long, Integer, Short, Byte, Double, Float, Object, Array }

    private String analyser;
    private Map<String, FieldDefinition> children;
    private boolean sortable;
    private DataType dataType;

    public String getAnalyser() {
        return analyser;
    }

    public Map<String, FieldDefinition> getChildren() {
        return children == null ? Collections.emptyMap() : children;
    }

    public boolean isSortable() {
        return sortable;
    }

    public DataType getDataType() {
        return dataType;
    }
}
