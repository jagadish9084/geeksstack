package com.scb.channels.foundation.search.model;

import java.util.List;
import java.util.Map;

public class Result {

    private Map<String, List<String>> highlights;
    private Map<String, Object> fields;
    private String[] continuationMarker;
    private Map<String, Object> payloadMap;
    private String id;

    public Result(Map<String, Object> payloadMap, String[] continuationMarker, Map<String,List<String>> highlights, Map<String, Object> fields,String id) {
        this.continuationMarker = continuationMarker;
        this.payloadMap = payloadMap;
        this.fields = fields;
        this.highlights = highlights;
        this.id=id;
    }

    public String[] getContinuationMarker() {
        return continuationMarker;
    }

    public Map<String, List<String>> getHighlights() {
        return highlights;
    }

    public Map<String, Object> getFields() {
        return fields;
    }

    public Map<String, Object> getPayloadAsMap() {
        return payloadMap;
    }

    public String getId() {
        return id;
    }
}
