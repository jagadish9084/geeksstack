package com.scb.channels.foundation.search.model;

public enum PredictionType {

    DidYouMean, AutoComplete

}
