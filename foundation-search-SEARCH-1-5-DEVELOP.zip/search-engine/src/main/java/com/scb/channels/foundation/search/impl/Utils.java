package com.scb.channels.foundation.search.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.scb.channels.foundation.search.model.IndexObject;
import com.scb.channels.foundation.search.model.MandatoryIndexFields;
import com.scb.channels.foundation.search.model.SearchResult;
import com.scb.channels.foundation.search.model.SearchSortBy;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.common.text.Text;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightField;
import org.elasticsearch.search.sort.SortOrder;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Stream;

import static com.scb.channels.foundation.search.SearchEngineAdminService.DEFAULT_FIELDS;
import static com.scb.channels.foundation.search.SearchEngineAdminService.DEFAULT_SEARCH_FIELDS;
import static com.scb.channels.foundation.search.impl.SearchBuilders.UID_FIELD;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;
import static org.apache.commons.lang3.StringUtils.replace;

public class Utils {

    private static final String HIGHLIGHT_PREFIX_TAG = "<em>";
    private static final String HIGHLIGHT_POST_TAG = "</em>";

    static StringBuilder buildPayloadAll(Object payload, StringBuilder builder) {
        if (payload instanceof String) {
            builder.append(payload.toString()).append(' ');
        }
        if (payload instanceof Map) {
            //noinspection unchecked
            ((Map<String,Object>)payload).entrySet().forEach(e->buildPayloadAll(e.getValue(),builder));
        }
        if (payload instanceof Collection) {
            //noinspection unchecked
            ((Collection<Object>)payload).forEach(e->buildPayloadAll(e,builder));
        }
        return builder;
    }

    static String buildSuggesterString(String description, List<String> identifier, String payloadContent) {
        return (StringUtils.join(identifier == null ? Collections.emptyList() : identifier," ") + " " +
                (description == null ? "" : description) + " " + payloadContent).toLowerCase();
    }

    static String cleanPartialForPredict(String partial) {
        partial = replace(partial,"+","");
        partial = replace(partial,"-","");
        partial = replace(partial,"(","");
        partial = replace(partial,")","");
        partial = replace(partial,"|","");
        return partial;
    }

    private static boolean hasTagMatch(String value, String query) {
        return Stream.of(StringUtils.split(query,' ')).filter(value::contains).count() > 0;
    }

    static String[] getFetchFields(String[] sourceFields) {
        List<String> fetchFields = Stream.of(sourceFields).filter(f->!f.equals("_all")).collect(toList());
        fetchFields.add(UID_FIELD);
        return fetchFields.toArray(new String[fetchFields.size()]);
    }

    static Map<String, HighlightField> postProcessHighlights(SearchHit sh, String queryExpression) {
        String unquotedExpression = queryExpression.replaceAll("\"","");
        Map<String,String> fullFieldMatches = findMatchingPayload("", sh.getSource(), unquotedExpression, f->!MandatoryIndexFields.isInternalField(f), Maps.newHashMap());
        return fullFieldMatches.entrySet().stream().collect(
                toMap(Map.Entry::getKey, e->tagMatch(e.getKey(), e.getValue(), unquotedExpression, HIGHLIGHT_PREFIX_TAG, HIGHLIGHT_POST_TAG)));
    }

    static SortOrder direction(SearchSortBy sortBy) {
        return SearchSortBy.Direction.Asc.equals(sortBy.getDirection()) ? SortOrder.ASC : SortOrder.DESC;
    }

    static IndexRequest.OpType opType() {
        return IndexRequest.OpType.CREATE;
    }

    static XContentType contentType() {
        return XContentType.JSON;
    }

    static String id(IndexObject indexObject) {
        return StringUtils.join(indexObject.getFields().getIdentifier(),"-") + "$" + StringUtils.join(indexObject.getFields().getDapTopic(),"-");
    }

    static String[] defaultSearchFieldArray(String... additions) {
        List<String> fields = Lists.newArrayList(DEFAULT_SEARCH_FIELDS);
        fields.addAll(Arrays.asList(additions));
        return fields.toArray(new String[fields.size()]);
    }

    static String[] defaultFieldArray(String... additions) {
        List<String> fields = Lists.newArrayList(DEFAULT_FIELDS.keySet());
        fields.addAll(Arrays.asList(additions));
        return fields.toArray(new String[fields.size()]);
    }

    static String indexType(IndexObject indexObject) {
        return indexObject.getIndexType().toLowerCase();
    }

    static String indexName(IndexObject indexObject) {
        return indexObject.getIndexName().toLowerCase();
    }

    static boolean isQueryExpression(String expression) {
        if (expression.contains("\"")) {
            return true;
        }
        String[] terms = StringUtils.split(expression," ");
        int maxTermLength = 0;
        if (terms.length > 0) {
            Optional<Integer> optional = Stream.of(terms).map(String::length).max(Integer::compare);
            maxTermLength = optional.isPresent() ? optional.get() : 0;
        }
        return maxTermLength > 30 || terms.length > 6 || expression.contains("-") || expression.contains("+") || expression.contains("(") && expression.contains(")");
    }

    static boolean isSuffixWildcard(String expression) {
        return expression.startsWith("*") || expression.startsWith("?");
    }

    static Map<String, String> groupIngestResults(BulkResponse response) {
        return Stream.of(response.getItems()).map(i -> Pair.of(trimId(i.getId()), !i.isFailed() ? "OK" : "FAIL:" + i.getFailureMessage())).collect(toMap(Pair::getKey, Pair::getValue));
    }

    private static Map<String, String> findMatchingPayload(String fieldName, Object payload, String queryExpression, Function<String, Boolean> filter, Map<String, String> results) {

        if (!filter.apply(fieldName))
            return results;

        if (payload instanceof String) {
            if (Utils.hasTagMatch(payload.toString().toLowerCase(),queryExpression.toLowerCase())) {
                results.put(fieldName, payload.toString());
            }
        }

        if (payload instanceof Map) {
            //noinspection unchecked
            ((Map<String,Object>)payload).entrySet().forEach(e->findMatchingPayload((fieldName.length() > 0 ? fieldName + "." : "") + e.getKey(), e.getValue(),queryExpression, filter, results));
        }

        if (payload instanceof Collection) {
            //noinspection unchecked
            ((Collection<Object>)payload).forEach(element->findMatchingPayload(fieldName, element,queryExpression, filter, results));
        }

        return results;
    }

    static String tagMatchPhrase(String source, String expression, String preTag, String postTag){
        if (source == null) {
            return null;
        }
        String sourceLower = source.toLowerCase();
        String expressionLower = expression.toLowerCase();
        int i = 0;
        if ((i = sourceLower.indexOf(expressionLower, i)) >= 0) {
            char[] sourceArray = source.toCharArray();
            char[] preArray = preTag.toCharArray();
            char[] postArray = postTag.toCharArray();
            int oLength = expression.length();
            StringBuilder buf = new StringBuilder (sourceArray.length);
            buf.append (sourceArray, 0, i).append(preArray);
            buf.append (sourceArray, i, oLength).append(postArray);
            i += oLength;
            int j = i;
            // Replace all remaining instances of oldString with newString.
            while ((i = sourceLower.indexOf(expressionLower, i)) > 0) {
                buf.append (sourceArray, j, i - j).append(preArray);
                buf.append (sourceArray, i, oLength).append(postArray);
                i += oLength;
                j = i;
            }
            buf.append (sourceArray, j, sourceArray.length - j);
            source = buf.toString();
            buf.setLength (0);
        }
        return source;
    }

    static HighlightField tagMatch(String fieldName, String value, String queryExpression, String prefixTag, String postTag) {
        String newValue = tagMatchPhrase(value, queryExpression, prefixTag, postTag);  // try phrase first
        if (newValue.length() == value.length())  // phrase not found, fallback to keywords
        {
            String qeLower = queryExpression.toLowerCase();

            String[] terms = StringUtils.split(value, ' ');
            String[] qeLowerTerms = StringUtils.split(qeLower, ' ');

            List<String> resultTerms = Lists.newArrayList();
            for (String term : terms) {
                resultTerms.add(insertTags(term, qeLowerTerms, prefixTag, postTag));
            }
            newValue = StringUtils.join(resultTerms, ' ');
        }
        return new HighlightField(fieldName, new Text[] {new Text (newValue)});
    }

    private static String valueOfField(Object o) {
        if (o instanceof List && ((List)o).size() > 0) {
            //noinspection unchecked
            return ((List<String>) o).get(((List) o).size() - 1);
        }
        return o != null ? o.toString() : null;
    }

    private static String insertTags(String term, String[] queryTerms, String prefixTag, String postTag) {
        for(String queryTerm : queryTerms) {
            term = insertTags(term, queryTerm, prefixTag, postTag);
        }
        return term;
    }

    private static String insertTags(String term, String qeLower, String prefixTag, String postTag) {

        int matchCount = 0;
        StringBuilder sb = new StringBuilder();
        int current = 0;
        for(char c : term.toCharArray()) {
            if (matchCount < qeLower.length() && Character.toLowerCase(c) == Character.toLowerCase(qeLower.charAt(matchCount))) {
                matchCount++;
            } else {
                if (matchCount > 0) {
                    sb.append(term.toCharArray(), current - matchCount, matchCount);
                }
                matchCount = 0;
                sb.append(c);
            }
            if (matchCount == qeLower.length()) {
                sb.append(prefixTag);
                sb.append(term.toCharArray(), current-(matchCount-1), matchCount);
                sb.append(postTag);
                matchCount = 0;
            }
            current++;
        }
        if (matchCount > 0) {
            sb.append(term.toCharArray(), current - matchCount, matchCount);
        }
        return sb.toString();
    }

    private static String trimId(String id) {
        if (id.contains("$"))
            return id.substring(0,id.indexOf("$"));
        return id;
    }

    static boolean isEmptySearchResult(SearchResult result, double lowScoreThreshold) {
        return result.getHits() == 0 || result.getMaxScore() < lowScoreThreshold;
    }

    static List<String> parseAutoCompleteResults(String[] fields, SearchResponse response) {
        return Stream.of(fields).flatMap(f -> Stream.of(response.getHits().hits())
                .map(o -> valueOfField(o.sourceAsMap().get(f)))).collect(toList());
    }


}
