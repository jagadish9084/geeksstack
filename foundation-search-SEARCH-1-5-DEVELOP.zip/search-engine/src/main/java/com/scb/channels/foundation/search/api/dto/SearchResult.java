package com.scb.channels.foundation.search.api.dto;

import java.util.Collection;
import java.util.Map;

public class SearchResult {

    private String searchId;
    private Map<String,Object> aggregate;
    private SearchResultElement[] results;
    private float maxScore;
    private long hits;
    private Collection<String> suggestions;

    public static SearchResult fromModelSearchResult(com.scb.channels.foundation.search.model.SearchResult result) {
        SearchResult r = new SearchResult();
        r.searchId = result.getSearchId();
        r.results = result.getResults().stream().map(SearchResultElement::fromModelResult).toArray(SearchResultElement[]::new);
        r.hits = result.getHits();
        r.maxScore = result.getMaxScore();
        r.aggregate = result.getAggregations();
        r.suggestions = result.getSuggestions();
        return r;
    }

    public String getSearchId() {
        return searchId;
    }

    public Map<String, Object> getAggregate() {
        return aggregate;
    }

    public SearchResultElement[] getResults() {
        return results;
    }

    public float getMaxScore() {
        return maxScore;
    }

    public long getHits() {
        return hits;
    }

    public Collection<String> getSuggestions() {
        return suggestions;
    }
}
