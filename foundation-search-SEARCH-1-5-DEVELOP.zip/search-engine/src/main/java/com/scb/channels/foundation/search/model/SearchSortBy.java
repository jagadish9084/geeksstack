package com.scb.channels.foundation.search.model;

public class SearchSortBy {

    public enum Direction { Asc, Desc }

    private String fieldName;
    private Direction direction;

    public SearchSortBy() { }


    public SearchSortBy(String fieldName, Direction direction) {
        this.fieldName = fieldName;
        this.direction = direction;
    }

    public String getFieldName() {
        return fieldName;
    }

    public Direction getDirection() {
        return direction;
    }
}
