package com.scb.channels.foundation.search.elastic;

import com.scb.channels.foundation.entitlement.dap.DapPolicy;
import org.apache.commons.lang3.StringUtils;
import org.apache.lucene.index.LeafReaderContext;
import org.apache.lucene.search.Explanation;
import org.apache.lucene.util.BytesRef;
import org.elasticsearch.common.lucene.search.function.CombineFunction;
import org.elasticsearch.common.lucene.search.function.LeafScoreFunction;
import org.elasticsearch.common.lucene.search.function.ScoreFunction;
import org.elasticsearch.index.fielddata.AtomicFieldData;
import org.elasticsearch.index.fielddata.IndexFieldData;
import org.elasticsearch.index.fielddata.SortedBinaryDocValues;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class DapSearchFunction extends ScoreFunction {

    private static final Logger logger = LoggerFactory.getLogger(DapSearchFunction.class);

    private static final BytesRef INACTIVE_STATUS = new BytesRef("inactive".getBytes());

    private final DapPolicy dapPolicy;
    private final String userId;
    private final IndexFieldData<?> uidFieldData;
    private final IndexFieldData<?> statusFieldData;
    private final double minScore;

    public DapSearchFunction(DapPolicy dapPolicy, String userId, double minScore, IndexFieldData<?> uidFieldData, IndexFieldData<?> statusFieldData) {
        super(CombineFunction.MULTIPLY);
        this.dapPolicy = dapPolicy;
        this.userId = userId;
        this.minScore = minScore;
        this.uidFieldData = uidFieldData;
        this.statusFieldData = statusFieldData;
    }

    @Override
    public LeafScoreFunction getLeafScoreFunction(LeafReaderContext ctx) throws IOException {

        AtomicFieldData leafData = uidFieldData.load(ctx);

        AtomicFieldData statusLeafData = statusFieldData != null ? statusFieldData.load(ctx) : null;

        final SortedBinaryDocValues uidByteData = leafData.getBytesValues();
        final SortedBinaryDocValues statusByteData = statusLeafData != null ? statusLeafData.getBytesValues() : null;

        final Map<BytesRef,String[]> dapCache = new HashMap<>(10000,1f);
        final Map<BytesRef,String> typeCache = new HashMap<>(100,1f);

        return new LeafScoreFunction() {
            @Override
            public final double score(final int docId, final float subQueryScore) {

                try {

                    if (subQueryScore < minScore) {
                        return 0.0d;
                    }

                    if (statusByteData != null) {
                        statusByteData.setDocument(docId);
                        final BytesRef statusBytes = statusByteData.count() > 0 ? statusByteData.valueAt(0) : null;
                        if (INACTIVE_STATUS.equals(statusBytes)) {
                            return 0.0d;
                        }
                    }

                    uidByteData.setDocument(docId);
                    final BytesRef bytes = uidByteData.valueAt(0);

                    BytesRef type = new BytesRef(bytes.bytes, bytes.offset, indexOf(bytes.bytes, bytes.offset, (byte) '#') - bytes.offset);
                    int idx = indexOf(bytes.bytes, bytes.offset + type.length, (byte) '$');

                    final String[] ts = getDapTopic(new BytesRef(bytes.bytes, idx + 1, (bytes.length - (idx - bytes.offset) - 1)));

                    String tpStr = typeCache.get(type);
                    if (tpStr == null) {
                        tpStr = type.utf8ToString();
                        typeCache.put(type, tpStr);
                    }
                    return dapPolicy.hasAccess(userId, tpStr, ts) ? 1.0d : 0.0d;

                } catch (Exception e) {
                    logger.error(e.getMessage(),e);
                    throw e;
                }

            }

            private int indexOf(byte[] bytes, int start, byte c) {
                for(int i=start;i!=bytes.length;i++) {
                    if (bytes[i] == c)
                        return i;
                }
                return -1;
            }

            @Override
            public Explanation explainScore(int docId, Explanation subQueryScore) throws IOException {
                if (score(docId,0) > 0.0d) {
                    return Explanation.match(1.0f, "data entitlement granted", subQueryScore);
                }
                return Explanation.noMatch("no data entitlement", subQueryScore);
            }

            final String[] getDapTopic(final BytesRef dapStr) {
                String[] dt = dapCache.get(dapStr);
                if (dt != null) {
                    return dt;
                } else {
                    String[] dapSegments = StringUtils.split(dapStr.utf8ToString(), '-');
                    dapCache.put(dapStr, dapSegments);
                    return dapSegments;
                }
            }
        };
    }

    @Override
    public boolean needsScores() {
        return false;
    }

    @Override
    protected boolean doEquals(ScoreFunction other) {
        return other instanceof DapSearchFunction && ((DapSearchFunction) other).dapPolicy.equals(this.dapPolicy);
    }

    @Override
    protected int doHashCode() {
        return dapPolicy.hashCode();
    }
}
