package com.scb.channels.foundation.search.api.dto;

import com.google.common.collect.Maps;

import java.util.Collections;
import java.util.Map;

public class Favourites {

    Map<String,SearchRequest> favourites = Maps.newHashMap();

    public Favourites() { }

    public Favourites(Map<String,SearchRequest> favourites) {
        this.favourites.putAll(favourites);
    }

    public Map<String, SearchRequest> getFavourites() {
        return Collections.unmodifiableMap(favourites);
    }
}
