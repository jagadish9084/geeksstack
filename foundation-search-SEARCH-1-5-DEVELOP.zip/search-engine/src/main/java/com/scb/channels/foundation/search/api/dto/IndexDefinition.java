package com.scb.channels.foundation.search.api.dto;

import java.util.Collections;
import java.util.Map;

public class IndexDefinition {

    private String indexName;
    private String indexType;
    private Map<String,FieldDefinition> fields;

    public String getIndexName() {
        return indexName;
    }

    public String getIndexType() {
        return indexType;
    }

    public Map<String, FieldDefinition> getFields() {
        return fields == null ? Collections.emptyMap() : fields;
    }

}
