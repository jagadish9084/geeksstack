package com.scb.channels.foundation.search.model;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.elasticsearch.common.text.Text;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.histogram.Histogram;
import org.elasticsearch.search.aggregations.bucket.terms.StringTerms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightField;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Stream;

import static com.google.common.collect.Maps.newHashMap;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

public class SearchResult {

    public static final String AGGREGATION_KEY = "agg";

    private String searchId;
    private long hits;
    private float maxScore;
    private List<Result> results;
    private Collection<String> suggestions = Lists.newArrayList();
    private Map<String, Object> aggregations = Maps.newHashMap();

    public SearchResult(long hits, float maxScore, boolean includePayload, Aggregations aggregations, SearchHits searchHits,Function<SearchHit,Map<String,HighlightField>> highlightPostProcessor) {
        this.hits = hits;
        this.maxScore = maxScore;
        if (aggregations != null) {
            this.aggregations.putAll(extractAggregations(aggregations.asMap().get(AGGREGATION_KEY)));
        }
        this.results = Stream.of(searchHits.getHits()).map(h->new Result(
                includePayload ? h.sourceAsMap() : Collections.emptyMap(),
                continuationMarker(h),
                highlights(h,highlightPostProcessor),
                fields(h.sourceAsMap()), h.id())).collect(toList());
    }

    private Map<String, Object> extractAggregations(Aggregation agg) {
        if (agg instanceof Histogram) {
            Histogram hg = (Histogram)agg;
            return fromHistoBuckets(hg.getBuckets());
        }
        if (agg instanceof StringTerms) {
            StringTerms st = (StringTerms)agg;
            return fromTermBuckets(st.getBuckets());
        }

        return Collections.emptyMap();
    }

    private Map<String, Object> fromHistoBuckets(List<Histogram.Bucket> buckets) {
        return buckets.stream().map(b->Pair.of(b.getKeyAsString(), b.getDocCount())).collect(toMap(Pair::getKey, Pair::getValue));
    }

    private Map<String, Object> fromTermBuckets(List<Terms.Bucket> buckets) {
        return buckets.stream().map(b->Pair.of(b.getKeyAsString(), b.getDocCount())).collect(toMap(Pair::getKey, Pair::getValue));
    }

    private SearchResult() {

    }

    public long getHits() {
        return hits;
    }

    public float getMaxScore() {
        return maxScore;
    }

    public List<Result> getResults() {
        return results;
    }

    public String getSearchId() {
        return searchId;
    }

    public Collection<String> getSuggestions() {
        return suggestions;
    }

    public SearchResult updateSearchId(String searchId) {
        SearchResult sr = new SearchResult();
        sr.results = this.results;
        sr.searchId = searchId;
        sr.maxScore = this.maxScore;
        sr.hits = this.hits;
        sr.suggestions = this.suggestions;
        sr.aggregations = this.aggregations;
        return sr;
    }

    private Map<String, Object> fields(Map<String, Object> source) {
        return extractFieldsFromMap(source, newHashMap(), new Stack<>());
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> extractFieldsFromMap(Map<String, Object> source, Map<String, Object> results, Stack<String> prefix) {
        for(String key : source.keySet()) {
            prefix.push(key);
            Object value = source.get(key);
            if (value instanceof Map) {
                extractFieldsFromMap((Map<String, Object>)value,results,prefix);
            } else {
                results.put(StringUtils.join(prefix, "."), value);
            }
            prefix.pop();
        }
        return results;
    }

    private String[] continuationMarker(SearchHit hit) {
        return Stream.of(hit.sortValues()).map(o->o==null?"":o).map(Object::toString).toArray(String[]::new);
    }

    private Map<String,List<String>> highlights(SearchHit h, Function<SearchHit,Map<String,HighlightField>> highlightPostProcessor) {

        Map<String,HighlightField> merged = Maps.newHashMap(h.getHighlightFields());
        if (highlightPostProcessor != null) {
            merged.putAll(highlightPostProcessor.apply(h));
        }
        Stream<Map.Entry<String,HighlightField>> fields = merged.entrySet().stream();
        return fields
                .filter(e->!e.getKey().endsWith(".keyword"))
                .map(e-> Pair.of(e.getKey(),
                        Stream.of(e.getValue().getFragments()).map(Text::string).collect(toList()))).collect(toMap(Pair::getKey, Pair::getValue));
    }

    public SearchResult withSuggestions(Collection<String> suggestions) {
        SearchResult sr = new SearchResult();
        sr.hits = this.hits;
        sr.results = this.results;
        sr.maxScore = this.maxScore;
        sr.searchId = this.searchId;
        sr.aggregations = this.aggregations;

        if (this.suggestions == null) {
            sr.suggestions = suggestions;
        } else {
            sr.suggestions = Lists.newArrayList();
            sr.suggestions.addAll(suggestions);
            sr.suggestions.addAll(this.suggestions);
        }
        return sr;
    }

    public SearchResult merge(SearchResult aggregationResults) {
        if (aggregationResults == null) {
            return this;
        }
        this.results.addAll(aggregationResults.results);
        this.suggestions.addAll(aggregationResults.suggestions);
        this.aggregations.putAll(aggregationResults.aggregations);
        return this;
    }

    public Map<String,Object> getAggregations() {
        return aggregations;
    }
}
