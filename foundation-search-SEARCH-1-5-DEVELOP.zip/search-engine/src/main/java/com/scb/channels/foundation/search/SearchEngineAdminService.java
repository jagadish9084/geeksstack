package com.scb.channels.foundation.search;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Sets;
import com.scb.channels.foundation.search.model.IndexFieldDefinition;

import java.io.IOException;
import java.util.Map;
import java.util.Set;

public interface SearchEngineAdminService {

    Map<String, IndexFieldDefinition> DEFAULT_FIELDS = ImmutableMap.<String,IndexFieldDefinition>builder()
            .put("identifier", IndexFieldDefinition.TEXT_TRIGRAM_ANALYSED)
            .put("timestamp", IndexFieldDefinition.DATE)
            .put("entityType", IndexFieldDefinition.TEXT_WITH_FIELD_DATA_NOT_ALL)
            .put("status",IndexFieldDefinition.TEXT_WITH_FIELD_DATA_NOT_ALL)
            .put("applicationId",IndexFieldDefinition.TEXT_NOT_ALL)
            .put("description",IndexFieldDefinition.TEXT_SUGGEST_ANALYSED)
            .put("md5hash", IndexFieldDefinition.TEXT_WITH_FIELD_DATA_NOT_ALL)
            .build();

    String TRIGRAM_ANALYZER = "contains_analyzer";

    String SUGGESTS_ANALYZER = "suggests_analyzer";

    Set<String> DEFAULT_SEARCH_FIELDS = Sets.newHashSet("identifier","description");

    void defineIndex(String indexName, String indexType, Map<String,IndexFieldDefinition> fields);

    Map<String, Object> getIndexMappings(String indexName, String indexType) throws IOException;

    String getStatistics();

    String getSearchShardStatistics();

    boolean indexExists(String indexName, String indexType);
}
