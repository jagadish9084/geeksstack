package com.scb.channels.foundation.search.model;

public class SearchEvent {

    private String searchId;
    private NewSearchRequest searchDefinition;
    private String type;

    public SearchEvent() { }

    public SearchEvent(String searchId, NewSearchRequest searchDefinition, String type) {
        this.searchId = searchId;
        this.searchDefinition = searchDefinition;
        this.type = type;
    }

    public String getSearchId() {
        return searchId;
    }

    public String getType() {
        return type;
    }

    public NewSearchRequest getSearchDefinition() {
        return searchDefinition;
    }
}
