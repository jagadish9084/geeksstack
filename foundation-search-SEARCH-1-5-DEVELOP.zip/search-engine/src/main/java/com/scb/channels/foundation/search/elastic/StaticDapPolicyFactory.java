package com.scb.channels.foundation.search.elastic;

import com.scb.channels.foundation.entitlement.dap.DapPolicyFactory;

public class StaticDapPolicyFactory {

    static DapPolicyFactory INSTANCE ;

    public static void init(DapPolicyFactory delegate) {
        INSTANCE = delegate;
    }
}
