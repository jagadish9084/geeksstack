package com.scb.channels.foundation.search.impl;

import com.google.common.collect.Sets;
import com.scb.channels.foundation.search.SearchEngineContext;
import com.scb.channels.foundation.search.api.dto.SearchRequest;
import com.scb.channels.foundation.search.elastic.DapSearchScoreBuilder;
import com.scb.channels.foundation.search.elastic.DapTermSuggestionBuilder;
import com.scb.channels.foundation.search.model.*;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.unit.Fuzziness;
import org.elasticsearch.common.util.ArrayUtils;
import org.elasticsearch.index.query.*;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.support.ValueType;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.elasticsearch.search.suggest.SortBy;
import org.elasticsearch.search.suggest.SuggestBuilder;
import org.elasticsearch.search.suggest.SuggestBuilders;
import org.elasticsearch.search.suggest.SuggestionBuilder;
import org.elasticsearch.search.suggest.term.TermSuggestionBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Stream;

import static com.scb.channels.foundation.search.SearchEngineService.SUGGESTER_FIELD;
import static com.scb.channels.foundation.search.elastic.DapSearchPlugin.hasDapPlugin;
import static com.scb.channels.foundation.search.impl.Utils.*;
import static java.util.stream.Collectors.toSet;

class SearchBuilders {

    private static final Logger logger = LoggerFactory.getLogger(SearchBuilders.class);

    private static final float MIN_SCORE = 0.00001f;
    static final String UID_FIELD = "_uid";
    private static final String SCORE_FIELD = "_score";
    private static final String SUGGEST_TAG = "suggest";

    static SearchRequestBuilder quickSearchRequestBuilder(Client client, SearchEngineContext searchEngineContext, String expression, boolean includePayload, int limit, String[] searchFields, String[] sourceFields) {

        String[] f2 = Arrays.copyOf(sourceFields,sourceFields.length+1);
        f2[f2.length-1] = UID_FIELD;

        QueryBuilder query = getQueryBuilder(expression, searchFields, new String[]{});

        SearchRequestBuilder result = client.prepareSearch().
                setMinScore(MIN_SCORE).
                highlighter(new HighlightBuilder().field("*").requireFieldMatch(false)).
                setSearchType(SearchType.DFS_QUERY_THEN_FETCH).
                addSort(SCORE_FIELD, SortOrder.DESC).
                addSort(UID_FIELD, SortOrder.ASC).
                setSize(limit).
                setQuery(searchEngineContext != null && hasDapPlugin() ?
                        QueryBuilders.functionScoreQuery( query, DapSearchScoreBuilder.dapPolicy(searchEngineContext, MIN_SCORE)) :
                        query);

        if (includePayload) {
            result.setFetchSource(true);
        } else {
            result.setFetchSource(f2, null);
        }

        logger.info("Executing quick search query with builder: " + result);

        return result;
    }

    static SearchRequestBuilder searchRequestBuilder(Client client, SearchEngineContext searchEngineContext, NewSearchRequest request, String[] searchFields, String[] sourceFields) {

        QueryBuilder query = getQueryBuilder(request.getExpression(), searchFields, request.getFields());

        SearchRequestBuilder builder = client.prepareSearch().
                setMinScore(MIN_SCORE).
                highlighter(new HighlightBuilder().field("payload.*").field("identifier").field("description").requireFieldMatch(false)).
                setSearchType(SearchType.DFS_QUERY_THEN_FETCH).
                setSize(request.getLimit()).
                setQuery(searchEngineContext != null && hasDapPlugin() ?
                        QueryBuilders.functionScoreQuery(
                                query,
                                DapSearchScoreBuilder.dapPolicy(searchEngineContext, MIN_SCORE)
                        ) : query);

        if (request.getFilterExpression() != null && request.getFilterExpression().trim().length() > 0) {
            builder.setPostFilter(
                    QueryBuilders.queryStringQuery(request.getFilterExpression())
                            .useDisMax(false)
                            .defaultField("identifier")
                            .useAllFields(false)
                            .fuzziness(Fuzziness.ZERO)
                            .fuzzyMaxExpansions(0)
                            .maxDeterminizedStates(100)
                            .defaultOperator(Operator.AND));
        }

        if (request.isIncludePayload()) {
            builder.setFetchSource(true);
        } else {
            builder.setFetchSource(getFetchFields(sourceFields), null);
        }

        if (request.getSortBy() != null) {
            Stream.of(request.getSortBy()).forEach(s->builder.addSort(s.getFieldName(),direction(s)));
        }

        return builder.
                addSort(SCORE_FIELD, SortOrder.DESC).
                addSort(UID_FIELD, SortOrder.ASC);
    }

    static SearchRequestBuilder aggregationRequestBuilder(SearchRequestBuilder builder, NewSearchRequest request) {
        if (request.getAggregateOn() != null && request.getAggregateOn().length > 0) {
            return builder.addAggregation(aggregationBuilder(request.getAggregateOn()));
        }
        return builder;
    }

    static Collection<String> parseSuggestResponse(String partial, SearchResponse response) {

        if (response.getSuggest() == null || response.getSuggest().size() == 0) {
            return Collections.emptyList();
        }

        Set<Set<String>> sets = response.getSuggest()
                .getSuggestion(SUGGEST_TAG).getEntries().stream()
                .map(o -> o.getOptions().isEmpty() ?
                        Collections.singleton(o.getText().string()) :
                        o.getOptions().stream().map(oo -> oo.getText().toString()).collect(toSet())).collect(toSet());

        @SuppressWarnings("unchecked")
        Set<List<String>> product = Sets.cartesianProduct(sets.toArray(new Set[sets.size()]));
        return product.stream().map(p -> StringUtils.join(p, " ")).filter(n -> !n.equalsIgnoreCase(partial)).collect(toSet());

    }

    static SearchRequestBuilder suggestRequestBuilder(Client client, SearchEngineContext searchEngineContext, PredictionType predictionType, String partial, String filterExpression, String[] fields, int limit) {

        SearchRequestBuilder builder = client.prepareSearch().setMinScore(MIN_SCORE).setSize(limit);

        if (predictionType.equals(PredictionType.DidYouMean)) {
            builder.suggest(new SuggestBuilder()
                    .setGlobalText(partial)
                    .addSuggestion(SUGGEST_TAG, didYouMeanBuilder(SUGGESTER_FIELD, searchEngineContext)));
        } else {

            QueryBuilder termQry = QueryBuilders.multiMatchQuery(partial, fields).type(MultiMatchQueryBuilder.Type.PHRASE_PREFIX).
                    operator(Operator.OR).
                    fuzziness(Fuzziness.ZERO).
                    lenient(true).prefixLength(3);

            if (filterExpression != null && filterExpression.trim().length() > 0) {
                builder.setPostFilter(QueryBuilders.queryStringQuery(filterExpression));
            }
            builder.setFetchSource(fields,null);
            builder.storedFields(fields).
                    setQuery(searchEngineContext != null && hasDapPlugin() ?
                            QueryBuilders.functionScoreQuery(
                                    termQry,
                                    DapSearchScoreBuilder.dapPolicy(searchEngineContext, MIN_SCORE)) :
                            termQry);
        }
        return builder;
    }

    private static SuggestionBuilder didYouMeanBuilder(String field, SearchEngineContext context) {

        TermSuggestionBuilder builder = context != null && hasDapPlugin() ? new DapTermSuggestionBuilder(field, context) : SuggestBuilders.termSuggestion(field);
        return builder.size(5)
                .accuracy(0.3f)
                .shardSize(10)
                .suggestMode(TermSuggestionBuilder.SuggestMode.MISSING)
                .sort(SortBy.FREQUENCY)
                ;
    }

    private static AggregationBuilder aggregationBuilder(SearchAggregation[] aggregateOn) {

        SearchAggregation sa = aggregateOn[0];

        String nickname = SearchResult.AGGREGATION_KEY;

        switch(sa.getAggregationType()) {
            case Histogram: return AggregationBuilders.histogram(nickname).field(sa.getField()).interval(sa.getInterval());
            case Max: return AggregationBuilders.max(nickname).field(sa.getField()).valueType(
                    SearchAggregation.AggregationReductionType.Date.equals(sa.getAggregationReductionType()) ? ValueType.DATE : ValueType.DOUBLE);
            case Min: return AggregationBuilders.min(nickname).field(sa.getField()).valueType(
                    SearchAggregation.AggregationReductionType.Date.equals(sa.getAggregationReductionType()) ? ValueType.DATE : ValueType.DOUBLE);
            case Average: return AggregationBuilders.avg(nickname).field(sa.getField()).valueType(
                    SearchAggregation.AggregationReductionType.Date.equals(sa.getAggregationReductionType()) ? ValueType.DATE : ValueType.DOUBLE);
            case Sum: return AggregationBuilders.sum(nickname).field(sa.getField()).valueType(
                    SearchAggregation.AggregationReductionType.Date.equals(sa.getAggregationReductionType()) ? ValueType.DATE : ValueType.DOUBLE);
            case Count: return AggregationBuilders.terms(nickname).field(sa.getField()).valueType(ValueType.STRING);
        }

        throw new IllegalArgumentException();

    }

    private static QueryBuilder getQueryBuilder(String expression, String[] fields, String[] requestFields) {

        boolean queryExpression = isQueryExpression(expression);

        DisMaxQueryBuilder disMax = QueryBuilders.disMaxQuery();
        Stream.of(fields).filter(f->!f.equals("_all")).forEach(f -> disMax.add(QueryBuilders.wildcardQuery(f,expression)));

        MultiMatchQueryBuilder multiMatch = QueryBuilders.
                multiMatchQuery(expression,fields).
                type(MultiMatchQueryBuilder.Type.CROSS_FIELDS).
                prefixLength(1).
                maxExpansions(20).
                operator(Operator.AND);
        boostFields(fields, multiMatch);

        MultiMatchQueryBuilder phrasePrefixMatch = QueryBuilders.
                multiMatchQuery(expression,fields).
                type(MultiMatchQueryBuilder.Type.PHRASE_PREFIX).
                prefixLength(1).
                maxExpansions(20).
                operator(Operator.AND);
        boostFields(fields, phrasePrefixMatch);


        SimpleQueryStringBuilder simpleQuery = QueryBuilders.simpleQueryStringQuery(expression).defaultOperator(Operator.AND).lenient(true);
        for(String field: requestFields) {
            simpleQuery = simpleQuery.field(field);
        }

        boolean singleTerm = expression.trim().indexOf(' ') == -1;

        return queryExpression ?
                simpleQuery :
                isSuffixWildcard(expression) ?
                        disMax :
                        singleTerm ? phrasePrefixMatch : multiMatch;
    }


    private static MultiMatchQueryBuilder boostFields(String[] fields, MultiMatchQueryBuilder builder) {
        for(String field : fields) {
            builder.field(field, MandatoryIndexFields.boostForField(field));
        }
        return builder;
    }

}
