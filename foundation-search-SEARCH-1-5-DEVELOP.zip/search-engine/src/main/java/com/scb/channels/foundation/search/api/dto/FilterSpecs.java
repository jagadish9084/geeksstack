package com.scb.channels.foundation.search.api.dto;

import com.google.common.collect.Lists;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

public class FilterSpecs {

    Collection<FilterSpec> filters = Lists.newArrayList();

    public FilterSpecs() { }

    public FilterSpecs(Collection<FilterSpec> filters) {
        this.filters.addAll(filters);
    }

    public Collection<FilterSpec> getFilters() {
        return filters == null ? Collections.emptyList() : filters;
    }

    public static FilterSpecs of(FilterSpec... specs) {
        return new FilterSpecs(Arrays.asList(specs));
    }

}
