package com.scb.channels.foundation.search.impl;

import com.scb.channels.foundation.objectstore.ObjectStoreProvider;
import com.scb.channels.foundation.search.model.*;
import org.elasticsearch.action.search.SearchResponse;
import org.springframework.context.annotation.Scope;

import java.util.Collection;
import java.util.Map;
import java.util.UUID;

@Scope("singleton")
public class SearchEventServiceImpl implements SearchEventService {

    private final Map<String, SearchEvent> searchLog;

    public SearchEventServiceImpl(ObjectStoreProvider objectStoreProvider) {
        this.searchLog = objectStoreProvider.getObjectStore("SearchLog");
    }

    @Override
    public String logQuickSearch(String expression, int limit, SearchResponse response) {
        String searchId = UUID.randomUUID().toString();
        searchLog.put(searchId, new SearchEvent(searchId, new NewSearchRequest(expression, "", false, false, new String[0], new String[0], new SearchAggregation[0], new SearchSortBy[0], limit), "Quick"));
        return searchId;
    }

    @Override
    public String logSearch(NewSearchRequest newSearchRequest, SearchResponse response) {
        String searchId = UUID.randomUUID().toString();
        searchLog.put(searchId, new SearchEvent(searchId, newSearchRequest, "New"));
        return searchId;
    }

    @Override
    public String logSearchContinuation(ContinueSearchRequest continueSearchRequest, SearchResponse response) {
        String searchId = UUID.randomUUID().toString();
        searchLog.put(searchId, new SearchEvent(searchId, continueSearchRequest.getNewSearchRequest(), "Continuation"));
        return searchId;
    }

    @Override
    public void logIngestation(Collection<IndexObject> indexObjects) {

    }

    @Override
    public SearchEvent findSearch(String searchId) {
        return searchLog.get(searchId);
    }

}
