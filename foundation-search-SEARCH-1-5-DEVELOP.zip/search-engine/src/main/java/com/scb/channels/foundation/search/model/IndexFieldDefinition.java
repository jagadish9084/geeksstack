package com.scb.channels.foundation.search.model;

import com.google.common.collect.Maps;
import com.scb.channels.foundation.search.api.dto.FieldDefinition;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Map;
import java.util.stream.Collectors;

import static com.scb.channels.foundation.search.SearchEngineAdminService.SUGGESTS_ANALYZER;
import static com.scb.channels.foundation.search.SearchEngineAdminService.TRIGRAM_ANALYZER;

public class IndexFieldDefinition {

    public static final IndexFieldDefinition TEXT = new IndexFieldDefinition(false,null,"text",false);
    public static final IndexFieldDefinition TEXT_NOT_ALL = new IndexFieldDefinition(false,null,"text",true);
    public static final IndexFieldDefinition TEXT_TRIGRAM_ANALYSED = new IndexFieldDefinition(false, TRIGRAM_ANALYZER, "text",false);
    public static final IndexFieldDefinition TEXT_SUGGEST_ANALYSED = new IndexFieldDefinition(false, SUGGESTS_ANALYZER, "text",false);
    public static final IndexFieldDefinition TEXT_WITH_FIELD_DATA = new IndexFieldDefinition(true,null,"text",false);
    public static final IndexFieldDefinition TEXT_WITH_FIELD_DATA_NOT_ALL = new IndexFieldDefinition(true,null,"text",true);

    public static final IndexFieldDefinition DATE = new IndexFieldDefinition(false,null,"date",false);
    public static final IndexFieldDefinition LONG = new IndexFieldDefinition(false,null,"long",false);
    public static final IndexFieldDefinition DOUBLE = new IndexFieldDefinition(false,null,"double",false);


    private boolean fieldData;
    private String analyseWith;
    private String dataType;
    private boolean excludeFromAll;

    private Map<String,IndexFieldDefinition> children = Maps.newHashMap();

    public IndexFieldDefinition(FieldDefinition dto) {
        this.fieldData = dto.getDataType().equals(FieldDefinition.DataType.Text) && dto.isSortable();
        this.dataType = dto.getDataType().name().toLowerCase();
        this.children = dto.getChildren().entrySet().stream().map(e-> Pair.of(e.getKey(), new IndexFieldDefinition(e.getValue()))).collect(Collectors.toMap(Pair::getKey, Pair::getValue));
        this.analyseWith = dto.getAnalyser();
    }

    public IndexFieldDefinition(boolean fieldData, String analyse, String dataType, boolean excludeFromAll) {
        this.fieldData = fieldData;
        this.analyseWith = analyse;
        this.dataType = dataType;
        this.excludeFromAll = excludeFromAll;
    }

    public boolean isFieldData() {
        return fieldData;
    }

    public String getAnalyseWith() {
        return analyseWith;
    }

    public String getDataType() {
        return dataType;
    }

    public boolean hasAnalyser() {
        return analyseWith != null && analyseWith.trim().length() > 0;
    }

    public Map<String, IndexFieldDefinition> getChildren() {
        return children;
    }

    public boolean excludeFromAll() {
        return excludeFromAll;
    }
}
