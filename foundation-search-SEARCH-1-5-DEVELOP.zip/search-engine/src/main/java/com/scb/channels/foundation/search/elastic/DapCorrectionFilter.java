package com.scb.channels.foundation.search.elastic;

import com.scb.channels.foundation.entitlement.dap.DapPolicy;
import org.apache.lucene.index.LeafReaderContext;
import org.apache.lucene.queries.CustomScoreProvider;
import org.apache.lucene.queries.CustomScoreQuery;
import org.apache.lucene.queries.TermsQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.util.BytesRef;
import org.elasticsearch.common.lucene.search.function.LeafScoreFunction;
import org.elasticsearch.index.fielddata.IndexFieldData;
import org.elasticsearch.index.mapper.MappedFieldType;
import org.elasticsearch.index.query.QueryShardContext;

import java.io.IOException;

public class DapCorrectionFilter {

    public static boolean permitTerm(IndexSearcher searcher, QueryShardContext shardContext, String field, BytesRef term, String userId, DapPolicy dapPolicy) {
        try {
            MappedFieldType fieldType = shardContext.getMapperService().fullName("_uid");
            IndexFieldData<?> ifd = shardContext.getForField(fieldType);

            MappedFieldType statusFieldType = shardContext.getMapperService().fullName("status");
            IndexFieldData<?> statusIfd = null;
            if (statusFieldType != null) {
                statusIfd = shardContext.getForField(statusFieldType);
            }

            DapSearchFunction function = new DapSearchFunction(dapPolicy, userId, 0.0d, ifd, statusIfd);

            Query query = new CustomScoreQuery(new TermsQuery(field, term)) {
                @Override
                protected CustomScoreProvider getCustomScoreProvider(LeafReaderContext context) throws IOException {
                    LeafScoreFunction leafScoreFunction = function.getLeafScoreFunction(context);
                    return new CustomScoreProvider(context) {
                        @Override
                        public float customScore(int doc, float subQueryScore, float valSrcScore) throws IOException {
                            double score = leafScoreFunction.score(doc, subQueryScore);
                            return score == 0.0d ? 0.0f : 10.0f;
                        }
                    };
                }
            };
            return searcher.search(query, 1).getMaxScore() > 0.001f;
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

}
