package com.scb.channels.foundation.search.api.resource;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.scb.channels.foundation.api.dto.recon.ReconHeaderRequest;
import com.scb.channels.foundation.api.dto.recon.ReconHeaderResponse;

/**
 * Created by 1562315 on 5/15/2017.
 */

public interface ReconResource {

    public ReconHeaderResponse resolveReconHeaders(ReconHeaderRequest request) throws JsonProcessingException;
}
