package com.scb.channels.foundation.search.model;

import org.elasticsearch.action.search.SearchResponse;

import java.util.Collection;

public interface SearchEventService {

    String logQuickSearch(String expression, int limit, SearchResponse response);
    String logSearch(NewSearchRequest newSearchRequest, SearchResponse response);
    String logSearchContinuation(ContinueSearchRequest continueSearchRequest, SearchResponse response);

    void logIngestation(Collection<IndexObject> indexObjects);

    SearchEvent findSearch(String searchId);
}
