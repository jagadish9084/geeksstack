package com.scb.channels.foundation.search.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.scb.channels.foundation.search.elastic.DapSearchPlugin;
import com.scb.channels.foundation.util.Sockets;
import io.advantageous.config.Config;
import io.advantageous.config.ConfigLoader;
import org.elasticsearch.bootstrap.BootstrapCheck;
import org.elasticsearch.cli.Terminal;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.BoundTransportAddress;
import org.elasticsearch.env.Environment;
import org.elasticsearch.node.InternalSettingsPreparer;
import org.elasticsearch.node.Node;
import org.elasticsearch.node.NodeValidationException;
import org.elasticsearch.plugins.Plugin;
import org.elasticsearch.script.mustache.MustachePlugin;
import org.elasticsearch.transport.Netty4Plugin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.Level;
import org.springframework.util.StringUtils;

import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EmbeddedElasticSearchProvider implements ElasticSearchProvider {

    private static final Logger logger = LoggerFactory.getLogger(EmbeddedElasticSearchProvider.class);

    private static final String LOGGER_LEVEL = "logger.level";
    private static final String PATH_HOME = "path.home";
    private static final String TRANSPORT_TYPE = "transport.type";
    private static final String CLUSTER_NAME = "cluster.name";

    private static final String DISCOVERY_ZEN_PING_UNICAST_HOSTS = "discovery.zen.ping.unicast.hosts";
    private static final String DISCOVERY_ZEN_MINIMUM_MASTER_NODES = "discovery.zen.minimum_master_nodes";
    private static final String NETWORK_HOST = "network.host";
    private static final String HTTP_ENABLED = "http.enabled";
    private static final String NODE_NAME = "node.name";

    private static final String TCP_PORT = "transport.tcp.port";
    private static final String NODE_MASTER = "node.master";
    private static final String NODE_DATA = "node.data";
    private static final String NODE_INGEST = "node.ingest";

    private static final String NODE_MAX_LOCAL_STORAGE_NODES = "node.max_local_storage_nodes";
    private static final String THREAD_POOL_BULK_SIZE = "thread_pool.bulk.size";
    private static final String THREAD_POOL_BULK_QUEUE_SIZE = "thread_pool.bulk.queue_size";
    private static final String MAX_CLAUSE_COUNT = "indices.query.bool.max_clause_count";
    private static final String NODE_ATTR = "node.attr";
    private static final String SHARD_AWARENESS_ATTRIBUTES = "cluster.routing.allocation.awareness.attributes";

    private final Node node;

    public EmbeddedElasticSearchProvider(Config config, String clusterName, String rootHost, String nodeName, boolean isMaster) throws NodeValidationException, UnknownHostException {
        int retries = 0;
        Node tempNode;
        do {
            tempNode = initNode(config, clusterName, rootHost, nodeName, isMaster);
            try {
                tempNode.start();
                break;
            } catch (Exception e) {
                logger.error("Error initialising ES, trying again (port clash?), error: " + e.getMessage(),e);
                tempNode = null;
            }
        } while (retries++ < 3);
        if (tempNode == null) {
            throw new RuntimeException("Unable to start, check logs for errors.");
        }
        this.node = tempNode;
    }

    private static boolean isMaster(Config config, boolean isMaster) {
        if (!StringUtils.isEmpty(System.getProperty("com.scb.channels.foundation.es.root-host"))
                || config.getString("search.elastic.cluster_hosts").equalsIgnoreCase("localhost")) {
            return isMaster;
        }
        else {
            String[] hosts = config.getString("search.elastic.cluster_hosts").split(",");

            return Stream.of(hosts).anyMatch(ip -> {
                try {
                    return ip.equalsIgnoreCase(Inet4Address.getLocalHost().getHostAddress());
                } catch (UnknownHostException e) {
                    throw new RuntimeException("Unable to get local IP while checking master eligibility", e);
                }
            });
        }
    }

    @Override
    public Client getClient() {
        return this.node.client();
    }

    private static Environment initialEnvironment(Config config, boolean foreground, String clusterName, String rootHost, String nodeName, boolean isMaster, Map<String, String> esSettings) throws UnknownHostException {

        logger.info("Initialising cluster " + clusterName + " with root " + rootHost + ", node name " + nodeName + ", is master node: " + isMaster);

        Terminal terminal = foreground?Terminal.DEFAULT:null;

        Settings.Builder builder = Settings.builder();

        esSettings.put(CLUSTER_NAME, clusterName);
        esSettings.put(NODE_NAME, nodeName);
 
        esSettings.put(NODE_MASTER, String.valueOf(isMaster(config, isMaster)));
        esSettings.put(NODE_DATA, String.valueOf(true));
        esSettings.put(NODE_INGEST, String.valueOf(isMaster(config, isMaster)));

        esSettings.put(TCP_PORT, String.valueOf(Sockets.findNextAvailableTcpPort(
                config.getInt("search.elastic.startport"),
                config.getInt("search.elastic.endport"))));

        esSettings.put(DISCOVERY_ZEN_PING_UNICAST_HOSTS, config.getString("search.elastic.cluster_hosts"));
        esSettings.put(DISCOVERY_ZEN_MINIMUM_MASTER_NODES, String.valueOf(config.getInt("search.elastic.minimum_masters")));
        esSettings.put(LOGGER_LEVEL, Level.INFO.name());

        esSettings.put(PATH_HOME,config.getString("search.elastic.home_dir"));

        esSettings.put(TRANSPORT_TYPE, Netty4Plugin.NETTY_TRANSPORT_NAME);
        esSettings.put(NETWORK_HOST, (config.getString("search.elastic.network.host").isEmpty()) ?
                                Inet4Address.getLocalHost().getHostAddress():
                                config.getString("search.elastic.network.host") );
        esSettings.put(HTTP_ENABLED, String.valueOf(false));

        esSettings.put(NODE_MAX_LOCAL_STORAGE_NODES, String.valueOf(5));
        esSettings.put(THREAD_POOL_BULK_SIZE, String.valueOf(Runtime.getRuntime().availableProcessors()));
        esSettings.put(THREAD_POOL_BULK_QUEUE_SIZE, String.valueOf(16 * Runtime.getRuntime().availableProcessors()));
        esSettings.put(MAX_CLAUSE_COUNT, String.valueOf(config.getInt("search.elastic.max_clause_count")));
        setNodeAttributes(esSettings, config);

        logger.info("ElasticSearch connection Settings, " + NETWORK_HOST + ":{}, " + TCP_PORT + ":{} ", esSettings.get(NETWORK_HOST), esSettings.get(TCP_PORT));

        return InternalSettingsPreparer.prepareEnvironment(builder.build(), terminal, esSettings);
    }

    private Node initNode(Config config, String clusterName, String rootHost, String nodeName, boolean isMaster) throws UnknownHostException {
        Environment environment = initialEnvironment(config, false, clusterName, rootHost, nodeName, isMaster, Maps.newHashMap());

        List<Class<? extends Plugin>> plugins = Lists.newArrayList(Arrays.asList(Netty4Plugin.class, MustachePlugin.class ));
        if (DapSearchPlugin.hasDapPlugin()) {
            plugins.add(DapSearchPlugin.class);
        }
        return new Node(environment, plugins) {
            protected void validateNodeBeforeAcceptingRequests(Settings settings, BoundTransportAddress boundTransportAddress, List<BootstrapCheck> checks) throws NodeValidationException { }
        };
    }

    private static Map<String, String> setNodeAttributes(Map<String, String> esSettings, Config config) {

        String[] nodeAttributePair = config.getString("search.elastic.node_attr_values").split(",");
        List<String> attribute_names = new ArrayList<>();
        for(String pair: nodeAttributePair) {
            String[] key_value = pair.split(":");
            esSettings.put(NODE_ATTR+"."+key_value[0], key_value[1]);
            attribute_names.add(key_value[0]);
        }
        if(attribute_names.size()>0) {
            esSettings.put(SHARD_AWARENESS_ATTRIBUTES, attribute_names.stream().collect(Collectors.joining(",")));
        }

        return esSettings;
    }

}
