package com.scb.channels.foundation.search;

import com.scb.channels.foundation.api.dto.recon.ReconHeaderRequest;
import com.scb.channels.foundation.api.dto.recon.ReconHeaderResponse;
import com.scb.channels.foundation.search.model.*;

import java.util.Collection;
import java.util.Map;

public interface SearchEngineService {

    String SUGGESTER_FIELD = "_suggest";

    Map<String, String> ingest(Collection<IndexObject> indexObjects, SearchEngineContext searchEngineContext);

    SearchResult newSearch(NewSearchRequest newSearchRequest, SearchEngineContext searchEngineContext);

    SearchResult continueSearch(ContinueSearchRequest continueSearchRequest, SearchEngineContext searchEngineContext);

    SearchResult quickSearch(String expression, boolean includePayload, int resultLimit, SearchEngineContext searchEngineContext);

    SearchResult quickSearch(String expression, int resultLimit, SearchEngineContext searchEngineContext);

    ReconHeaderResponse compareReconHeaders(ReconHeaderRequest request, SearchEngineContext searchEngineContext);

    @SuppressWarnings("unchecked")
    Collection<String> predict(PredictionType predictionType, String partial, int resultLimit, String[] fields, SearchEngineContext searchEngineContext);

    Collection<String> predict(PredictionType predictionType, String partial, String filterExpression, int resultLimit, String[] field, SearchEngineContext searchEngineContext);

    void addFavourite(String searchId, SearchEngineContext searchEngineContext);

    void deleteFavourite(String searchId, SearchEngineContext searchEngineContext);

    Collection<SearchEvent> findFavourites(Integer searchLimit, SearchEngineContext searchEngineContext);
}