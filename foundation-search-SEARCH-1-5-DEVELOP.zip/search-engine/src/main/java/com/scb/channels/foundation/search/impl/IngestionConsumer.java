package com.scb.channels.foundation.search.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.channels.foundation.search.SearchEngineContext;
import com.scb.channels.foundation.search.SearchEngineService;
import com.scb.channels.foundation.search.api.dto.IngestEnvelope;
import com.scb.channels.foundation.search.model.IndexObject;
import io.advantageous.config.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;

import java.util.Collections;

public class IngestionConsumer {

    private static final Logger logger = LoggerFactory.getLogger(IngestionConsumer.class);

    private final SearchEngineService searchEngineService;
    private final Config config;

    private ObjectMapper objectMapper;

    public IngestionConsumer(SearchEngineService searchEngineService, Config config,
                             ObjectMapper objectMapper) {
        this.searchEngineService = searchEngineService;
        this.config = config;
        this.objectMapper = objectMapper;
    }

    @KafkaListener(topics = "search_engine.t")
    public void onMessage(String message) {
        try {
            IngestEnvelope envelope = objectMapper.readValue(message, IngestEnvelope.class);
            searchEngineService.ingest(Collections.singletonList(IndexObject.fromDto(envelope, objectMapper)), createSearchContext() );
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
            throw new RuntimeException(e.getMessage(),e);
        }
    }

    private SearchEngineContext createSearchContext() {
        return new SearchEngineContext(
                config.getString("search.subscription.user"),
                config.getString("search.subscription.dappolicy")
        );
    }

}
