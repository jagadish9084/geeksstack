package com.scb.channels.foundation.search.api.dto;

import com.scb.channels.foundation.util.ReflectionBuilder;

import java.util.Map;

public class SearchRequest {

    public enum AggregateFun { Count, Histogram, Max, Min, Sum, Avg }

    private String expression;

    private int resultSetLimit;
    private boolean includePayload;
    private String[] fields;
    private SortBy[] sortBy;

    private Map<String,AggregateFun> aggregateOn;
    private String filterExpression;
    private FilterSpecs filterSpecs;
    private boolean includeDidYouMean;
    private String[] suggestionFields;


    public interface SearchRequestBuilder {

        SearchRequestBuilder expression(String expression);

        SearchRequestBuilder resultSetLimit(int resultSetLimit);

        SearchRequestBuilder includePayload(boolean includePayload);

        SearchRequestBuilder fields(String[] fields);

        SearchRequestBuilder suggestionFields(String[] fields);

        SearchRequestBuilder aggregateOn(Map<String,AggregateFun> aggregateOn);

        SearchRequestBuilder sortBy(SortBy[] sortBy);

        SearchRequestBuilder filterExpression(String filterExpression);

        SearchRequestBuilder filterSpecs(FilterSpecs filterExpression);

        SearchRequestBuilder includeDidYouMean(boolean includeDidYouMean);

        SearchRequest build();
    }

    public static SearchRequestBuilder builder() {
        return ReflectionBuilder.builderFor(SearchRequestBuilder.class);
    }

    public SearchRequest() { }

    public SearchRequest(String expression, int resultSetLimit) {
        this.resultSetLimit = resultSetLimit;
        this.expression = expression;
    }

    public String getExpression() {
        return expression;
    }

    public Map<String, AggregateFun> getAggregateOn() {
        return aggregateOn;
    }

    public int getResultSetLimit() {
        return resultSetLimit;
    }

    public boolean isIncludePayload() {
        return includePayload;
    }

    public void setIncludePayload(boolean includePayload) {
        this.includePayload = includePayload;
    }

    public String[] getFields() {
        return fields;
    }

    public String[] getSuggestionFields() {
        return suggestionFields;
    }

    public SortBy[] getSortBy() {
        return sortBy;
    }

    public void setFields(String[] fields) {
        this.fields = fields;
    }

    public String getFilterExpression() {
        return filterExpression;
    }

    public boolean isIncludeDidYouMean() {
        return includeDidYouMean;
    }

    public FilterSpecs getFilterSpecs() {
        return filterSpecs;
    }
}
