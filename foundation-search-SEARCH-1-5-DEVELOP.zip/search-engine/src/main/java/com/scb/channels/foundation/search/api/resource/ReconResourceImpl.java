package com.scb.channels.foundation.search.api.resource;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.scb.channels.foundation.api.dto.recon.ReconHeaderRequest;
import com.scb.channels.foundation.api.dto.recon.ReconHeaderResponse;
import com.scb.channels.foundation.search.SearchEngineContext;
import com.scb.channels.foundation.search.SearchEngineService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.Authorization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * Created by 1562315 on 5/15/2017.
 */
@CrossOrigin()
@Path("/recon")
@Api(value = "/recon", description = "Search Engine Recon API")
@Produces({MediaType.APPLICATION_JSON})
public class ReconResourceImpl implements ReconResource{

    private final SearchEngineContext searchEngineRequest;
    private SearchEngineService searchEngineService;

    @Autowired
    public ReconResourceImpl(SearchEngineContext searchEngineRequest, SearchEngineService searchEngineService) {
        this.searchEngineRequest = searchEngineRequest;
        this.searchEngineService = searchEngineService;
    }

    @POST
    @Path("/list")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Get application content by classification and resource id",
            response = ReconHeaderResponse.class,
            httpMethod = "POST",
            authorizations = {@Authorization(value="basicAuth")})
    public ReconHeaderResponse resolveReconHeaders(@ApiParam(required = true)ReconHeaderRequest request) throws JsonProcessingException {
        return searchEngineService.compareReconHeaders(request, searchEngineRequest);
    }
}
