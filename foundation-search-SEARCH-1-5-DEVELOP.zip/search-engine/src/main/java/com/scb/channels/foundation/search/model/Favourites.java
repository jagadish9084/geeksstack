package com.scb.channels.foundation.search.model;

import com.google.common.collect.Lists;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

public class Favourites {

    private LinkedList<String> searchIds = Lists.newLinkedList();

    public Favourites(Collection<String> searchIds) {
        this.searchIds.addAll(searchIds);
    }

    public Favourites() {
    }

    public Collection<String> getSearchIds() {
        return searchIds;
    }

    public Favourites remove(String searchId) {
        Favourites favs = new Favourites(this.searchIds);
        favs.searchIds.remove(searchId);
        return favs;
    }

    public Favourites add(String searchId) {
        Favourites favs = new Favourites(this.searchIds);
        favs.searchIds.addFirst(searchId);
        return favs;
    }

    public Favourites limit(Integer searchLimit) {
        return new Favourites(
                this.searchIds.subList(0, Math.min(this.searchIds.size(), searchLimit))
        );
    }
}
