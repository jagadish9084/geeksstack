package com.scb.channels.foundation.search.model;

import com.scb.channels.foundation.search.api.dto.SearchRequest;

public class SearchAggregation {

    public static final int DEFAULT_HISTOGRAM_INTERVAL = 1000 * 60 * 60 * 24;

    public enum AggregationType { Term, Histogram, Average, Sum, Min, Max, Percentile, DateHistogram, Count, TopHits  }

    public enum AggregationReductionType { None, DateDay, DateMonth, Date, DateYear }

    private AggregationType aggregationType;
    private AggregationReductionType aggregationReductionType;
    private String nickname;
    private String field;
    private double interval;

    private SearchAggregation subAggregation;

    public SearchAggregation() { }

    public SearchAggregation(AggregationType aggregationType, AggregationReductionType aggregationReductionType, String nickname, String field, double interval, SearchAggregation subAggregation) {
        this.aggregationType = aggregationType;
        this.aggregationReductionType = aggregationReductionType;
        this.nickname = nickname;
        this.field = field;
        this.interval = interval;
        this.subAggregation = subAggregation;
    }

    public AggregationType getAggregationType() {
        return aggregationType;
    }

    public AggregationReductionType getAggregationReductionType() {
        return aggregationReductionType;
    }

    public String getNickname() {
        return nickname;
    }

    public String getField() {
        return field;
    }

    public double getInterval() {
        return interval;
    }

    public SearchAggregation getSubAggregation() {
        return subAggregation;
    }

    public static SearchAggregation fromDto(String key, SearchRequest.AggregateFun value) {

        AggregationType aggregationType = null;
        AggregationReductionType aggregationReductionType = null;

        long interval = 1;

        switch(value) {
            case Avg:
                aggregationType = AggregationType.Average;
                aggregationReductionType = AggregationReductionType.None;
                break;
            case Count:
                aggregationType = AggregationType.Count;
                aggregationReductionType = AggregationReductionType.None;
                break;
            case Histogram:
                aggregationType = AggregationType.Histogram;
                aggregationReductionType = AggregationReductionType.Date;
                interval = DEFAULT_HISTOGRAM_INTERVAL;
                break;
            case Max:
                aggregationType = AggregationType.Max;
                aggregationReductionType = AggregationReductionType.None;
                break;
            case Sum:
                aggregationType = AggregationType.Sum;
                aggregationReductionType = AggregationReductionType.None;
                break;
            case Min:
                aggregationType = AggregationType.Min;
                aggregationReductionType = AggregationReductionType.None;
                break;
        }

        return new SearchAggregation(aggregationType, aggregationReductionType, "", key, interval, null);
    }

}
