package com.scb.channels.foundation.search.api.resource;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.channels.foundation.api.dto.recon.ReconHeaderRequest;
import com.scb.channels.foundation.api.dto.recon.ReconHeaderResponse;
import com.scb.channels.foundation.search.SearchEngineContext;
import com.scb.channels.foundation.search.SearchEngineService;
import com.scb.channels.foundation.search.api.dto.*;
import com.scb.channels.foundation.search.model.ContinueSearchRequest;
import com.scb.channels.foundation.search.model.IndexObject;
import com.scb.channels.foundation.search.model.NewSearchRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.Authorization;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.context.WebApplicationContext;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiFunction;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toMap;

@CrossOrigin()
@Component
@Scope(WebApplicationContext.SCOPE_REQUEST)
@Path("/search")
@Api(value = "/search", description = "Search Engine API")
public class SearchResourceImpl implements SearchResource {

    private final SearchEngineContext searchEngineRequest;
    private SearchEngineService searchEngineService;

    private ObjectMapper objectMapper;

    @Autowired
    public SearchResourceImpl(SearchEngineService reportEngineService, SearchEngineContext searchEngineRequest
                                , ObjectMapper objectMapper) {
        this.searchEngineService = reportEngineService;
        this.searchEngineRequest = searchEngineRequest;
        this.objectMapper = objectMapper;
    }

    @POST
    @Path("/ingest")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Ingests an ingest envelope and returns a respective operation result, either OK or FAIL",
            notes = "Calls for the same object state will be indempotent, calls for the same id but different state will result in an update",
            response = Map.class,
            httpMethod = "POST",
            authorizations = {@Authorization(value="basicAuth")})
    public Map<String,String> ingest(@ApiParam(required = true) IngestEnvelopes envelope) {
        validateData(envelope.getIngestEnvelopes().stream(), IngestEnvelope::checkComplete);
        return searchEngineService.ingest(envelope.getIngestEnvelopes().stream().map(e->IndexObject.fromDto(e,objectMapper)).collect(Collectors.toList()), searchEngineRequest);
    }

    @POST
    @Path("/newSearch")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Submits a new search to the search engine",
            response = SearchResult.class,
            httpMethod = "POST",
            authorizations = {@Authorization(value="basicAuth")})
    public SearchResult newSearch(@ApiParam(required = true) SearchRequest searchRequest) throws JsonProcessingException {
        return SearchResult.fromModelSearchResult(
                        searchEngineService.newSearch(getNewSearchRequest(searchRequest), searchEngineRequest));
}

    @POST
    @Path("/quickSearch")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Submits a quick search to the search engine",
            response = SearchResult.class,
            httpMethod = "POST",
            authorizations = {@Authorization(value="basicAuth")})
    public SearchResult quickSearch(@ApiParam(required = true) SearchRequest searchRequest) throws JsonProcessingException {
        return SearchResult.fromModelSearchResult( searchEngineService.quickSearch(
                searchRequest.getExpression(),
                searchRequest.isIncludePayload(),
                searchRequest.getResultSetLimit(), searchEngineRequest) );
    }

    @POST
    @Path("/predict")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Performs a predict, e.g. did-you-mean or auto-complete",
            response = PredictResult.class,
            httpMethod = "POST",
            authorizations = {@Authorization(value="basicAuth")})
    public PredictResult predict(@ApiParam(required = true) PredictRequest predictRequest) throws JsonProcessingException {
        if (predictRequest == null) {
            Response.status(Response.Status.NOT_ACCEPTABLE).entity("missing request body.");
        }
        Collection<String> result = searchEngineService.predict(
                predictRequest.getPredictionType(),
                predictRequest.getPartial(),
                null,
                predictRequest.getResultLimit(),
                predictRequest.getFields() == null ? new String[] { "description"  } : predictRequest.getFields()
                , searchEngineRequest
        );

        return new PredictResult(result);
    }

    @GET
    @Path("/quickSearch")
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Submits a quick search to the search engine using only query parameters",
            response = SearchResult.class,
            httpMethod = "GET",
            authorizations = {@Authorization(value="basicAuth")})
    public SearchResult quickSearch(@QueryParam("expression") String expression,
                                    @QueryParam("limit") Integer limit,
                                    @QueryParam("includePayload") boolean includePayload)  throws JsonProcessingException {
        return SearchResult.fromModelSearchResult( searchEngineService.quickSearch(expression, includePayload, limit, searchEngineRequest) );
    }

    @POST
    @Path("/continueSearch")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Continues a previously submitted search based on the continuation marker",
            notes = "For details on how the continuation marker works, see https://www.elastic.co/guide/en/elasticsearch/reference/current/search-request-search-after.html ",
            response = SearchResult.class,
            httpMethod = "POST",
            authorizations = {@Authorization(value="basicAuth")})
    public SearchResult continueSearch(@ApiParam(required = true) SearchContinuationRequest searchRequest) throws JsonProcessingException {
        ContinueSearchRequest rs = new ContinueSearchRequest(
                searchRequest.getContinuationMarker(),
                getNewSearchRequest(searchRequest.getSearchRequest())
        );
        return SearchResult.fromModelSearchResult(searchEngineService.continueSearch(rs, searchEngineRequest));
    }

    @GET
    @Path("/favourites") //limit={n}	GET	Find current users list of favourite searches	NA	Favourite Result
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Returns saved favourites for a given user, the number of favourites returned is limited by the limit parameter",
            response = Map.class,
            httpMethod = "POST",
            authorizations = {@Authorization(value="basicAuth")})
    public Favourites favourites(@QueryParam("limit") Integer searchLimit) throws JsonProcessingException {

        return new Favourites(searchEngineService.findFavourites(searchLimit, searchEngineRequest).stream().map(
                s-> Pair.of(s.getSearchId(),new SearchRequest(s.getSearchDefinition().getExpression(),s.getSearchDefinition().getLimit()))).
                collect(toMap(Pair::getKey, Pair::getValue)));

    }

    @POST
    @Path("/favourites/add/{searchId}")
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Adds a search id to the top of the current users favourites",
            code = 204,
            httpMethod = "POST",
            authorizations = {@Authorization(value="basicAuth")})
    public Response favouritesAdd(@PathParam("searchId") String searchId) {
        searchEngineService.addFavourite(searchId, searchEngineRequest);
        return Response.ok(Response.Status.NO_CONTENT).build();
    }

    @POST
    @Path("/favourites/delete/{searchId}")
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Removes a search id from the current users favourites",
            code = 204,
            httpMethod = "POST",
            authorizations = {@Authorization(value="basicAuth")})
    public Response favouritesDelete(@PathParam("searchId") String searchId) {
        searchEngineService.deleteFavourite(searchId, searchEngineRequest);
        return Response.ok(Response.Status.NO_CONTENT).build();
    }



    private NewSearchRequest getNewSearchRequest(SearchRequest searchRequest) {
        return new NewSearchRequest(searchRequest);
    }


    private <T> void validateData(Stream<T> content, BiFunction<T, AtomicInteger, String> fun) {
        AtomicInteger refCounter = new AtomicInteger();
        String errors = StringUtils.join(content.map(i->fun.apply(i,refCounter)).collect(Collectors.toList()), ",");
        if (refCounter.get() > 0) {
            throw new IllegalArgumentException(errors);
        }
    }
}
