package com.scb.channels.foundation.search;

import com.google.common.collect.Maps;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.core.HttpHeaders;
import javax.xml.bind.DatatypeConverter;
import java.util.Map;

public class SearchEngineContext {

    private Map<String,String> httpHeaders = Maps.newConcurrentMap();

    @Autowired
    public SearchEngineContext(Map<String,String> httpHeaders) {
        this.httpHeaders.putAll(httpHeaders);
    }

    public SearchEngineContext(String userId, String dapPolicy) {
        this.httpHeaders.put("userid",userId);
        this.httpHeaders.put("dappolicy",dapPolicy);
    }

    public String getUserId() {
        String userId = httpHeaders.get("userid");
        if (userId == null) {
            String authHeader = httpHeaders.get(HttpHeaders.AUTHORIZATION.toLowerCase());
            if (authHeader == null) {
                throw new IllegalArgumentException("UserId header is not specified, this mandatory header must be present for each request.");
            }
            userId = new String(DatatypeConverter.parseBase64Binary(authHeader.substring("Basic ".length()))).split(":")[0];
        }
        if(StringUtils.isBlank(userId)) {
            throw new IllegalArgumentException("UserId header is not specified, this mandatory header must be present for each request.");
        }
        return userId;
    }

    public String getDapPolicy() {
        String dappolicy = httpHeaders.get("dappolicy");
//        if (dappolicy == null) {
//            throw new IllegalArgumentException("dappolicy header is not specified, this mandatory header must be present for each request.");
//        }
        //TODO: remove this once UI passes it in
        return dappolicy == null ? "NextGen" : dappolicy;
    }
}
