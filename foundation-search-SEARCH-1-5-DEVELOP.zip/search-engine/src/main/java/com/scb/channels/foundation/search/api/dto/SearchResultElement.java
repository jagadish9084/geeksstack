package com.scb.channels.foundation.search.api.dto;

import com.scb.channels.foundation.search.model.Result;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import static com.scb.channels.foundation.util.Strings.defaultToString;

public class SearchResultElement {

    private String entityType;
    private Collection<String> identifier;
    private Instant timestamp;
    private String description;
    private Map<String,Object> payload;
    private String[] continuationMarker;
    private Map<String, List<String>> highlights;
    private String MD5hash;

    public SearchResultElement() { }

    @SuppressWarnings("unchecked")
    public static SearchResultElement fromModelResult(Result result) {
        SearchResultElement e = new SearchResultElement();
        e.continuationMarker = result.getContinuationMarker();
        e.description = defaultToString( result.getFields().get("description"), "");
        e.entityType = result.getFields().get("entityType").toString();
        e.identifier = (Collection<String>)result.getFields().get("identifier");
        e.payload =  (Map<String,Object>)result.getPayloadAsMap().get("payload");
        e.highlights = result.getHighlights();
        e.timestamp = Instant.parse(defaultToString(result.getFields().get("timestamp"),"1970-01-01T00:00:00"));
        return e;
    }

    public String getEntityType() {
        return entityType;
    }

    public Collection<String> getIdentifier() {
        return identifier;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    public String getDescription() {
        return description;
    }

    public Map<String, Object> getPayload() {
        return payload;
    }

    public String[] getContinuationMarker() {
        return continuationMarker;
    }

    public Map<String, List<String>> getHighlights() {
        return highlights;
    }
}
