package com.scb.channels.foundation.search.api.dto;

public class SearchContinuationRequest {

    private String[] continuationMarker;
    private SearchRequest searchRequest;

    public SearchContinuationRequest() { }

    public SearchContinuationRequest(String[] continuationMarker, SearchRequest searchRequest) {
        this.continuationMarker = continuationMarker;
        this.searchRequest = searchRequest;
    }

    public String[] getContinuationMarker() {
        return continuationMarker;
    }

    public SearchRequest getSearchRequest() {
        return searchRequest;
    }

}
