package com.scb.channels.foundation.search.api.dto;

import com.google.common.collect.Lists;

import java.util.Collections;
import java.util.List;

public class IndexDefinitions {

    private List<IndexDefinition> indexDefinitions = Lists.newArrayList();

    public List<IndexDefinition> getIndexDefinitions() {
        return Collections.unmodifiableList(indexDefinitions);
    }
}
