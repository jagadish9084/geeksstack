package com.scb.channels.foundation.search.elastic;

import com.google.common.collect.Lists;
import com.scb.channels.foundation.entitlement.dap.impl.AnnotationBasedDapPolicyFactory;
import com.scb.channels.foundation.entitlement.dap.impl.CompositeDapPolicyFactory;
import com.scb.channels.foundation.entitlement.dap.impl.PropertyBasedDapPolicyFactory;
import org.elasticsearch.plugins.Plugin;
import org.elasticsearch.plugins.SearchPlugin;
import org.elasticsearch.search.suggest.term.DapTermSuggester;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

public class DapSearchPlugin extends Plugin implements SearchPlugin {

    public static boolean hasDapPlugin() {
        return !("true".equals(System.getProperty("suppress-dap-plugin")));
    }

    public DapSearchPlugin() throws ClassNotFoundException, InstantiationException, IllegalAccessException, IOException {
        StaticDapPolicyFactory.init(new CompositeDapPolicyFactory(
                new PropertyBasedDapPolicyFactory(),
                new AnnotationBasedDapPolicyFactory()));
    }

    @Override
    public List<SuggesterSpec<?>> getSuggesters() {
        return Collections.singletonList(new SuggesterSpec<>(DapTermSuggester.NAME, DapTermSuggestionBuilder::new, DapTermSuggestionBuilder::fromXContent));
    }

    public List<ScoreFunctionSpec<?>> getScoreFunctions() {
        return Lists.newArrayList(
                new ScoreFunctionSpec<>(
                        DapSearchScoreBuilder.NAME,
                        DapSearchScoreBuilder::new,
                        DapSearchScoreBuilder::fromXContent));
    }

}
