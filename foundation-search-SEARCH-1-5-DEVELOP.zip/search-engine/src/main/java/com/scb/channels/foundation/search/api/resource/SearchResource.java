package com.scb.channels.foundation.search.api.resource;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.scb.channels.foundation.search.api.dto.*;

import javax.ws.rs.core.Response;
import java.util.Map;

public interface SearchResource {

    Map<String,String> ingest(IngestEnvelopes envelope) throws JsonProcessingException;

    SearchResult newSearch(SearchRequest searchRequest) throws JsonProcessingException;

    SearchResult quickSearch(SearchRequest searchRequest) throws JsonProcessingException;

    SearchResult quickSearch(String expression, Integer limit, boolean includePayload) throws JsonProcessingException;

    SearchResult continueSearch(SearchContinuationRequest searchRequest) throws JsonProcessingException;

    PredictResult predict(PredictRequest predictRequest) throws JsonProcessingException;

    Favourites favourites(Integer searchLimit) throws JsonProcessingException;

    Response favouritesAdd(String searchId);

    Response favouritesDelete(String searchId);

}