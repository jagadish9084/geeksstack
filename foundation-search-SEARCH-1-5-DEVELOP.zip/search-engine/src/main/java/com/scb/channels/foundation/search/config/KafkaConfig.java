package com.scb.channels.foundation.search.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.channels.foundation.search.Application;
import com.scb.channels.foundation.search.SearchEngineService;
import com.scb.channels.foundation.search.impl.IngestionConsumer;
import io.advantageous.config.Config;
import io.advantageous.config.ConfigLoader;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.IntegerDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.*;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableKafka
@Conditional(KafkaConfig.KafkaEnabledCheck.class)
public class KafkaConfig {

    private static final Logger logger = LoggerFactory.getLogger(KafkaConfig.class);

    static final class KafkaEnabledCheck implements Condition {
        @Override
        public boolean matches(ConditionContext conditionContext, AnnotatedTypeMetadata annotatedTypeMetadata) {
            Config config = conditionContext.getBeanFactory().getBean(Application.class).config();
            boolean enabled = config.hasPath("search.subscription.enabled") && config.getBoolean("search.subscription.enabled");
            logger.info("Kafka subscription for ingesting events enabled:" + enabled);
            return enabled;
        }
    }


    @Bean
    public Map<String,Object> consumerConfigs(Config config){
        Map<String,Object> props = new HashMap<String,Object>();

        String bootStrapServers = config.getString("search.subscription.kafka.bootstrap_servers");
        String consumerGroupId = config.getString("search.subscription.kafka.services.groupId");

        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootStrapServers );
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,IntegerDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, consumerGroupId);
        return props;
    }

    @Bean
    public ConsumerFactory<Integer,String> consumerFactory(Config config){
        return new DefaultKafkaConsumerFactory<>(consumerConfigs(config));
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<Integer,String> kafkaListenerContainerFactory(Config config){
        ConcurrentKafkaListenerContainerFactory<Integer,String> factory=new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory(config));
        return factory;
    }

    @Bean
    public IngestionConsumer ingestionConsumer(SearchEngineService searchEngineService, Config config, ObjectMapper objectMapper) {
        return new IngestionConsumer(searchEngineService, config, objectMapper);
    }


}
