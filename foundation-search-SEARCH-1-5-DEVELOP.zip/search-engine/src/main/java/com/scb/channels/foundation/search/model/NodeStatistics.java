package com.scb.channels.foundation.search.model;

public class NodeStatistics {
}
