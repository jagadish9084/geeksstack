package com.scb.channels.foundation.search.impl;

import com.scb.channels.foundation.search.SearchEngineAdminService;
import com.scb.channels.foundation.search.model.IndexFieldDefinition;
import com.scb.channels.foundation.search.model.SearchEventService;
import com.scb.channels.foundation.util.jackson.JacksonMarshaller;
import com.scb.channels.foundation.util.jackson.Marshaller;
import io.advantageous.config.Config;
import org.elasticsearch.action.admin.indices.alias.get.GetAliasesResponse;
import org.elasticsearch.action.admin.indices.mapping.get.GetMappingsResponse;
import org.elasticsearch.action.bulk.BulkProcessor;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.cluster.metadata.AliasMetaData;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static com.google.common.collect.Maps.newHashMap;
import static com.scb.channels.foundation.search.SearchEngineService.SUGGESTER_FIELD;
import static com.scb.channels.foundation.search.impl.Utils.buildPayloadAll;
import static com.scb.channels.foundation.search.impl.Utils.buildSuggesterString;

@Scope("singleton")
public class SearchEngineAdminServiceImpl implements SearchEngineAdminService {

    private static final Logger logger = LoggerFactory.getLogger(SearchEngineAdminServiceImpl.class);

    private final Config config;
    private final Client client;

    private SearchEventService searchEventService;
    private Marshaller marshaller = new JacksonMarshaller();

    public SearchEngineAdminServiceImpl(Config config, ElasticSearchProvider elasticSearchProvider, SearchEventService searchEventService) {
        this.config = config;
        this.client = elasticSearchProvider.getClient();
        this.searchEventService = searchEventService;
    }

    @Override
    public void defineIndex(String indexName, String indexType, Map<String, IndexFieldDefinition> _fields) {

        Map<String, IndexFieldDefinition> fields = newHashMap(_fields);

        boolean exists = indexExists(indexName, indexType);

        if (!exists) {
            client.admin().indices().prepareCreate(indexName).setSettings(buildSettings()).get();
            applyMappings(indexName, indexType, fields);
            logger.info("Define index completed.");
        } else {
            logger.info("Index already exists, rebuilding .. ");
            String newIndexName = indexName + "_" + System.currentTimeMillis();

            logger.info("Creating new index with underlying name: " + newIndexName);
            client.admin().indices().prepareCreate(newIndexName).setSettings(buildSettings()).get();
            applyMappings(newIndexName, indexType, fields);

            logger.info("Cloning index " + indexName + " to " + newIndexName);
            cloneIndex(indexName, newIndexName);

            logger.info("Deleting index " + indexName);
            client.admin().indices().prepareClose(indexName).get();
            client.admin().indices().prepareDelete(indexName).get();

            logger.info("Aliasing new index.. ");
            client.admin().indices().prepareAliases().addAlias(newIndexName, indexName).get();
            logger.info("Redefine index completed.");
        }

    }

    @SuppressWarnings("unchecked")
    @Override
    public Map<String, Object> getIndexMappings(String indexName, String indexType) throws IOException {

        GetAliasesResponse aliases = client.admin().indices().prepareGetAliases(indexName).get();

        String routedIndex = indexName;
        if (!aliases.getAliases().isEmpty()) {
            List<AliasMetaData> als = aliases.getAliases().valuesIt().next();
            if (!als.isEmpty()) {
                if (als.get(0).getAlias().equals(indexName)) {
                    routedIndex = aliases.getAliases().keysIt().next();
                }
            }
        }

        GetMappingsResponse response = client.admin().indices().prepareGetMappings().get();
        return response.mappings().
                get(routedIndex).
                get(indexType).
                sourceAsMap();
    }

    @Override
    public String getStatistics() {

        String res = "{\"health\": " + client.admin().cluster().prepareHealth().get().toString();
        res += ", \"clusterStats\" : " + client.admin().cluster().prepareClusterStats().get().toString();
        res += ", \"nodeInfo\" : " + client.admin().cluster().prepareNodesInfo().get().toString();
        res += ", \"nodeStats\" : " + client.admin().cluster().prepareNodesStats().get().toString();
        res += " } ";
        return res;
    }

    @Override
    public String getSearchShardStatistics() {
        String res = "{\"searchShards\" : " + marshaller.marshalLenient(client.admin().cluster().prepareSearchShards().get());
        res += " } ";
        return res;
    }


    @Override
    public boolean indexExists(String indexName, String indexType) {
        return client.admin().indices().prepareExists(indexName).get().isExists();
    }

    private Map<String, IndexFieldDefinition> defaultFields() {
        return DEFAULT_FIELDS;
    }

    private String getMappingSource(Map<String, IndexFieldDefinition> fields) {
        String source = "{ \"_all\":  { \"analyzer\" : \"" + TRIGRAM_ANALYZER + "\" } ";
//        String source = "{ \"_all\":  { } ";
        if (!fields.isEmpty()) {
            source += ", " + toProperties(fields);
        }
        source += dynamicLongToDouble();
        source += "}";
        return source;
    }

    private String dynamicLongToDouble() {
        return ", \"dynamic_templates\": [ " +
                "        { " +
                "          \"doubles\": { " +
                "            \"match_mapping_type\": \"long\", " +
                "            \"mapping\": { " +
                "              \"type\": \"double\" " +
                "            } " +
                "          } " +
                "        } ]";
    }

    @SuppressWarnings({"SuspiciousMethodCalls", "unchecked"})
    private String toProperties(Map<String, IndexFieldDefinition> stringObjectMap) {

        if (stringObjectMap == null || stringObjectMap.isEmpty())
            return "";

        String r = "\"properties\" : { \"_suggest\" : { \"type\" : \"text\" } , ";

        boolean first = true;
        for (Map.Entry<String, IndexFieldDefinition> entry : stringObjectMap.entrySet()) {

            String key = entry.getKey();
            IndexFieldDefinition def = entry.getValue();

            if (!first) {
                r += ",";
            }

            r += " \"" + key + "\" : { " +
                    " \"type\" : \"" + def.getDataType() + "\" " +
                    ((def.hasAnalyser() && !def.isFieldData()) ? ", \"analyzer\": \"" + def.getAnalyseWith() + "\" " : "") +
                    (def.excludeFromAll() ? ", \"include_in_all\": false " : "") +
                    (def.isFieldData() ? ", \"fielddata\": true, \"analyzer\" : \"nowhite_analyzer\"" : "");

            r += (stringObjectMap.get(key).getChildren().isEmpty() ? "" : " , " + toProperties(stringObjectMap.get(key).getChildren()));
            r += " } ";

            first = false;
        }

        return r + "} ";
    }

    private Settings.Builder buildUpdateSettings() {
        return Settings.builder().

                put("index.analysis.analyzer.suggests_analyzer.type", "custom").
                put("index.analysis.analyzer.suggests_analyzer.tokenizer", "standard").
                putArray("index.analysis.analyzer.suggests_analyzer.filter", "lowercase", "shingle_filter").

                put("index.analysis.analyzer.nowhite_analyzer.type", "custom").
                put("index.analysis.analyzer.nowhite_analyzer.tokenizer", "keyword").
                putArray("index.analysis.analyzer.nowhite_analyzer.filter", "lowercase", "whitespace_remove").

                put("index.analysis.analyzer.contains_analyzer.type", "custom").
                put("index.analysis.analyzer.contains_analyzer.tokenizer", "ngram_tokenizer").
                putArray("index.analysis.analyzer.contains_analyzer.filter", "lowercase").

                put("index.analysis.tokenizer.ngram_tokenizer.type", "ngram").
                put("index.analysis.tokenizer.ngram_tokenizer.min_gram", "3").
                put("index.analysis.tokenizer.ngram_tokenizer.max_gram", "3").
                putArray("index.analysis.tokenizer.ngram_tokenizer.token_chars", "letter", "digit").

                //
                put("index.analysis.filter.whitespace_remove.type", "pattern_replace").
                put("index.analysis.filter.whitespace_remove.pattern", " ").
                put("index.analysis.filter.whitespace_remove.replacement", "").

                put("index.analysis.filter.light_english_stemmer.type", "stemmer").
                put("index.analysis.filter.light_english_stemmer.language", "light_english").
                put("index.analysis.filter.english_possessive_stemmer.type", "stemmer").
                put("index.analysis.filter.english_possessive_stemmer.language", "possessive_english").

                put("index.analysis.filter.shingle_filter.type", "shingle").
                put("index.analysis.filter.shingle_filter.min_shingle_size", "2").
                put("index.analysis.filter.shingle_filter.max_shingle_size", "4");
    }

    private Settings buildSettings() {
        return buildUpdateSettings().
                put("index.refresh_interval", "250ms").
                put("index.number_of_shards", config.getInt("search.elastic.no_shards")).
                put("index.number_of_replicas", config.getInt("search.elastic.replication_factor")).
                build();
    }

    private void applyMappings(String indexName, String indexType, Map<String, IndexFieldDefinition> fields) {
        fields.putAll(defaultFields());
        client.admin().indices().preparePutMapping(indexName).setType(indexType).setSource(
                getMappingSource(fields), XContentType.JSON
        ).setUpdateAllTypes(true).get();
    }

    private void cloneIndex(String indexName, String newIndexName) {

        int BULK_ACTIONS_THRESHOLD = 100;

        SearchResponse scrollResp = client.prepareSearch(indexName) // Specify index
                .setScroll(new TimeValue(600000))
                .setQuery(QueryBuilders.matchAllQuery()) // Match all query
                .setSize(BULK_ACTIONS_THRESHOLD).get(); //100 hits per shard will


        int BULK_CONCURRENT_REQUESTS = 8;
        BulkProcessor bulkProcessor = BulkProcessor.builder(client, new BulkProcessor.Listener() {
            @Override
            public void beforeBulk(long executionId, BulkRequest request) {
            }

            @Override
            public void afterBulk(long executionId, BulkRequest request, BulkResponse response) {
            }

            @Override
            public void afterBulk(long executionId, BulkRequest request, Throwable failure) {
            }
        }).setBulkActions(BULK_ACTIONS_THRESHOLD)
                .setConcurrentRequests(BULK_CONCURRENT_REQUESTS)
                .setFlushInterval(TimeValue.timeValueMillis(5)).build();

        //Scroll until no hits are returned
        int counter = 0;
        while (true) {
            //Break condition: No hits are returned
            if (scrollResp.getHits().getHits().length == 0) {
                bulkProcessor.close();
                break;
            }
            // Get results from a scan search and add it to bulk ingest
            for (SearchHit hit: scrollResp.getHits()) {
                IndexRequest request = new IndexRequest(newIndexName, hit.type(), hit.id());
                Map<String,Object> source = hit.getSource();
                if (!source.containsKey(SUGGESTER_FIELD)) {

                    source.put(SUGGESTER_FIELD,
                            buildSuggesterString(
                                    (String)source.get("description"),
                                    (List<String>)source.get("identifier"),
                                    buildPayloadAll(source.get("payload"), new StringBuilder("")).toString().trim()));
                }
                request.source(source);
                bulkProcessor.add(request);
            }

            counter += scrollResp.getHits().totalHits();
            logger.info("Handled " + scrollResp.getHits().totalHits() + " in this batch, total " + counter + " elements.. scrolling ");

            scrollResp = client.prepareSearchScroll(scrollResp.getScrollId()).setScroll(new TimeValue(600000)).get();
        }

        logger.info("Clone complete, copied " + counter + " elements. ");
    }


}
