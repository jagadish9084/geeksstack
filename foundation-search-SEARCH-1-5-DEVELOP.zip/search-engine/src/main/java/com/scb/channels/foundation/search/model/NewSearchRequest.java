package com.scb.channels.foundation.search.model;

import com.scb.channels.foundation.search.api.dto.FilterSpec;
import com.scb.channels.foundation.search.api.dto.FilterSpecs;
import com.scb.channels.foundation.search.api.dto.SearchRequest;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class NewSearchRequest {

    private boolean includeDidYouMean;
    private SearchSortBy[] sortBy;
    private String expression;
    private String filterExpression;
    private boolean includePayload;
    private String[] fields;
    private String[] suggestionFields;
    private SearchAggregation[] aggregation;
    private int limit;

    public NewSearchRequest() { }

    public NewSearchRequest(String expression,
                            String filterExpression,
                            boolean includeDidYouMean,
                            boolean includePayload,
                            String[] fields,
                            String[] suggestionFields,
                            SearchAggregation[] aggregation,
                            SearchSortBy[] sortBy,
                            int limit) {
        this.expression = expression;
        this.filterExpression = filterExpression;
        this.includeDidYouMean = includeDidYouMean;
        this.includePayload = includePayload;
        this.fields = fields;
        this.suggestionFields = suggestionFields;
        this.sortBy = sortBy;
        this.aggregation = aggregation;
        this.limit = limit;
    }

    public NewSearchRequest(SearchRequest searchRequest) {
        this(searchRequest.getExpression(),
                buildFilterExpression(searchRequest),
                searchRequest.isIncludeDidYouMean(),
                searchRequest.isIncludePayload(),
                searchRequest.getFields(),
                searchRequest.getSuggestionFields(),
                toAggregateModel(searchRequest.getAggregateOn()),
                searchRequest.getSortBy() != null ? Stream.of(searchRequest.getSortBy()).map(s -> new SearchSortBy(s.getFieldName(),SearchSortBy.Direction.valueOf(s.getDirection().name()))).toArray(SearchSortBy[]::new) : new SearchSortBy[0],
                searchRequest.getResultSetLimit());
    }

    private static SearchAggregation[] toAggregateModel(Map<String, SearchRequest.AggregateFun> aggregateOn) {
        if (aggregateOn == null) {
            return null;
        }
        return aggregateOn.entrySet().stream().map(e->SearchAggregation.fromDto(e.getKey(),e.getValue())).toArray(SearchAggregation[]::new);
    }

    public String getExpression() {
        return expression;
    }

    public boolean isIncludePayload() {
        return includePayload;
    }

    public String[] getFields() {
        return fields != null ? fields : new String[0];
    }

    public SearchSortBy[] getSortBy() {
        return sortBy;
    }

    public boolean isIncludeDidYouMean() {
        return includeDidYouMean;
    }

    public SearchAggregation[] getAggregateOn() {
        return aggregation;
    }

    public int getLimit() {
        return limit;
    }

    public String getFilterExpression() {
        return filterExpression == null ? "" : filterExpression;
    }

    private static String buildFilterExpression(SearchRequest searchRequest) {
        String expression = "";

        if (StringUtils.isEmpty(searchRequest.getFilterExpression()) &&
                (searchRequest.getFilterSpecs() == null || searchRequest.getFilterSpecs().getFilters().isEmpty() )) {
            return expression;
        }
        if (searchRequest.getFilterExpression() != null) {
            expression += searchRequest.getFilterExpression();
        }
        String filterSpec = filterToExpression(searchRequest.getFilterSpecs());
        if (filterSpec.trim().length() > 0) {
            expression += (expression.trim().length() > 0 ? " AND " : "") + filterSpec;
        }

        return expression;
    }

    private static String filterToExpression(FilterSpecs filterSpecs) {
        return filterSpecs == null ? "" : StringUtils.join(filterSpecs.getFilters().stream().map(FilterSpec::toString).collect(Collectors.toList()), " AND ");
    }

    public String[] getSuggestionFields() {
        return suggestionFields;
    }

}
