package com.scb.channels.foundation.search.impl;

import com.scb.channels.foundation.search.model.ServerEndPoint;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.transport.client.PreBuiltTransportClient;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class ElasticSearchProviderImpl implements ElasticSearchProvider {

    private final PreBuiltTransportClient client;

    public ElasticSearchProviderImpl(ServerEndPoint... endPoint) throws UnknownHostException {
        PreBuiltTransportClient client = new PreBuiltTransportClient(Settings.EMPTY);
        for(ServerEndPoint ep : endPoint) {
            client.addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName(ep.getHost()), ep.getPort()));
        }
        this.client = client;
    }

    @Override
    public Client getClient() {
        return client;
    }

}
