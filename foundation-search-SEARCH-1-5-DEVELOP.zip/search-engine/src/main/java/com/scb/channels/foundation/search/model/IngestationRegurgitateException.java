package com.scb.channels.foundation.search.model;

public class IngestationRegurgitateException extends RuntimeException {
    public IngestationRegurgitateException(String s) {
        super(s);
    }
}
