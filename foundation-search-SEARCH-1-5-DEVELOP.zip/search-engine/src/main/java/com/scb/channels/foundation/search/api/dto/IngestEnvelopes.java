package com.scb.channels.foundation.search.api.dto;

import java.util.Collection;

public class IngestEnvelopes {

    private Collection<IngestEnvelope> ingestEnvelopes;

    public Collection<IngestEnvelope> getIngestEnvelopes() {
        return ingestEnvelopes;
    }
}
