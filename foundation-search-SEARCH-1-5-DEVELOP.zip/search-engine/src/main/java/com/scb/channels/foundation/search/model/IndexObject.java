package com.scb.channels.foundation.search.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.channels.foundation.search.api.dto.IngestEnvelope;

public class IndexObject {

    private byte[] payload;
    private MandatoryIndexFields fields;

    private String indexName;
    private String indexType;

    public IndexObject(byte[] payload, MandatoryIndexFields fields, String indexName, String indexType) {
        this.payload = payload;
        this.fields = fields;
        this.indexName = indexName;
        this.indexType = indexType;
    }

    public byte[] getPayload() {
        return payload;
    }

    public MandatoryIndexFields getFields() {
        return fields;
    }

    public String getIndexType() {
        return indexType;
    }

    public String getIndexName() {
        return indexName;
    }

    public static IndexObject fromDto(IngestEnvelope e, ObjectMapper objectMapper) {
        try {
            return new IndexObject(
                    objectMapper.writeValueAsBytes(e.getPayload()),
                    MandatoryIndexFields.of(e,objectMapper),
                    e.getApplicationId() + "-" + e.getEntityType(),  //here we are using a new index per type, this decision was based on the relatively large data-sets per type
                    //see https://www.elastic.co/blog/index-vs-type for further reading
                    e.getEntityType());
        } catch (JsonProcessingException e1) {
            throw new RuntimeException(e1.getMessage(), e1);
        }

    }

}



