package com.scb.channels.foundation.search.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Sets;
import com.scb.channels.foundation.search.api.dto.IngestEnvelope;
import com.scb.channels.foundation.util.encryption.HashingUtil;
import org.springframework.util.Assert;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

public class MandatoryIndexFields {

    private static final Set<String> INTERNAL_FIELDS = Sets.newHashSet("_suggest","applicationId","entityType","dapTopic", "status", "md5hash");

    private String applicationId;
    private String entityType;
    private Instant timestamp;
    private List<String> identifier;
    private List<String> dapTopic;
    private String description;
    private StatusFlag status;
    private String md5hash;

    private MandatoryIndexFields(String applicationId, String entityType, Instant timeStamp, List<String> identifier, List<String> dapTopic, String description,String MD5Hash, StatusFlag statusFlag) {

        for(String dapT : dapTopic) {
            if (dapT.contains("$")) {
                throw new IllegalArgumentException("Dap topic cannot contain the symbol '$'");
            }
        }
        this.applicationId = applicationId;
        this.entityType = entityType;
        this.timestamp = timeStamp;
        this.identifier = identifier;
        this.dapTopic = dapTopic;
        this.description = description;
        this.status = statusFlag;
        this.md5hash = MD5Hash;
    }

    @SuppressWarnings("unused")
    public String getApplicationId() {
        return applicationId;
    }

    public String getEntityType() {
        return entityType;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    public List<String> getIdentifier() {
        return identifier;
    }

    public String getDescription() {
        return description;
    }

    public List<String> getDapTopic() {
        return dapTopic;
    }

    public String getStatus() {
        return status.name();
    }

    public String getMd5hash() { return md5hash; }

    public static MandatoryIndexFields of(String applicationId, String entityType, Instant timeStamp, String description, String MD5Hash, String[] dapTopic, String... identifier) {
        return of(applicationId,entityType, timeStamp, description, MD5Hash, dapTopic, StatusFlag.ACTIVE, identifier);
    }

    public static MandatoryIndexFields of(String applicationId, String entityType, Instant timeStamp, String description, String MD5Hash, String[] dapTopic, StatusFlag statusFlag, String... identifier) {
        Assert.notNull(dapTopic,"dapTopic must be specified");
        Assert.notNull(identifier,"identifier must be specified");
        Assert.notNull(description,"description must be specified");
        Assert.notNull(statusFlag,"status must be specificed");
        return new MandatoryIndexFields(
                applicationId, entityType, timeStamp, Arrays.asList(identifier), Arrays.asList(dapTopic), description,MD5Hash, statusFlag
        );
    }

    public static MandatoryIndexFields of(IngestEnvelope e) {
        return of(e.getApplicationId(),e.getEntityType(),e.getTimestamp(),e.getDescription(), HashingUtil.xxHash(e.getPayload()), e.getDapTopic(), StatusFlag.valueOf(e.getStatus()), e.getIdentifier());
    }
    public static MandatoryIndexFields of(IngestEnvelope e, ObjectMapper objectMapper) throws JsonProcessingException {
        return of(e.getApplicationId(), e.getEntityType(), e.getTimestamp(), e.getDescription(), HashingUtil.xxHash(objectMapper.writeValueAsString(e.getPayload())), e.getDapTopic(), StatusFlag.valueOf(e.getStatus()), e.getIdentifier());
    }

    public static boolean isInternalField(String fieldName) {
        return INTERNAL_FIELDS.contains(fieldName);
    }

    public static float boostForField(String field) {
        if ("identifier".equals(field))
            return 3.0f;
        if ("description".equals(field))
            return 2.5f;
        return 1.0f;
    }
}
