package com.scb.channels.foundation.search;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.scb.channels.foundation.datasource.util.DataSourceFactory;
import com.scb.channels.foundation.objectstore.EntityType;
import com.scb.channels.foundation.objectstore.EntityTypes;
import com.scb.channels.foundation.objectstore.ObjectStoreConfiguration;
import com.scb.channels.foundation.objectstore.ObjectStoreProvider;
import com.scb.channels.foundation.objectstore.serialization.KryoSerializationFactory;
import com.scb.channels.foundation.objectstore.serialization.StoreSerializerFactory;
import com.scb.channels.foundation.search.config.KafkaConfig;
import com.scb.channels.foundation.search.impl.*;
import com.scb.channels.foundation.search.model.Favourites;
import com.scb.channels.foundation.search.model.SearchEvent;
import com.scb.channels.foundation.search.model.SearchEventService;
import io.advantageous.config.Config;
import io.advantageous.config.ConfigLoader;
import org.elasticsearch.node.NodeValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Scope;
import org.springframework.web.context.WebApplicationContext;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.SQLException;

import static com.scb.channels.foundation.entitlement.dap.policy.cadm.NextGenDapPolicy.CSL_ENDPOINT_CONFIG_KEY;
import static com.scb.channels.foundation.entitlement.dap.policy.research.ResearchDapPolicy.RESEARCH_CSL_ENDPOINT_CONFIG_KEY;
import static com.scb.channels.foundation.objectstore.EntityTypes.ObjectStoreType.DB;
import static com.scb.channels.foundation.util.Http.getHeadersInfo;

@SpringBootApplication
@Import({ ObjectStoreConfiguration.class, KafkaConfig.class })
public class Application extends SpringBootServletInitializer {

    private static String rootHost;
    private static String nodeName;
    private static boolean isRoot;
    Logger logger = LoggerFactory.getLogger(Application.class);

    static {
        try {
            nodeName = System.getProperty("com.scb.channels.foundation.es.node-name", InetAddress.getLocalHost().getHostAddress());
        } catch (UnknownHostException e) {
            throw new RuntimeException(e.getMessage(),e);
        }
        rootHost = System.getProperty("com.scb.channels.foundation.es.root-host", nodeName + ":9300");
        isRoot = rootHost.startsWith(nodeName);
    }

    public static void main(String[] args) {

        rootHost = args.length > 0 ? args[0] : "localhost";
        nodeName = args.length > 1 ? args[1] : "node1";
        isRoot = args.length <= 2 || !"slave".equals(args[2]);

        ApplicationContext ctx = SpringApplication.run(Application.class, args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(Application.class);
    }

    @Bean
    @Scope(WebApplicationContext.SCOPE_REQUEST)
    public SearchEngineContext searchEngineContext(HttpServletRequest request) {
        return new SearchEngineContext(getHeadersInfo(request));
    }

    @Bean
    public SearchEngineService search(ElasticSearchProvider elasticSearchProvider, SearchEventService searchEventService, SearchEngineAdminService searchEngineAdminService, ObjectStoreProvider objectStoreProvider, ObjectMapper objectMapper) throws IOException, NodeValidationException {
        return  new SearchEngineServiceImpl(elasticSearchProvider,
                                            searchEventService,
                                            searchEngineAdminService,
                                            objectStoreProvider,
                                            objectMapper);
    }

    @Bean
    public SearchEngineAdminService admin(Config config, ElasticSearchProvider elasticSearchProvider, SearchEventService searchEventService) throws IOException, NodeValidationException {
        return new SearchEngineAdminServiceImpl(config, elasticSearchProvider, searchEventService);
    }

    @Bean
    @Qualifier("objectStore")
    public DataSource objectStoreDataSource(DataSourceFactory dataSourceFactory) throws SQLException {
        return dataSourceFactory.create("searchstore");
    }

    @Bean
    public Config config() {
        String configFile = System.getProperty("config-file", "service-config.js");
        logger.info("Using config: {}", configFile);
        return ConfigLoader.load(configFile);
    }

    @Bean
    public DataSourceFactory dataSourceFactory(Config config) {
        return new DataSourceFactory(config);
    }

    @Bean
    public EntityTypes entityTypes() {
        return EntityTypes.of(
                EntityType.create("SearchLog", SearchEvent.class, DB, 10000),
                EntityType.create("Favourites", Favourites.class, DB, 100000)
        );
    }

    @Bean
    public SearchEventService searchEventService(ObjectStoreProvider objectStoreProvider) {
        return new SearchEventServiceImpl(objectStoreProvider);
    }

    @Bean
    public StoreSerializerFactory storeSerializerFactory() {
        return new KryoSerializationFactory();
    }

    @Bean
    public ElasticSearchProvider elasticSearchProvider(Config config) throws UnknownHostException, NodeValidationException {
            System.setProperty(CSL_ENDPOINT_CONFIG_KEY, config.getString(CSL_ENDPOINT_CONFIG_KEY));
            System.setProperty(RESEARCH_CSL_ENDPOINT_CONFIG_KEY, config.getString(RESEARCH_CSL_ENDPOINT_CONFIG_KEY));
        return new EmbeddedElasticSearchProvider(config, "Channels-ES", rootHost, nodeName, isRoot);
    }

    @Bean
    public ObjectMapper objectMapper() {

        return new ObjectMapper()
                .registerModule(new JodaModule())
                .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
                .configure(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS, false)
                .registerModule(new JavaTimeModule())
                .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    }
}
