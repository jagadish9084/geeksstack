package com.scb.channels.foundation.search.impl;

import org.elasticsearch.client.Client;

/**
 * Created by 1409314 on 2/11/2017.
 */
public interface ElasticSearchProvider {
    Client getClient();
}
