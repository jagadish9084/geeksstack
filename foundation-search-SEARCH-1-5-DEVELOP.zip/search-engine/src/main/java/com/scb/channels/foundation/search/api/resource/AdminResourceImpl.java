package com.scb.channels.foundation.search.api.resource;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.scb.channels.foundation.search.SearchEngineAdminService;
import com.scb.channels.foundation.search.api.dto.IndexDefinitions;
import com.scb.channels.foundation.search.model.IndexFieldDefinition;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.Authorization;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.context.WebApplicationContext;

import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.Map;
import java.util.stream.Collectors;

@CrossOrigin
@Component
@Scope(WebApplicationContext.SCOPE_REQUEST)
@Path("/admin")
@Api(value = "/admin", description = "Search Engine Admin API")
public class AdminResourceImpl {

    private SearchEngineAdminService searchEngineAdminService;

    @Autowired
    public AdminResourceImpl(SearchEngineAdminService reportEngineService) {
        this.searchEngineAdminService = reportEngineService;
    }

    @POST
    @Path("/defineIndex")
    @Consumes("application/json")
    @Produces("application/json")
    @ApiOperation(value = "Defines an index or updates the mappings of an existing index",
            response = String.class,
            code = 204,
            httpMethod = "POST",
            authorizations = {@Authorization(value="basicAuth")})
    public Response defineIndex(@ApiParam(required = true) IndexDefinitions indexDefinitions) {
        indexDefinitions.getIndexDefinitions().forEach(id->
            searchEngineAdminService.defineIndex(
                id.getIndexName(),
                id.getIndexType(),
                id.getFields().entrySet().stream().map(e-> Pair.of(e.getKey(), new IndexFieldDefinition(e.getValue()))).collect(Collectors.toMap(Pair::getKey, Pair::getValue))
                )
        );
        return Response.status(Response.Status.NO_CONTENT).build();
    }

    @GET
    @Path("/indexDefinition/{indexName}/{indexType}")
    @Produces("application/json")
    @ApiOperation(value = "Returns a json describing the index, including field mappings",
            response = Map.class,
            httpMethod = "GET",
            authorizations = {@Authorization(value="basicAuth")})
    public Map indexDefinition(@PathParam("indexName") String indexName, @PathParam("indexType") String indexType) throws IOException {
        return searchEngineAdminService.getIndexMappings(indexName,indexType);
    }

    @GET
    @Path("/stats")
    @Produces("application/json")
    @ApiOperation(value = "Returns detailed JSON for status of the search engine cluster.",
            response = String.class,
            httpMethod = "GET",
            authorizations = {@Authorization(value="basicAuth")})
    public String getNodeStats() throws JsonProcessingException {
        return this.searchEngineAdminService.getStatistics();
    }

    @GET
    @Path("/searchShardsInfo")
    @Produces("application/json")
    @ApiOperation(value = "Returns detailed JSON for Search Shards info search engine cluster.",
            response = String.class,
            httpMethod = "GET",
            authorizations = {@Authorization(value="basicAuth")})
    public String getSearchShardStats() throws JsonProcessingException {
        return this.searchEngineAdminService.getSearchShardStatistics();
    }

}
