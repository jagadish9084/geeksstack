package com.scb.channels.foundation.search.elastic;

import com.scb.channels.foundation.entitlement.dap.DapPolicy;
import com.scb.channels.foundation.entitlement.dap.DapPolicyFactory;
import com.scb.channels.foundation.search.SearchEngineContext;
import org.elasticsearch.common.ParsingException;
import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;
import org.elasticsearch.common.lucene.search.function.ScoreFunction;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentParser;
import org.elasticsearch.index.mapper.MappedFieldType;
import org.elasticsearch.index.mapper.TextFieldMapper;
import org.elasticsearch.index.query.QueryParseContext;
import org.elasticsearch.index.query.QueryShardContext;
import org.elasticsearch.index.query.functionscore.ScoreFunctionBuilder;

import java.io.IOException;

public class DapSearchScoreBuilder extends ScoreFunctionBuilder<DapSearchScoreBuilder> {

    static final String NAME = "dap_policy_enforcer";

    private String dapPolicy;
    private String userId;
    private double minSubQueryScore;
    private DapPolicyFactory dapPolicyFactory = StaticDapPolicyFactory.INSTANCE;

    DapSearchScoreBuilder(StreamInput in) throws IOException {
        super(in);
        this.dapPolicy = in.readString();
        this.userId = in.readString();
        this.minSubQueryScore = in.readDouble();
    }

    private DapSearchScoreBuilder(String dapPolicy, String userId, double minSubQueryScore) {
        this.userId = userId;
        this.dapPolicy = dapPolicy;
        this.minSubQueryScore = minSubQueryScore;
    }

    @Override
    protected void doWriteTo(StreamOutput out) throws IOException {
        out.writeString(dapPolicy);
        out.writeString(userId);
        out.writeDouble(minSubQueryScore);
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    protected void doXContent(XContentBuilder builder, Params params) throws IOException {
        builder.startObject(getName());
        builder.field("policy", dapPolicy);
        builder.field("userId", userId);
        builder.field("minSubQueryScore", minSubQueryScore);
        builder.endObject();
    }

    @Override
    protected boolean doEquals(DapSearchScoreBuilder functionBuilder) {
        return functionBuilder.dapPolicy.equals(dapPolicy) && functionBuilder.userId.equals(userId);
    }

    @Override
    protected int doHashCode() {
        return dapPolicy.hashCode() * userId.hashCode();
    }

    @Override
    protected ScoreFunction doToFunction(QueryShardContext context) throws IOException {

        MappedFieldType uidFieldType = context.getMapperService().fullName("_uid");
        MappedFieldType statusFieldType = context.getMapperService().fullName("status");

        //For empty shards, there are only default mappings defined, which
        //results in status being non-fielddata
        if (statusFieldType instanceof TextFieldMapper.TextFieldType) {
            if (!((TextFieldMapper.TextFieldType)statusFieldType).fielddata()) {
                statusFieldType = null;
            }
        } else {
            statusFieldType = null;
        }

        return new DapSearchFunction(dapPolicy(), userId, minSubQueryScore, context.getForField(uidFieldType),statusFieldType == null ? null : context.getForField(statusFieldType) );
    }

    private DapPolicy dapPolicy() {
        return dapPolicyFactory.create(dapPolicy);
    }

    static DapSearchScoreBuilder fromXContent(QueryParseContext parseContext)
            throws IOException, ParsingException {
        XContentParser parser = parseContext.parser();
        String currentFieldName = null;

        String policy = null;
        String userId = null;
        double minSubQueryScore = 0.0d;

        XContentParser.Token token;
        while ((token = parser.nextToken()) != XContentParser.Token.END_OBJECT) {
            if (token == XContentParser.Token.FIELD_NAME) {
                currentFieldName = parser.currentName();
            } else if (token.isValue()) {
                if ("policy".equals(currentFieldName)) {
                    policy = parser.text();
                } else if ("userId".equals(currentFieldName)) {
                    userId = parser.text();
                } else if ("minSubQueryScore".equals(currentFieldName)) {
                    minSubQueryScore = Double.parseDouble(parser.text());
                }
                else {
                    throw new ParsingException(parser.getTokenLocation(), NAME + " query does not support [" + currentFieldName + "]");
                }
            }
        }

        if (policy == null) {
            throw new ParsingException(parser.getTokenLocation(), "[" + NAME + "] required field 'field' missing");
        }

        return new DapSearchScoreBuilder(policy,userId,minSubQueryScore);
    }

    private static ScoreFunctionBuilder dapPolicy(String dapPolicy, String userId, double minSubQueryScore) {
        return new DapSearchScoreBuilder(dapPolicy, userId, minSubQueryScore);
    }

    public static ScoreFunctionBuilder dapPolicy(SearchEngineContext searchEngineContext, double minSubQueryScore) {
        return dapPolicy(searchEngineContext.getDapPolicy(), searchEngineContext.getUserId(), minSubQueryScore);
    }
}
