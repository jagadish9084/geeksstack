package com.scb.channels.foundation.search.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Maps;
import com.scb.channels.foundation.api.dto.recon.ReconHeaderRequest;
import com.scb.channels.foundation.api.dto.recon.ReconHeaderResponse;
import com.scb.channels.foundation.api.dto.recon.ReconHeaders;
import com.scb.channels.foundation.objectstore.ObjectStoreProvider;
import com.scb.channels.foundation.search.SearchEngineAdminService;
import com.scb.channels.foundation.search.SearchEngineContext;
import com.scb.channels.foundation.search.SearchEngineService;
import com.scb.channels.foundation.search.api.dto.SearchRequest;
import com.scb.channels.foundation.search.model.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.elasticsearch.action.bulk.BulkItemResponse;
import org.elasticsearch.action.bulk.BulkRequestBuilder;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.support.WriteRequest;
import org.elasticsearch.client.Client;
import org.elasticsearch.search.SearchHit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;

import java.io.IOException;
import java.text.MessageFormat;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.scb.channels.foundation.objectstore.ObjectStoreProvider.lock;
import static com.scb.channels.foundation.objectstore.ObjectStoreProvider.unlock;
import static com.scb.channels.foundation.search.impl.SearchBuilders.*;
import static com.scb.channels.foundation.search.impl.Utils.*;
import static com.scb.channels.foundation.util.Execution.executeSafeAndTimed;
import static java.util.stream.Collectors.toList;

@Scope("singleton")
public class SearchEngineServiceImpl implements SearchEngineService {

    private static final Logger logger = LoggerFactory.getLogger(SearchEngineServiceImpl.class);

    private static final String IDENTIFIER_FIELD = "identifier";
    private static final String DID_YOU_MEAN_FIELD = "description";
    private static final String PAYLOAD_FIELD = "payload";
    private static float LOW_SCORE_THRESHOLD = 0.2f;
    private static final String FIELD_MD5HASH = "md5hash";
    private static final String FIELD_TIMESTAMP = "timestamp";

    private static String FILTER_EXPRESSION_HAS_IDS = "entityType:{0} AND identifier:{1}";
    private static String FILTER_EXPRESSION_NOT_HAVE_IDS = "entityType:{0} AND -identifier:{1}";
    private static String FILTER_EXPRESSION_HAS_IDS_WITH_SUBCATEGORY = "entityType:{0} AND identifier:{1} AND payload.subcategory:{2}";
    private static String FILTER_EXPRESSION_NOT_HAVE_IDS_WITH_SUBCATEGORY = "entityType:{0} AND -identifier:{1} AND payload.subcategory{2}";

    private Client client;

    private Map<String, Favourites> favouriteObjectStore;
    private SearchEngineAdminService searchEngineAdminService;

    private ObjectMapper objectMapper;

    private SearchEventService searchEventService;

    public SearchEngineServiceImpl(ElasticSearchProvider elasticSearchProvider, SearchEventService searchEventService,
                                   SearchEngineAdminService searchEngineAdminService,
                                   ObjectStoreProvider objectStoreProvider,
                                   ObjectMapper objMapper) {
        this.client = elasticSearchProvider.getClient();
        this.searchEventService = searchEventService;
        this.searchEngineAdminService = searchEngineAdminService;
        this.favouriteObjectStore = objectStoreProvider.getObjectStore("Favourites");
        this.objectMapper = objMapper;
    }

    @Override
    public SearchResult quickSearch(String expression, int resultLimit, SearchEngineContext searchEngineContext) {
        return quickSearch(expression, false, resultLimit, searchEngineContext);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Collection<String> predict(PredictionType predictionType, String partial, int resultLimit, String[] fields, SearchEngineContext searchEngineContext) {
        return predict(predictionType, partial, null, resultLimit, fields, searchEngineContext);
    }

    @Override
    public Map<String, String> ingest(Collection<IndexObject> indexObjects, SearchEngineContext searchEngineContext) {

        logger.info("Executing ingest for user id " + getCurrentUserId(searchEngineContext));

        return executeSafeAndTimed("ingest", () -> {

            logger.info("Ingesting " + indexObjects.size() + " objects .. ");

            BulkRequestBuilder builder = client.prepareBulk().setRefreshPolicy(WriteRequest.RefreshPolicy.WAIT_UNTIL);

            indexObjects.stream().map(i -> Pair.of(indexName(i), indexType(i))).distinct().forEach(i -> {
                if (!searchEngineAdminService.indexExists(i.getKey(), i.getValue())) {
                    searchEngineAdminService.defineIndex(i.getKey(), i.getValue(), Collections.emptyMap());
                }
            });

            Map<String, IndexObject> indexObjectIds = Maps.newHashMap();
            for (IndexObject indexObject : indexObjects) {
                deleteIfExist(indexObject, searchEngineContext);
                String id = id(indexObject);
                indexObjectIds.put(id, indexObject);

                builder.add(client.prepareIndex(
                        indexName(indexObject),
                        indexType(indexObject)).
                        setSource(source(indexObject), contentType()).
                        setId(id).
                        setOpType(opType()));
            }

            BulkResponse response = builder.get();
            Map<String, String> results = groupIngestResults(response);
            handleUpdatesOnDuplicates(indexObjectIds, response, results);

            logger.info("Ingested, " + results.size() + " results. ");
            searchEventService.logIngestation(indexObjects);
            return results;

        });

    }

    @Override
    public SearchResult newSearch(NewSearchRequest newSearchRequest, SearchEngineContext searchEngineContext) {
        logger.info("Executing new search for user id " + getCurrentUserId(searchEngineContext));

        return executeSafeAndTimed("newSearch", () -> {
            SearchRequestBuilder searchRequest = aggregationRequestBuilder(searchRequestBuilder(
                    client, searchEngineContext,
                    newSearchRequest,
                    defaultSearchFieldArray("_all"),
                    defaultFieldArray("_all")), newSearchRequest);

            logger.debug("Executing new search with query builder: " + searchRequest.toString());

            SearchResponse response;
            try {
                response = searchRequest.get();
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
                throw e;
            }

            String searchId = searchEventService.logSearch(newSearchRequest, response);

            SearchResult result = toSearchResult(response, newSearchRequest.getExpression(), newSearchRequest.isIncludePayload(), searchId);

            if (newSearchRequest.isIncludeDidYouMean() || isEmptySearchResult(result, LOW_SCORE_THRESHOLD)) {
                result = result.withSuggestions(this.predict(PredictionType.DidYouMean, newSearchRequest.getExpression(), newSearchRequest.getFilterExpression(), 5, new String[]{IDENTIFIER_FIELD, DID_YOU_MEAN_FIELD}, searchEngineContext));
            }

            return result;
        });
    }

    @Override
    public SearchResult continueSearch(ContinueSearchRequest continueSearchRequest, SearchEngineContext searchEngineContext) {
        logger.info("Executing continue search for user id " + getCurrentUserId(searchEngineContext));
        return executeSafeAndTimed("continueSearch", () -> {

            SearchRequestBuilder builder = aggregationRequestBuilder(searchRequestBuilder(
                    client, searchEngineContext,
                    continueSearchRequest.getNewSearchRequest(),
                    defaultSearchFieldArray("_all"),
                    defaultFieldArray("_all")), continueSearchRequest.getNewSearchRequest());

            builder.searchAfter(continueSearchRequest.getMarker());
            logger.debug("Executing continue search with query builder: ", builder);
            SearchResponse response = builder.get();
            return toSearchResult(response, continueSearchRequest.getNewSearchRequest().getExpression(),
                    continueSearchRequest.getNewSearchRequest().isIncludePayload(),
                    searchEventService.logSearchContinuation(continueSearchRequest, response));
        });
    }

    @Override
    public SearchResult quickSearch(String expression, boolean includePayload, int resultLimit, SearchEngineContext searchEngineContext) {
        logger.info("Executing quick search for user id " + getCurrentUserId(searchEngineContext) + ", expression " + expression);
        return executeSafeAndTimed("quicksearch", () -> {
            SearchResponse response = quickSearchRequestBuilder(client, searchEngineContext, expression, includePayload, resultLimit, defaultSearchFieldArray("_all"), defaultFieldArray("_all")).get();
            SearchResult result = toSearchResult(response, expression, includePayload, searchEventService.logQuickSearch(expression, resultLimit, response));
            if (isEmptySearchResult(result, LOW_SCORE_THRESHOLD)) {
                result = result.withSuggestions(this.predict(PredictionType.DidYouMean, expression, "", 5, new String[]{DID_YOU_MEAN_FIELD}, searchEngineContext));
            }
            return result;
        });
    }

    @SuppressWarnings("unchecked")
    @Override
    public Collection<String> predict(PredictionType predictionType, String requestPartial, String filterExpression, int resultLimit, String[] fields, SearchEngineContext searchEngineContext) {
        logger.info("Executing predict with type " + predictionType + " and partial " + requestPartial + " for fields " + StringUtils.join(fields, ","));
        return executeSafeAndTimed("predict", () -> {

            String partial = cleanPartialForPredict(requestPartial);

            if (requestPartial.trim().equals("") || requestPartial.trim().equals("*")) {
                return Collections.<String>emptyList();
            }
            SearchRequestBuilder builder = suggestRequestBuilder(client, searchEngineContext,
                    predictionType, partial, filterExpression, fields, resultLimit);

            logger.debug("Executing predict query with builder: ", builder);

            SearchResponse response = builder.get();

            return PredictionType.AutoComplete.equals(predictionType) ?
                    parseAutoCompleteResults(fields, response) :
                    parseSuggestResponse(partial, response);

        });
    }

    @Override
    public void addFavourite(String searchId, SearchEngineContext searchEngineContext) {
        logger.info("Adding favourite for user id " + getCurrentUserId(searchEngineContext) + " with search id " + searchId);
        executeSafeAndTimed("deleteFavourite", () -> {
            assert searchEventService.findSearch(searchId) != null;
            updateFavourite(favourites -> favourites.add(searchId), searchEngineContext);
        });
    }

    @Override
    public void deleteFavourite(String searchId, SearchEngineContext searchEngineContext) {
        logger.info("Deleting favourite for user id " + getCurrentUserId(searchEngineContext) + " with search id " + searchId);
        executeSafeAndTimed("deleteFavourite", () -> updateFavourite(favourites -> favourites.remove(searchId), searchEngineContext));
    }

    @Override
    public Collection<SearchEvent> findFavourites(Integer searchLimit, SearchEngineContext searchEngineContext) {
        logger.info("Finding favourites for user id " + getCurrentUserId(searchEngineContext));
        return executeSafeAndTimed("findFavourites", () -> {
            Favourites favs = favouriteObjectStore.get(searchEngineContext.getUserId());
            return (favs != null ? favs.limit(searchLimit) : new Favourites()).getSearchIds().stream()
                    .map(sid -> searchEventService.findSearch(sid))
                    .filter(p -> p != null)
                    .collect(toList());
        });
    }

    private List<Result> collectReconListMatchesInSE(List<ReconHeaders> reconHeadersList, SearchEngineContext searchEngineContext, int batchSize) {

        List<Result> results = new ArrayList<>();
        //Make the request in batches
        boolean continueLoop = true;
        for (int startIndex = 0; continueLoop; startIndex += batchSize) {
            int endIndex = getEndIndex(reconHeadersList, startIndex, batchSize);
            logger.info("Retrieving Recon headers Results. Total: {}, StartIndex: {}, EndIndex: {}"
                    , reconHeadersList.size(), startIndex, endIndex);
            NewSearchRequest request = new NewSearchRequest(createSearchRequestWithHeaders(batchSize,
                    reconHeadersList.subList(startIndex, endIndex).toArray(new ReconHeaders[0])));
            results.addAll(newSearch(request, searchEngineContext).getResults());
            continueLoop = endIndex < reconHeadersList.size();
        }
        logger.info("Total hits for Recon: {}", results.size());
        return results;
    }

    private int getEndIndex(List<ReconHeaders> reconHeaderList, int startIndex, int batchSize) {
        return startIndex + batchSize < reconHeaderList.size() ? startIndex + batchSize : reconHeaderList.size();
    }

    private boolean identifiersEqual(List<String> resultsIdentifier, List<String> reconIdentifiers) {
        final Set<String> s1 = new HashSet<>(resultsIdentifier);
        final Set<String> s2 = new HashSet<>(reconIdentifiers);

        return s1.equals(s2);
    }

    private boolean foundInResults(List<Result> results, ReconHeaders header) {
        return results.stream().anyMatch(result -> identifiersEqual((List<String>) result.getFields().get("identifier"), header.getIdentifiers()));
    }

    private Optional<Result> getResult(List<Result> results, ReconHeaders header) {
        return results.stream().filter(result -> identifiersEqual((List<String>) result.getFields().get("identifier"), header.getIdentifiers()))
                .findFirst();
    }

    @Override
    public ReconHeaderResponse compareReconHeaders(ReconHeaderRequest request, SearchEngineContext searchEngineContext) {

        logger.info("Processing Recon Headers: {}", request.getReconHeaders());
        //Search request with all identifiers, and get all results.
        // Batch Search requests
        List<Result> searchResults = collectReconListMatchesInSE(request.getReconHeaders(), searchEngineContext, 1000);
        Predicate<ReconHeaders> finalPredicate = getNotFoundPredicate(searchResults).or(getHashAndTimestampPredicate(searchResults));
        List<ReconHeaders> headersToUpdate = request.getReconHeaders().stream().filter(finalPredicate).collect(Collectors.toList());
        // TODO as discussed with jonathan, not in recon list and in db will not be deleted for now
        // onlyInElasticList = listOnlyInElastic(request.getReconHeaders(), searchEngineContext);
        return new ReconHeaderResponse(headersToUpdate, ImmutableList.of());

    }

    private boolean isNotEqual(Result result, String hash) {
        String resultHash = String.valueOf(result.getFields().get(FIELD_MD5HASH));
        return (null == resultHash) || !resultHash.contentEquals(hash);
    }

    private Predicate<ReconHeaders> getHashAndTimestampPredicate(List<Result> searchResults) {
        return (ReconHeaders header) -> {
            Optional<Result> result = getResult(searchResults, header);
            return result.isPresent()
                    && isNotEqual(result.get(), header.getMd5hash())
                    && !Instant.ofEpochSecond(header.getTimestamp()).isBefore(Instant.parse((String) result.get().getFields().get(FIELD_TIMESTAMP)));
        };
    }

    private Predicate<ReconHeaders> getNotFoundPredicate(List<Result> searchResults) {
        return header -> !foundInResults(searchResults, header) && !"delete".equalsIgnoreCase(header.getAction());
    }

    private List<ReconHeaders> listOnlyInElastic(List<ReconHeaders> headers, SearchEngineContext searchEngineContext) {
        NewSearchRequest request = new NewSearchRequest(createNotInHeadersSearchRequest(headers, 10000));
        SearchResult searchResult = newSearch(request, searchEngineContext);

        List<ReconHeaders> listOnlyInElastic = new ArrayList<>();
        while (0 < searchResult.getResults().size()) {
            listOnlyInElastic.addAll(searchResult.getResults().stream()
                    .map(results -> {
                        Map<String, Object> fields = results.getFields();
                        return ReconHeaders.builder()
                                .md5hash((String) fields.get("md5hash"))
                                .identifiers((List<String>) fields.get("identifier"))
                                .entityType((String) fields.get("entityType"))
                                .timestamp(Instant.now().getEpochSecond())
                                .subCategory("")
                                .applicationId((String) fields.get("applicationId"))
                                .build();
                    })
                    .collect(toList()));

            ContinueSearchRequest continueSearchRequest = new ContinueSearchRequest(nextContinuationMarker(searchResult),
                    request);
            searchResult = continueSearch(continueSearchRequest, searchEngineContext);
        }

        return listOnlyInElastic;

    }

    private String[] nextContinuationMarker(SearchResult result) {
        return result.getResults().get(result.getResults().size() - 1).getContinuationMarker();
    }


    private SearchRequest createNotInHeadersSearchRequest(List<ReconHeaders> headers, int resultSetLimit) {

        String filterExpression = "";
        if (StringUtils.isEmpty(headers.get(0).getSubCategory())) {
            filterExpression = MessageFormat.format(FILTER_EXPRESSION_NOT_HAVE_IDS, headers.get(0).getEntityType(), formIdentifierExpression(headers));
        } else {
            filterExpression = MessageFormat.format(FILTER_EXPRESSION_NOT_HAVE_IDS_WITH_SUBCATEGORY, headers.get(0).getEntityType(), formIdentifierExpression(headers), headers.get(0).getSubCategory());
        }

        return SearchRequest.builder()
                .filterExpression(filterExpression)
                .includePayload(false)
                .expression("*")
                .resultSetLimit(resultSetLimit)
                .build();
    }

    private SearchRequest createSearchRequestWithHeaders(int resultSetLimit, ReconHeaders... headersList) {
        List<String> identifiersList = new ArrayList<>();
        String entityType = headersList.length > 0 ? headersList[0].getEntityType() : "";

        Stream.of(headersList).forEach(headers -> identifiersList.addAll(headers.getIdentifiers()));
        String identifiers = identifiersList.stream().
                filter(identifier -> !entityType.equalsIgnoreCase(identifier)).
                collect(Collectors.joining(" OR ", "(", ")"));
        logger.info("Recon Search Request with Headers generated.");
        logger.info("FilterExpression: {}", MessageFormat.format(FILTER_EXPRESSION_HAS_IDS, entityType, identifiers));
        return SearchRequest.builder()
                .expression("*")
                .includePayload(false)
                .resultSetLimit(resultSetLimit)
                .filterExpression(MessageFormat.format(FILTER_EXPRESSION_HAS_IDS, entityType, identifiers))
                .build();

    }

    private String formIdentifierExpression(List<ReconHeaders> headers) {
        return headers.stream()
                .map(reconHeaders -> reconHeaders.getIdentifiers().stream().
                        filter(identifier -> !reconHeaders.getEntityType().equalsIgnoreCase(identifier)).
                        collect(Collectors.joining(" AND ", "(", ")")))
                .collect(Collectors.joining(" OR ", "(", ")"));
    }

    private void updateFavourite(Function<Favourites, Favourites> action, SearchEngineContext searchEngineContext) {
        lock(favouriteObjectStore, searchEngineContext.getUserId());
        try {
            favouriteObjectStore.computeIfAbsent(searchEngineContext.getUserId(), k -> new Favourites());
            Favourites favs = favouriteObjectStore.get(searchEngineContext.getUserId());
            favouriteObjectStore.put(searchEngineContext.getUserId(), action.apply(favs));
        } finally {
            unlock(favouriteObjectStore, searchEngineContext.getUserId());
        }
    }

    private static SearchResult toSearchResult(SearchResponse response, String queryExpression, boolean includePayload, String searchId) {

        Optional<Float> maxScore = Stream.of(response.getHits().getHits()).map(SearchHit::getScore).max(Float::compare);
        if (response.getShardFailures() != null) {
            Stream.of(response.getShardFailures()).forEach(s -> logger.error("[" + searchId + "], Shard: " + s.shardId() + ", Index: " + s.index() + ", Reason:" + s.reason()));
        }

        return new SearchResult(
                response.getHits().totalHits(),
                maxScore.isPresent() ? maxScore.get() : 0.0f,
                includePayload,
                response.getAggregations(),
                response.getHits(),
                (sh) -> postProcessHighlights(sh, queryExpression)
        ).updateSearchId(searchId);

    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> source(IndexObject indexObject) {
        try {
            Map<String, Object> result = Maps.newHashMap();
            result.putAll(objectMapper.readValue(objectMapper.writeValueAsString(indexObject.getFields()), Map.class));

            Map<String, Object> payload = objectMapper.readValue(indexObject.getPayload(), Map.class);

            String suggester = buildSuggesterString(
                    indexObject.getFields().getDescription(),
                    indexObject.getFields().getIdentifier(),
                    buildPayloadAll(payload, new StringBuilder("")).toString().trim());

            result.put(SUGGESTER_FIELD, suggester);
            result.put(PAYLOAD_FIELD, payload);
            return result;
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    private void handleUpdatesOnDuplicates(Map<String, IndexObject> indexObjectIds, BulkResponse response, Map<String, String> results) {
        AtomicInteger updates = new AtomicInteger();
        BulkRequestBuilder updateBuilder = client.prepareBulk().setRefreshPolicy(WriteRequest.RefreshPolicy.WAIT_UNTIL);
        Stream.of(response.getItems()).filter(BulkItemResponse::isFailed).forEach(
                n -> {
                    IndexObject indexObject = indexObjectIds.get(n.getId());
                    updateBuilder.add(client.prepareUpdate(
                            indexName(indexObject),
                            indexType(indexObject),
                            id(indexObject)).
                            setDoc(source(indexObject))
                    );
                    updates.incrementAndGet();
                }
        );
        if (updates.get() > 0) {
            response = updateBuilder.get();
            results.putAll(groupIngestResults(response));
        }
    }

    private String getCurrentUserId(SearchEngineContext searchEngineContext) {
        return searchEngineContext == null ? "TEST" : searchEngineContext.getUserId();
    }

    @SuppressWarnings("unchecked")
    private void deleteIfExist(IndexObject indexObject, SearchEngineContext searchEngineContext) {
        final int resultSetLimit = 100;
        String identifier = indexObject.getFields().getIdentifier().stream().
                filter(idf -> !indexObject.getFields().getEntityType().equalsIgnoreCase(idf)).
                collect(Collectors.joining(" AND ", "(", ")"));

        SearchRequest searchRequest = SearchRequest.builder()
                .expression("*")
                .includePayload(false)
                .resultSetLimit(resultSetLimit)
                .filterExpression(MessageFormat.format(FILTER_EXPRESSION_HAS_IDS, indexObject.getFields().getEntityType(), identifier))
                .build();
        SearchResult searchResult = newSearch(new NewSearchRequest(searchRequest), searchEngineContext);

        if (null != searchResult) {
            List<String> idsToDelete = searchResult.getResults().stream()
                    .filter(result -> identifiersEqual(indexObject.getFields().getIdentifier(), (List<String>) result.getFields().get(IDENTIFIER_FIELD)))
                    .map(Result::getId).collect(Collectors.toList());

            idsToDelete.forEach(idToDelete -> {
                DeleteResponse deleteResponse = client.prepareDelete(indexObject.getIndexName(), indexObject.getIndexType(), idToDelete).execute().actionGet();
                if (deleteResponse.status().getStatus() == 200) {
                    logger.info("entity of type : {} and Id: {} has been deleted", indexObject.getFields().getEntityType(), deleteResponse.getId());
                }
            });
        }
    }

}
