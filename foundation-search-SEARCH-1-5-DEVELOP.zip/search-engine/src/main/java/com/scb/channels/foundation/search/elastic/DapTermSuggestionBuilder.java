package com.scb.channels.foundation.search.elastic;

import com.scb.channels.foundation.entitlement.dap.DapPolicy;
import com.scb.channels.foundation.search.SearchEngineContext;
import org.elasticsearch.ElasticsearchParseException;
import org.elasticsearch.common.ParseField;
import org.elasticsearch.common.ParsingException;
import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentParser;
import org.elasticsearch.index.query.QueryShardContext;
import org.elasticsearch.search.suggest.SuggestionSearchContext;
import org.elasticsearch.search.suggest.term.DapTermSuggester;
import org.elasticsearch.search.suggest.term.TermSuggestionBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.lang.reflect.Field;

public class DapTermSuggestionBuilder extends TermSuggestionBuilder {

    private static final Logger logger = LoggerFactory.getLogger(DapTermSuggestionBuilder.class);

    public static final ParseField DAP_POLICY_FIELD = new ParseField("dap_policy");
    public static final ParseField USER_ID_FIELD = new ParseField("user_id");

    private String dapPolicy;
    private String userId;

    public DapTermSuggestionBuilder() {
        super("_na_");
    }

    public DapTermSuggestionBuilder(String field, SearchEngineContext context) {
        super(field);
        this.dapPolicy = context.getDapPolicy();
        this.userId = context.getUserId();
    }

    public DapTermSuggestionBuilder dapPolicy(String dapPolicy) {
        this.dapPolicy = dapPolicy;
        return this;
    }

    public DapTermSuggestionBuilder userId(String userId) {
        this.userId = userId;
        return this;
    }

    @Override
    public String getWriteableName() {
        return DapTermSuggester.NAME;
    }

    public DapTermSuggestionBuilder(StreamInput in) throws IOException {
        super(in);
        this.dapPolicy = in.readString();
        this.userId = in.readString();
    }

    @Override
    public void doWriteTo(StreamOutput out) throws IOException {
        super.doWriteTo(out);
        out.writeString(dapPolicy);
        out.writeString(userId);
    }

    @Override
    public SuggestionSearchContext.SuggestionContext build(QueryShardContext context) throws IOException {
        //TODO: figure out how to remove use of reflection, tried re-implementing the super build logic here
        //TODO: and adding a dap term context class, but it didn't work - needs further investigation
        SuggestionSearchContext.SuggestionContext r = super.build(context);
        Field field;
        try {
            field = r.getClass().getSuperclass().getDeclaredField("suggester");
            field.setAccessible(true);
            field.set(r, new  DapTermSuggester(dapPolicy(), userId) );
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new RuntimeException(e.getMessage(),e);
        }
        return r;
    }

    @Override
    public XContentBuilder innerToXContent(XContentBuilder builder, Params params) throws IOException {
        super.innerToXContent(builder,params);
        builder.field(DAP_POLICY_FIELD.getPreferredName(), dapPolicy);
        builder.field(USER_ID_FIELD.getPreferredName(), userId);
        return builder;
    }

    public static TermSuggestionBuilder fromXContent(XContentParser parser) throws IOException {
        TermSuggestionBuilder builder = TermSuggestionBuilder.fromXContent(parser);

        DapTermSuggestionBuilder tmpSuggestion = new DapTermSuggestionBuilder();

        tmpSuggestion.accuracy(builder.accuracy());
        tmpSuggestion.maxEdits(builder.maxEdits());
        tmpSuggestion.maxInspections(builder.maxInspections());
        tmpSuggestion.maxTermFreq(builder.maxTermFreq());
        tmpSuggestion.minDocFreq(builder.minDocFreq());
        tmpSuggestion.minWordLength(builder.minWordLength());
        tmpSuggestion.prefixLength(builder.prefixLength());
        tmpSuggestion.shardSize(builder.shardSize());
        tmpSuggestion.sort(builder.sort());
        tmpSuggestion.text(builder.text());
        tmpSuggestion.regex(builder.regex());
        tmpSuggestion.prefix(builder.prefix());
        tmpSuggestion.stringDistance(builder.stringDistance());
        tmpSuggestion.suggestMode(builder.suggestMode());

        XContentParser.Token token;
        String currentFieldName = null;
        String fieldname = null;
        while ((token = parser.nextToken()) != XContentParser.Token.END_OBJECT) {
            if (token == XContentParser.Token.FIELD_NAME) {
                currentFieldName = parser.currentName();
            } else if (token.isValue()) {
                if (DAP_POLICY_FIELD.match(currentFieldName)) {
                    tmpSuggestion.dapPolicy(parser.text());
                } else if (USER_ID_FIELD.match(currentFieldName)) {
                    tmpSuggestion.userId(parser.text());
                } else {
                    throw new ParsingException(parser.getTokenLocation(),
                            "suggester[term] doesn't support field [" + currentFieldName + "]");
                }
            } else {
                throw new ParsingException(parser.getTokenLocation(), "suggester[term] parsing failed on [" + currentFieldName + "]");
            }
        }

        // now we should have field name, check and copy fields over to the suggestion builder we return
        if (fieldname == null) {
            throw new ElasticsearchParseException(
                    "the required field option [" + FIELDNAME_FIELD.getPreferredName() + "] is missing");
        }
        return tmpSuggestion;
    }


    private DapPolicy dapPolicy() {
        return StaticDapPolicyFactory.INSTANCE.create(dapPolicy);
    }
}
