var config = {
    entitlement: {
        nextgen: {
               csl: {
                   endpoints: ""
               }
            },
         research: {
            csl: {
                endpoints: "http://localhost:9012/research/api/application/v1.0/rp/api/user/entitlement"
            }
         }
    },
    search: {
              elastic: {
                  no_shards: 8,
                  replication_factor: 2,
                  minimum_masters: 2,
                  home_dir : "/apps/tomcat/appdata/search",
                  cluster_hosts: "10.23.195.124,10.23.195.125,10.23.195.126,10.23.195.127,10.23.195.169,10.23.195.170",
                  startport: 9300,
                  endport: 9320,
                     network: {
                       host: ""
                       },
                  max_clause_count: 20480,
                  node_attr_values: "zone:dc2"
              },
              subscription: {
                  enabled: false,
                  user: "system",
                  dappolicy: "NextGen",
                  kafka: {
                     bootstrap_servers: "localhost:9092",
                     services: {
                        groupId: "seGroupId",
                        topic: "search_engine.t"
                     }
                  }
              }
        },
    datasources: {
        searchstore: {
             driverClass: "org.h2.Driver",
             url: "jdbc:h2:file:/apps/tomcat/appdata/search/test_mem;DB_CLOSE_DELAY=-1;AUTO_SERVER=TRUE;INIT=CREATE TABLE IF NOT EXISTS OBJECT_STORE ( ID VARCHAR(64), ENTITY_TYPE VARCHAR(256), CONTENT VARCHAR(4000), SEGMENT NUMBER, AUDITTIMESTAMP DATETIME, PRIMARY KEY ( ENTITY_TYPE, ID, SEGMENT ) ) ",
             user: "sa",
             password: "sa",
             loginTimeout: 30,
             connectionTimeout: 30000,
             maxPoolSize: 5,
             idleTimeout: 120000
        }
    }
}