var config = {
    entitlement: {
        nextgen: {
               csl: {
                   endpoints: "http://10.20.239.143:9183/s2b/global/corporate/api/common/v1.0/search/util/getEntitlement"
               }
            },
        research: {
           csl: {
               endpoints: "http://localhost:9012/research/api/application/v1.0/rp/api/user/entitlement"
           }
        }
    },
    search: {
          elastic: {
              no_shards: 8,
              replication_factor: 1,
              minimum_masters: 1,
              home_dir : "/apps/tomcat/appdata/search",
              cluster_hosts: "10.23.210.25,10.23.210.26",
              startport: 9300,
              endport: 9320,
              network: {
                   host: ""
                   },
              max_clause_count: 20480,
              node_attr_values: "zone:sit"
          },
          subscription: {
              enabled: false,
              user: "system",
              dappolicy: "NextGen",
              kafka: {
                 bootstrap_servers: "localhost:9092",
                 services: {
                    groupId: "seGroupId",
                    topic: "search_engine.t"
                 }
              }
          }
    },
    datasources: {
        searchstore: {
             driverClass: "org.h2.Driver",
             url: "jdbc:h2:file:/apps/tomcat/appdata/search/test_mem;DB_CLOSE_DELAY=-1;AUTO_SERVER=TRUE;INIT=CREATE TABLE IF NOT EXISTS OBJECT_STORE ( ID VARCHAR(64), ENTITY_TYPE VARCHAR(256), CONTENT VARCHAR(4000), SEGMENT NUMBER, AUDITTIMESTAMP DATETIME, PRIMARY KEY ( ENTITY_TYPE, ID, SEGMENT ) ) ",
             user: "sa",
             password: "sa",
             loginTimeout: 30,
             connectionTimeout: 30000,
             maxPoolSize: 5,
             idleTimeout: 120000
        }
    }
}