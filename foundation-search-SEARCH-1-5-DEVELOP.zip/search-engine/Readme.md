# Search Engine Development Guide
Bitbucket Source: https://bitbucket.global.standardchartered.com/scm/s2bv4/foundation-search.git

Maven Settings: [settings.xml](https://confluence.global.standardchartered.com/download/attachments/191456061/settings.xml)

## Building the project
Foundation-Search is a maven project build on Maven 3 and Java 8 (>1.8.0_45). Import the project into Intellij, referencing maven's settings file from the link above and build.
After building the project, a war artifact (search-engine.war) will be available in the target folder of the project source.
The required configuration files are available under the <projectroot>/src/main/resources

* hc.xml is the configuration for hazelcast. [Reference] (https://confluence.global.standardchartered.com/display/CC/Hazelcast+Configuration)
* logback.xml is the configuration for logging. [Reference] (https://confluence.global.standardchartered.com/display/CC/Logging+Configuration)
* service-config.js is the configuration for the application. [Reference] (https://confluence.global.standardchartered.com/display/CC/Application+Configuration)

## Running the application from command line
To run the application, the following will be required:

* application war, (search-engine.war)
* application configuration file (.js)
* hazelcast config (.xml)

Run the application with the following command replacing the appropriate file paths:
    java -jar search-engine.war -Dconfig-file=app-config.js -DhazelcastConfigResource=hazelcastConfig.xml -Dapp-log-base=\folder\path\for\logs\

#### Folder Structure
Under src/main/java
Package: com.scb.channels.foundation.search

* api package - dto and api definitions
* config package - configuration definitions
* elastic package - customizations for DAP (data access policy) calculations used within Elasticsearch
* impl package - Service implemenations
* model package - model objects within Search engine
* Application class - main application class
* SearchEngineContext class - Request context class, defines the expected headers for requests
* SearchEngineAdminService class - Admin Service definitions
* SearchEngineService class - Search service definitions

Package: com.elastic.search.suggest

* phrase - customizations for Phrase suggestions
* term - customizations for Term suggestions

Under config
This folder contains configuration files for the applications seperated by projects and environments.

Under templates
This folder contains the template definition that is used by the aig-template-plugin to generate the appropriate AIG html files in the target folder at build time.

## Contributing

To contribute to the project

* Create a branch with the Jira number, and just starting exploring
* When complete, create a pull request to the branch SEARCH-<VERSION_NUMBER>-DEVELOP, with description of the changes
* Add anyone on CIB Channels Foundation team, or Cooper Lee Tony Gordon Vincent as a reviewer
* And we'll get in touch with comments or updates.